import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Preview proxies often strip Origin / rewrite Host. Server Actions are
  // still available for authenticated forms, but login uses a classic JSON
  // route which is immune to the Origin check.
  experimental: {
    serverActions: {
      allowedOrigins: [
        "localhost:3000",
        "127.0.0.1:3000",
        "localhost",
        "127.0.0.1",
        "*.e2b.app",
        "*.arena.dev",
        "*.vercel.app",
        "*.webcontainer.io",
      ],
      bodySizeLimit: "2mb",
    },
  },
  // Trust the platform proxy for host / protocol headers.
  poweredByHeader: false,
};

export default nextConfig;
