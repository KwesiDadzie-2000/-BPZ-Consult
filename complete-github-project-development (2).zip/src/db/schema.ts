import {
  boolean,
  date,
  doublePrecision,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

/**
 * BPZ Consult ERP — PostgreSQL schema.
 *
 * Fixes carried over from the original local-storage build:
 *  - credentials are stored server-side as scrypt hashes (never in the browser)
 *  - sessions are database rows addressed by an opaque HttpOnly cookie
 *  - every money document posts balanced double-entry journal lines
 */

export const users = pgTable(
  "users",
  {
    id: serial("id").primaryKey(),
    username: text("username").notNull(),
    email: text("email").notNull(),
    name: text("name").notNull(),
    role: text("role").notNull().default("accountant"), // owner | manager | accountant | auditor
    jobTitle: text("job_title").notNull().default("Consultant"),
    passwordHash: text("password_hash").notNull(),
    passwordSalt: text("password_salt").notNull(),
    status: text("status").notNull().default("active"), // active | suspended
    lastLoginAt: timestamp("last_login_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("users_username_idx").on(t.username), uniqueIndex("users_email_idx").on(t.email)],
);

export const sessions = pgTable("sessions", {
  id: text("id").primaryKey(), // sha-256 of the cookie token
  userId: integer("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  userAgent: text("user_agent"),
  ip: text("ip"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  lastSeenAt: timestamp("last_seen_at", { withTimezone: true }).notNull().defaultNow(),
});

export const authEvents = pgTable("auth_events", {
  id: serial("id").primaryKey(),
  identifier: text("identifier").notNull(),
  userId: integer("user_id"),
  kind: text("kind").notNull(), // success | failure | lockout | reset
  ip: text("ip"),
  userAgent: text("user_agent"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const passwordResets = pgTable("password_resets", {
  id: text("id").primaryKey(), // sha-256 of the reset token
  userId: integer("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  usedAt: timestamp("used_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const clients = pgTable("clients", {
  id: serial("id").primaryKey(),
  code: text("code").notNull(),
  name: text("name").notNull(),
  sector: text("sector").notNull(),
  currency: text("currency").notNull().default("GHS"),
  jurisdiction: text("jurisdiction").notNull().default("Ghana"),
  contactName: text("contact_name").notNull().default(""),
  contactEmail: text("contact_email").notNull().default(""),
  phone: text("phone").notNull().default(""),
  services: text("services").notNull().default("Bookkeeping"),
  status: text("status").notNull().default("active"), // active | onboarding | dormant
  healthScore: integer("health_score").notNull().default(80),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const accounts = pgTable(
  "accounts",
  {
    id: serial("id").primaryKey(),
    accountNo: text("account_no").notNull(),
    name: text("name").notNull(),
    type: text("type").notNull(), // asset | liability | equity | income | expense
    category: text("category").notNull(),
    active: boolean("active").notNull().default(true),
  },
  (t) => [uniqueIndex("accounts_no_idx").on(t.accountNo)],
);

export const journals = pgTable("journals", {
  id: serial("id").primaryKey(),
  docNo: text("doc_no").notNull(),
  journalDate: date("journal_date", { mode: "string" }).notNull(),
  module: text("module").notNull(), // Sales | Expenses | Banking | Payroll | Manual
  description: text("description").notNull(),
  clientId: integer("client_id").references(() => clients.id, { onDelete: "set null" }),
  status: text("status").notNull().default("posted"), // posted | reversed
  createdBy: integer("created_by").references(() => users.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const journalLines = pgTable("journal_lines", {
  id: serial("id").primaryKey(),
  journalId: integer("journal_id")
    .notNull()
    .references(() => journals.id, { onDelete: "cascade" }),
  accountNo: text("account_no").notNull(),
  accountName: text("account_name").notNull(),
  description: text("description").notNull().default(""),
  debit: doublePrecision("debit").notNull().default(0),
  credit: doublePrecision("credit").notNull().default(0),
});

export const bankAccounts = pgTable("bank_accounts", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  bankName: text("bank_name").notNull(),
  accountNo: text("account_no").notNull(),
  glAccount: text("gl_account").notNull(),
  kind: text("kind").notNull().default("bank"), // bank | cash | momo
  currency: text("currency").notNull().default("GHS"),
  openedBalance: doublePrecision("opened_balance").notNull().default(0),
});

export const invoices = pgTable(
  "invoices",
  {
    id: serial("id").primaryKey(),
    invoiceNo: text("invoice_no").notNull(),
    clientId: integer("client_id").references(() => clients.id, { onDelete: "set null" }),
    customerName: text("customer_name").notNull(),
    revenueStream: text("revenue_stream").notNull(),
    netRevenue: doublePrecision("net_revenue").notNull(),
    vatRate: doublePrecision("vat_rate").notNull().default(15),
    vatAmount: doublePrecision("vat_amount").notNull().default(0),
    totalAmount: doublePrecision("total_amount").notNull(),
    paidAmount: doublePrecision("paid_amount").notNull().default(0),
    status: text("status").notNull().default("sent"), // draft | sent | partial | paid | overdue
    issueDate: date("issue_date", { mode: "string" }).notNull(),
    dueDate: date("due_date", { mode: "string" }).notNull(),
    notes: text("notes"),
    createdBy: integer("created_by").references(() => users.id, { onDelete: "set null" }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("invoices_no_idx").on(t.invoiceNo)],
);

export const expenses = pgTable("expenses", {
  id: serial("id").primaryKey(),
  reference: text("reference").notNull(),
  clientId: integer("client_id").references(() => clients.id, { onDelete: "set null" }),
  vendor: text("vendor").notNull(),
  category: text("category").notNull(),
  description: text("description").notNull().default(""),
  netAmount: doublePrecision("net_amount").notNull(),
  vatAmount: doublePrecision("vat_amount").notNull().default(0),
  totalAmount: doublePrecision("total_amount").notNull(),
  paidAmount: doublePrecision("paid_amount").notNull().default(0),
  status: text("status").notNull().default("pending"), // pending | approved | paid
  expenseDate: date("expense_date", { mode: "string" }).notNull(),
  dueDate: date("due_date", { mode: "string" }).notNull(),
  glAccount: text("gl_account").notNull(),
  createdBy: integer("created_by").references(() => users.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const employees = pgTable(
  "employees",
  {
    id: serial("id").primaryKey(),
    staffNo: text("staff_no").notNull(),
    name: text("name").notNull(),
    role: text("role").notNull(),
    department: text("department").notNull().default("Advisory"),
    basicSalary: doublePrecision("basic_salary").notNull(),
    allowances: doublePrecision("allowances").notNull().default(0),
    ssnitNo: text("ssnit_no").notNull().default(""),
    tin: text("tin").notNull().default(""),
    status: text("status").notNull().default("active"),
    startDate: date("start_date", { mode: "string" }).notNull(),
  },
  (t) => [uniqueIndex("employees_staff_no_idx").on(t.staffNo)],
);

export const payrollRuns = pgTable("payroll_runs", {
  id: serial("id").primaryKey(),
  period: text("period").notNull(), // YYYY-MM
  status: text("status").notNull().default("approved"), // approved | paid
  gross: doublePrecision("gross").notNull(),
  paye: doublePrecision("paye").notNull(),
  ssnitEmployee: doublePrecision("ssnit_employee").notNull(),
  ssnitEmployer: doublePrecision("ssnit_employer").notNull(),
  netPay: doublePrecision("net_pay").notNull(),
  headcount: integer("headcount").notNull(),
  lines: jsonb("lines").notNull(),
  createdBy: integer("created_by").references(() => users.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const auditLog = pgTable("audit_log", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"),
  actorName: text("actor_name").notNull().default("System"),
  action: text("action").notNull(),
  entity: text("entity").notNull(),
  entityRef: text("entity_ref"),
  summary: text("summary").notNull(),
  ip: text("ip"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type UserRow = typeof users.$inferSelect;
export type ClientRow = typeof clients.$inferSelect;
export type InvoiceRow = typeof invoices.$inferSelect;
export type ExpenseRow = typeof expenses.$inferSelect;
export type JournalRow = typeof journals.$inferSelect;
export type JournalLineRow = typeof journalLines.$inferSelect;
export type EmployeeRow = typeof employees.$inferSelect;
export type PayrollRunRow = typeof payrollRuns.$inferSelect;
