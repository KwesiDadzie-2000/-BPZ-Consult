import { randomBytes, scrypt as _scrypt, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";

/**
 * Server-side credential storage.
 * scrypt(N=16384, r=8, p=1, 64-byte key) with a per-user 16-byte salt.
 * Stored format: `s2$<hex key>` — a bare digest is never written.
 */
const scrypt = promisify(_scrypt) as (password: string, salt: string, keylen: number) => Promise<Buffer>;

export const SCRYPT_PREFIX = "s2$";
const KEY_LEN = 64;
export const PASSWORD_MIN_LENGTH = 10;

async function scryptHex(password: string, salt: string): Promise<string> {
  const key = await scrypt(password, salt, KEY_LEN);
  return key.toString("hex");
}

export async function hashPassword(password: string, salt: string): Promise<string> {
  return `${SCRYPT_PREFIX}${await scryptHex(password, salt)}`;
}

export function newSalt(): string {
  return randomBytes(16).toString("hex");
}

export function needsRehash(hash: string): boolean {
  return !hash.startsWith(SCRYPT_PREFIX);
}

export async function verifyPassword(password: string, salt: string, expectedHash: string): Promise<boolean> {
  if (!password || !salt || !expectedHash) return false;
  if (!expectedHash.startsWith(SCRYPT_PREFIX)) return false;
  try {
    const actual = Buffer.from(await scryptHex(password, salt), "hex");
    const expected = Buffer.from(expectedHash.slice(SCRYPT_PREFIX.length), "hex");
    if (actual.length !== expected.length) return false;
    return timingSafeEqual(actual, expected);
  } catch {
    return false;
  }
}

export function passwordPolicyError(password: string): string | null {
  if (password.length < PASSWORD_MIN_LENGTH) return `Password must be at least ${PASSWORD_MIN_LENGTH} characters.`;
  if (!/[a-z]/.test(password)) return "Password must contain a lowercase letter.";
  if (!/[A-Z]/.test(password)) return "Password must contain an uppercase letter.";
  if (!/[0-9]/.test(password)) return "Password must contain a digit.";
  if (!/[^A-Za-z0-9]/.test(password)) return "Password must contain a symbol.";
  return null;
}
