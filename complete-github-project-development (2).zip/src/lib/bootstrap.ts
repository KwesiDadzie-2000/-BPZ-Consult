import "server-only";
import { sql } from "drizzle-orm";
import { db } from "@/db";

/**
 * Self-healing schema bootstrap.
 *
 * The workspace must never render a raw 500 simply because a fresh PostgreSQL
 * instance has no tables yet (or because a migration was skipped). Every DDL
 * statement is idempotent and runs under a PostgreSQL advisory lock so parallel
 * requests during a cold start cannot race each other.
 */
const DDL: string[] = [
  `create table if not exists "users" (
    "id" serial primary key,
    "username" text not null,
    "email" text not null,
    "name" text not null,
    "role" text not null default 'accountant',
    "job_title" text not null default 'Consultant',
    "password_hash" text not null,
    "password_salt" text not null,
    "status" text not null default 'active',
    "last_login_at" timestamptz,
    "created_at" timestamptz not null default now()
  )`,
  `create unique index if not exists "users_username_idx" on "users" ("username")`,
  `create unique index if not exists "users_email_idx" on "users" ("email")`,
  `create table if not exists "sessions" (
    "id" text primary key,
    "user_id" integer not null references "users"("id") on delete cascade,
    "expires_at" timestamptz not null,
    "user_agent" text,
    "ip" text,
    "created_at" timestamptz not null default now(),
    "last_seen_at" timestamptz not null default now()
  )`,
  `create table if not exists "auth_events" (
    "id" serial primary key,
    "identifier" text not null,
    "user_id" integer,
    "kind" text not null,
    "ip" text,
    "user_agent" text,
    "created_at" timestamptz not null default now()
  )`,
  `create index if not exists "auth_events_identifier_idx" on "auth_events" ("identifier", "created_at")`,
  `create table if not exists "password_resets" (
    "id" text primary key,
    "user_id" integer not null references "users"("id") on delete cascade,
    "expires_at" timestamptz not null,
    "used_at" timestamptz,
    "created_at" timestamptz not null default now()
  )`,
  `create table if not exists "clients" (
    "id" serial primary key,
    "code" text not null,
    "name" text not null,
    "sector" text not null,
    "currency" text not null default 'GHS',
    "jurisdiction" text not null default 'Ghana',
    "contact_name" text not null default '',
    "contact_email" text not null default '',
    "phone" text not null default '',
    "services" text not null default 'Bookkeeping',
    "status" text not null default 'active',
    "health_score" integer not null default 80,
    "notes" text,
    "created_at" timestamptz not null default now()
  )`,
  `create table if not exists "accounts" (
    "id" serial primary key,
    "account_no" text not null,
    "name" text not null,
    "type" text not null,
    "category" text not null,
    "active" boolean not null default true
  )`,
  `create unique index if not exists "accounts_no_idx" on "accounts" ("account_no")`,
  `create table if not exists "journals" (
    "id" serial primary key,
    "doc_no" text not null,
    "journal_date" date not null,
    "module" text not null,
    "description" text not null,
    "client_id" integer references "clients"("id") on delete set null,
    "status" text not null default 'posted',
    "created_by" integer references "users"("id") on delete set null,
    "created_at" timestamptz not null default now()
  )`,
  `create table if not exists "journal_lines" (
    "id" serial primary key,
    "journal_id" integer not null references "journals"("id") on delete cascade,
    "account_no" text not null,
    "account_name" text not null,
    "description" text not null default '',
    "debit" double precision not null default 0,
    "credit" double precision not null default 0
  )`,
  `create index if not exists "journal_lines_journal_idx" on "journal_lines" ("journal_id")`,
  `create table if not exists "bank_accounts" (
    "id" serial primary key,
    "name" text not null,
    "bank_name" text not null,
    "account_no" text not null,
    "gl_account" text not null,
    "kind" text not null default 'bank',
    "currency" text not null default 'GHS',
    "opened_balance" double precision not null default 0
  )`,
  `create table if not exists "invoices" (
    "id" serial primary key,
    "invoice_no" text not null,
    "client_id" integer references "clients"("id") on delete set null,
    "customer_name" text not null,
    "revenue_stream" text not null,
    "net_revenue" double precision not null,
    "vat_rate" double precision not null default 15,
    "vat_amount" double precision not null default 0,
    "total_amount" double precision not null,
    "paid_amount" double precision not null default 0,
    "status" text not null default 'sent',
    "issue_date" date not null,
    "due_date" date not null,
    "notes" text,
    "created_by" integer references "users"("id") on delete set null,
    "created_at" timestamptz not null default now()
  )`,
  `create unique index if not exists "invoices_no_idx" on "invoices" ("invoice_no")`,
  `create table if not exists "expenses" (
    "id" serial primary key,
    "reference" text not null,
    "client_id" integer references "clients"("id") on delete set null,
    "vendor" text not null,
    "category" text not null,
    "description" text not null default '',
    "net_amount" double precision not null,
    "vat_amount" double precision not null default 0,
    "total_amount" double precision not null,
    "paid_amount" double precision not null default 0,
    "status" text not null default 'pending',
    "expense_date" date not null,
    "due_date" date not null,
    "gl_account" text not null,
    "created_by" integer references "users"("id") on delete set null,
    "created_at" timestamptz not null default now()
  )`,
  `create table if not exists "employees" (
    "id" serial primary key,
    "staff_no" text not null,
    "name" text not null,
    "role" text not null,
    "department" text not null default 'Advisory',
    "basic_salary" double precision not null,
    "allowances" double precision not null default 0,
    "ssnit_no" text not null default '',
    "tin" text not null default '',
    "status" text not null default 'active',
    "start_date" date not null
  )`,
  `create unique index if not exists "employees_staff_no_idx" on "employees" ("staff_no")`,
  `create table if not exists "payroll_runs" (
    "id" serial primary key,
    "period" text not null,
    "status" text not null default 'approved',
    "gross" double precision not null,
    "paye" double precision not null,
    "ssnit_employee" double precision not null,
    "ssnit_employer" double precision not null,
    "net_pay" double precision not null,
    "headcount" integer not null,
    "lines" jsonb not null,
    "created_by" integer references "users"("id") on delete set null,
    "created_at" timestamptz not null default now()
  )`,
  `create table if not exists "audit_log" (
    "id" serial primary key,
    "user_id" integer,
    "actor_name" text not null default 'System',
    "action" text not null,
    "entity" text not null,
    "entity_ref" text,
    "summary" text not null,
    "ip" text,
    "created_at" timestamptz not null default now()
  )`,
];

let bootstrapPromise: Promise<void> | null = null;

export function ensureSchema(): Promise<void> {
  if (!bootstrapPromise) {
    bootstrapPromise = run()
      .catch((error) => {
        bootstrapPromise = null;
        throw error;
      });
  }
  return bootstrapPromise;
}

async function run(): Promise<void> {
  // Session-level advisory lock: only one cold-start worker builds the schema.
  await db.execute(sql`select pg_advisory_lock(748201337)`);
  try {
    for (const statement of DDL) {
      await db.execute(sql.raw(statement));
    }
  } finally {
    await db.execute(sql`select pg_advisory_unlock(748201337)`);
  }
}
