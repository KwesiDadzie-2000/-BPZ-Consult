import "server-only";
import { cookies, headers } from "next/headers";
import { redirect } from "next/navigation";
import { and, desc, eq, gt, gte, isNull, lt, sql } from "drizzle-orm";
import { createHash, randomBytes } from "node:crypto";
import { db } from "@/db";
import { auditLog, authEvents, passwordResets, sessions, users, type UserRow } from "@/db/schema";
import { hashPassword, needsRehash, newSalt, passwordPolicyError, verifyPassword } from "./password";

export const SESSION_COOKIE = "bpz_session";
export const SESSION_TTL_MS = 8 * 60 * 60 * 1000; // 8 hours
const SLIDE_THRESHOLD_MS = 2 * 60 * 60 * 1000; // renew once under 2 hours remain
const MAX_FAILURES = 5;
const FAILURE_WINDOW_MS = 15 * 60 * 1000;
const LOCKOUT_MS = 5 * 60 * 1000;
const RESET_TTL_MS = 30 * 60 * 1000;

export type SessionUser = {
  id: number;
  username: string;
  email: string;
  name: string;
  role: string;
  jobTitle: string;
  lastLoginAt: Date | null;
};

export function sanitizeUser(row: UserRow): SessionUser {
  return {
    id: row.id,
    username: row.username,
    email: row.email,
    name: row.name,
    role: row.role,
    jobTitle: row.jobTitle,
    lastLoginAt: row.lastLoginAt,
  };
}

function sha256(value: string): string {
  return createHash("sha256").update(value).digest("hex");
}

async function requestMeta() {
  try {
    const h = await headers();
    return {
      ip: h.get("x-forwarded-for")?.split(",")[0]?.trim() || h.get("x-real-ip") || "local",
      userAgent: h.get("user-agent")?.slice(0, 250) || "unknown",
    };
  } catch {
    return { ip: "local", userAgent: "unknown" };
  }
}

/** True only when the request actually arrived over TLS. */
async function isHttpsRequest(): Promise<boolean> {
  try {
    const h = await headers();
    const proto = (h.get("x-forwarded-proto") || "").split(",")[0].trim();
    if (proto) return proto === "https";
    return (h.get("referer") || "").startsWith("https://");
  } catch {
    return false;
  }
}

async function setSessionCookie(token: string) {
  const store = await cookies();
  // `Secure` is only set over TLS: an http preview would silently drop the
  // cookie and the user would be bounced back to the sign-in screen.
  const secure = await isHttpsRequest();
  store.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure,
    path: "/",
    maxAge: SESSION_TTL_MS / 1000,
  });
}

export async function clearSessionCookie() {
  const store = await cookies();
  const secure = await isHttpsRequest();
  store.set(SESSION_COOKIE, "", { httpOnly: true, sameSite: "lax", secure, path: "/", maxAge: 0 });
}

/** Creates a DB session and returns the raw token (caller attaches the cookie). */
export async function createSession(userId: number): Promise<string> {
  const token = randomBytes(32).toString("hex");
  const meta = await requestMeta();
  await db.insert(sessions).values({
    id: sha256(token),
    userId,
    expiresAt: new Date(Date.now() + SESSION_TTL_MS),
    ip: meta.ip,
    userAgent: meta.userAgent,
  });
  return token;
}

/** Cookie options shared by API routes that attach the session cookie. */
export async function sessionCookieOptions(): Promise<{
  httpOnly: boolean;
  sameSite: "lax";
  secure: boolean;
  path: string;
  maxAge: number;
}> {
  return {
    httpOnly: true,
    sameSite: "lax",
    secure: await isHttpsRequest(),
    path: "/",
    maxAge: SESSION_TTL_MS / 1000,
  };
}

/** Resolves the signed-in user from the HttpOnly cookie, sliding the DB session. */
export async function getCurrentUser(): Promise<SessionUser | null> {
  try {
    const store = await cookies();
    const token = store.get(SESSION_COOKIE)?.value;
    if (!token) return null;
    const rows = await db
      .select({ session: sessions, user: users })
      .from(sessions)
      .innerJoin(users, eq(users.id, sessions.userId))
      .where(eq(sessions.id, sha256(token)))
      .limit(1);
    const row = rows[0];
    if (!row) return null;
    if (row.session.expiresAt.getTime() < Date.now()) {
      try {
        await db.delete(sessions).where(eq(sessions.id, row.session.id));
      } catch {
        /* ignore cleanup failure */
      }
      return null;
    }
    if (row.user.status !== "active") return null;

    // Sliding renewal keeps an active working day from being cut off.
    try {
      if (row.session.expiresAt.getTime() < Date.now() + SLIDE_THRESHOLD_MS) {
        await db
          .update(sessions)
          .set({ expiresAt: new Date(Date.now() + SESSION_TTL_MS), lastSeenAt: new Date() })
          .where(eq(sessions.id, row.session.id));
      } else {
        await db.update(sessions).set({ lastSeenAt: new Date() }).where(eq(sessions.id, row.session.id));
      }
    } catch (error) {
      console.error("Session slide failed", error);
    }
    return sanitizeUser(row.user);
  } catch (error) {
    console.error("getCurrentUser failed", error);
    return null;
  }
}

export async function requireUser(): Promise<SessionUser> {
  const user = await getCurrentUser();
  if (!user) redirect("/login?error=Your+session+expired.+Please+sign+in+again.");
  return user;
}

export async function requireOwner(): Promise<SessionUser> {
  const user = await requireUser();
  if (user.role !== "owner") redirect("/dashboard?error=That+area+is+restricted+to+the+firm+owner.");
  return user;
}

export async function destroyCurrentSession(): Promise<void> {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (token) await db.delete(sessions).where(eq(sessions.id, sha256(token)));
  await clearSessionCookie();
}

export async function destroyAllSessions(userId: number): Promise<void> {
  await db.delete(sessions).where(eq(sessions.userId, userId));
  await clearSessionCookie();
}

export async function revokeSession(userId: number, sessionId: string): Promise<void> {
  await db.delete(sessions).where(and(eq(sessions.userId, userId), eq(sessions.id, sessionId)));
}

async function recentFailures(identifier: string): Promise<{ failures: number; lockedForSeconds: number }> {
  const list = await db
    .select({ kind: authEvents.kind, createdAt: authEvents.createdAt })
    .from(authEvents)
    .where(and(eq(authEvents.identifier, identifier), gte(authEvents.createdAt, new Date(Date.now() - FAILURE_WINDOW_MS))))
    .orderBy(desc(authEvents.createdAt))
    .limit(10);
  let failures = 0;
  let lastFailureAt: Date | null = null;
  for (const event of list) {
    if (event.kind === "success" || event.kind === "lockout") break;
    if (event.kind === "failure") {
      failures += 1;
      if (!lastFailureAt) lastFailureAt = event.createdAt;
    }
  }
  const lockedForSeconds =
    failures >= MAX_FAILURES && lastFailureAt
      ? Math.max(0, Math.ceil((lastFailureAt.getTime() + LOCKOUT_MS - Date.now()) / 1000))
      : 0;
  return { failures, lockedForSeconds };
}

export type LoginResult = { ok: true; token: string } | { ok: false; error: string; lockedForSeconds?: number };

/** Server-side credential check with persisted, brute-force resistant lockout. */
export async function login(identifierInput: string, password: string): Promise<LoginResult> {
  const identifier = identifierInput.trim().toLowerCase();
  if (!identifier || !password) return { ok: false, error: "Enter your username (or email) and password." };

  const meta = await requestMeta();
  const { lockedForSeconds } = await recentFailures(identifier);
  if (lockedForSeconds > 0) {
    return {
      ok: false,
      error: `Too many failed attempts. Try again in ${Math.ceil(lockedForSeconds / 60)} minute(s).`,
      lockedForSeconds,
    };
  }

  const found = await db
    .select()
    .from(users)
    .where(sql`lower(${users.username}) = ${identifier} or lower(${users.email}) = ${identifier}`)
    .limit(1);
  const user = found[0];
  if (!user) {
    await db.insert(authEvents).values({ identifier, kind: "failure", ip: meta.ip, userAgent: meta.userAgent });
    return { ok: false, error: "Invalid username, email or password." };
  }

  const valid = await verifyPassword(password, user.passwordSalt, user.passwordHash);
  if (!valid) {
    const { failures } = await recentFailures(identifier);
    await db.insert(authEvents).values({
      identifier,
      userId: user.id,
      kind: "failure",
      ip: meta.ip,
      userAgent: meta.userAgent,
    });
    if (failures + 1 >= MAX_FAILURES) {
      await db.insert(authEvents).values({
        identifier,
        userId: user.id,
        kind: "lockout",
        ip: meta.ip,
        userAgent: meta.userAgent,
      });
      await db.insert(auditLog).values({
        userId: user.id,
        actorName: user.name,
        action: "Auth lockout",
        entity: "User",
        entityRef: user.username,
        summary: "Sign-in locked for 5 minutes after 5 failed attempts.",
        ip: meta.ip,
      });
    }
    return { ok: false, error: "Invalid username, email or password." };
  }

  if (user.status !== "active") {
    await db.insert(authEvents).values({ identifier, userId: user.id, kind: "failure", ip: meta.ip, userAgent: meta.userAgent });
    return { ok: false, error: "This account is suspended. Contact the firm owner." };
  }

  // Transparent upgrade if an older hash scheme was stored.
  if (needsRehash(user.passwordHash)) {
    const salt = newSalt();
    await db
      .update(users)
      .set({ passwordHash: await hashPassword(password, salt), passwordSalt: salt })
      .where(eq(users.id, user.id));
  }

  await db.delete(sessions).where(and(eq(sessions.userId, user.id), lt(sessions.expiresAt, new Date())));
  const token = await createSession(user.id);
  await db.update(users).set({ lastLoginAt: new Date() }).where(eq(users.id, user.id));
  await db.insert(authEvents).values({ identifier, userId: user.id, kind: "success", ip: meta.ip, userAgent: meta.userAgent });
  await db.insert(auditLog).values({
    userId: user.id,
    actorName: user.name,
    action: "Signed in",
    entity: "User",
    entityRef: user.username,
    summary: "Workspace session started (8-hour sliding session).",
    ip: meta.ip,
  });
  return { ok: true, token };
}

export type ResetRequestResult = { ok: true; resetUrl: string; expiresAt: Date } | { ok: false; error: string };

/**
 * Creates a single-use password reset token. The workspace has no outbound mail
 * in preview, so the short-lived link is returned to the requester and also
 * written to the audit trail.
 */
export async function requestPasswordReset(identifierInput: string): Promise<ResetRequestResult> {
  const identifier = identifierInput.trim().toLowerCase();
  if (!identifier) return { ok: false, error: "Enter your username or email address." };
  const found = await db
    .select()
    .from(users)
    .where(sql`lower(${users.username}) = ${identifier} or lower(${users.email}) = ${identifier}`)
    .limit(1);
  const user = found[0];
  if (!user) return { ok: false, error: "No workspace account matches that username or email." };

  const token = randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + RESET_TTL_MS);
  await db.delete(passwordResets).where(and(eq(passwordResets.userId, user.id), isNull(passwordResets.usedAt)));
  await db.insert(passwordResets).values({ id: sha256(token), userId: user.id, expiresAt });
  const meta = await requestMeta();
  await db.insert(auditLog).values({
    userId: user.id,
    actorName: user.name,
    action: "Password reset requested",
    entity: "User",
    entityRef: user.username,
    summary: "Single-use reset link generated (valid for 30 minutes).",
    ip: meta.ip,
  });
  return { ok: true, resetUrl: `/reset-password?token=${token}`, expiresAt };
}

export async function resetPasswordWithToken(
  token: string,
  newPassword: string,
  confirmPassword: string,
): Promise<{ ok: true } | { ok: false; error: string }> {
  if (!token) return { ok: false, error: "This reset link is incomplete. Request a new one." };
  if (newPassword !== confirmPassword) return { ok: false, error: "The two passwords do not match." };
  const policyError = passwordPolicyError(newPassword);
  if (policyError) return { ok: false, error: policyError };

  const rows = await db
    .select({ reset: passwordResets, user: users })
    .from(passwordResets)
    .innerJoin(users, eq(users.id, passwordResets.userId))
    .where(eq(passwordResets.id, sha256(token)))
    .limit(1);
  const row = rows[0];
  if (!row) return { ok: false, error: "This reset link is invalid. Request a new one." };
  if (row.reset.usedAt) return { ok: false, error: "This reset link has already been used." };
  if (row.reset.expiresAt.getTime() < Date.now()) return { ok: false, error: "This reset link has expired. Request a new one." };

  const salt = newSalt();
  const passwordHash = await hashPassword(newPassword, salt);
  await db.transaction(async (tx) => {
    await tx.update(users).set({ passwordHash, passwordSalt: salt }).where(eq(users.id, row.user.id));
    await tx.update(passwordResets).set({ usedAt: new Date() }).where(eq(passwordResets.id, row.reset.id));
    await tx.delete(sessions).where(eq(sessions.userId, row.user.id));
    await tx.insert(auditLog).values({
      userId: row.user.id,
      actorName: row.user.name,
      action: "Password reset completed",
      entity: "User",
      entityRef: row.user.username,
      summary: "Password rotated with a single-use token; all sessions revoked.",
    });
  });
  return { ok: true };
}

export async function changePassword(
  user: SessionUser,
  currentPassword: string,
  newPassword: string,
  confirmPassword: string,
): Promise<{ ok: true } | { ok: false; error: string }> {
  if (newPassword !== confirmPassword) return { ok: false, error: "The new passwords do not match." };
  const policyError = passwordPolicyError(newPassword);
  if (policyError) return { ok: false, error: policyError };
  const rows = await db.select().from(users).where(eq(users.id, user.id)).limit(1);
  const row = rows[0];
  if (!row) return { ok: false, error: "Account not found." };
  const valid = await verifyPassword(currentPassword, row.passwordSalt, row.passwordHash);
  if (!valid) return { ok: false, error: "Your current password is incorrect." };
  const salt = newSalt();
  await db
    .update(users)
    .set({ passwordHash: await hashPassword(newPassword, salt), passwordSalt: salt })
    .where(eq(users.id, user.id));
  await db.insert(auditLog).values({
    userId: user.id,
    actorName: user.name,
    action: "Password changed",
    entity: "User",
    entityRef: user.username,
    summary: "Credential rotated from workspace settings.",
  });
  return { ok: true };
}

export async function audit(
  user: { id: number; name: string },
  action: string,
  entity: string,
  entityRef: string,
  summary: string,
): Promise<void> {
  const meta = await requestMeta();
  await db.insert(auditLog).values({
    userId: user.id,
    actorName: user.name,
    action,
    entity,
    entityRef,
    summary,
    ip: meta.ip,
  });
}

export async function activeSessionsFor(userId: number) {
  return db
    .select()
    .from(sessions)
    .where(and(eq(sessions.userId, userId), gt(sessions.expiresAt, new Date())))
    .orderBy(desc(sessions.lastSeenAt));
}

/** Auditors hold a read-only seat; every mutation goes through this guard. */
export async function requireWriter(): Promise<SessionUser> {
  const user = await requireUser();
  if (user.role === "auditor") {
    redirect("/dashboard?error=Your+auditor+seat+is+read-only.+Ask+the+firm+owner+for+write+access.");
  }
  return user;
}
