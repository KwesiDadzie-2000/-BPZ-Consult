import "server-only";
import { sql } from "drizzle-orm";
import { db } from "@/db";
import {
  accounts,
  auditLog,
  bankAccounts,
  clients,
  employees,
  expenses,
  invoices,
  payrollRuns,
  users,
} from "@/db/schema";
import { hashPassword, newSalt } from "./password";
import { ensureSchema } from "./bootstrap";
import { AR_ACCOUNT, AP_ACCOUNT, EXPENSE_ACCOUNTS, VAT_INPUT_ACCOUNT, VAT_OUTPUT_ACCOUNT, postJournal } from "./accounting";
import { computePayroll } from "./payroll";
import { addDays, round2 } from "./format";

export const SEED_CREDENTIALS = [
  { username: "owner", password: "BpzOwner2026!", name: "Kwesi Dadzie", role: "owner", jobTitle: "Managing Partner", email: "owner@bpzconsult.com" },
  { username: "ama", password: "BpzAma2026!", name: "Ama Mensah", role: "manager", jobTitle: "Audit Manager", email: "ama@bpzconsult.com" },
  { username: "kofi", password: "BpzKofi2026!", name: "Kofi Boateng", role: "accountant", jobTitle: "Senior Accountant", email: "kofi@bpzconsult.com" },
  { username: "auditor", password: "BpzAuditor2026!", name: "Esi Nyarko", role: "auditor", jobTitle: "External Auditor", email: "auditor@bpzconsult.com" },
] as const;

const CHART = [
  ["1010", "GCB Bank — Operating", "asset", "Cash & bank"],
  ["1020", "Ecobank — Payroll", "asset", "Cash & bank"],
  ["1030", "Fidelity Bank — Tax reserve", "asset", "Cash & bank"],
  ["1040", "Petty cash", "asset", "Cash & bank"],
  ["1100", "Accounts receivable", "asset", "Receivables"],
  ["1200", "VAT input recoverable", "asset", "Tax recoverable"],
  ["1300", "Prepayments", "asset", "Current assets"],
  ["1400", "Work in progress", "asset", "Current assets"],
  ["1500", "Property, plant & equipment", "asset", "Non-current assets"],
  ["1510", "Accumulated depreciation", "asset", "Non-current assets"],
  ["2000", "Accounts payable", "liability", "Payables"],
  ["2100", "VAT output payable", "liability", "Statutory"],
  ["2200", "PAYE payable", "liability", "Statutory"],
  ["2210", "SSNIT payable", "liability", "Statutory"],
  ["2300", "Net pay payable", "liability", "Payroll"],
  ["2400", "Accruals", "liability", "Payables"],
  ["2500", "Bank loan — Stanbic", "liability", "Borrowings"],
  ["3000", "Share capital", "equity", "Equity"],
  ["3100", "Retained earnings", "equity", "Equity"],
  ["3900", "Current year earnings", "equity", "Equity"],
  ["4000", "Revenue — Advisory & consulting", "income", "Revenue"],
  ["4010", "Revenue — Audit & assurance", "income", "Revenue"],
  ["4020", "Revenue — Tax services", "income", "Revenue"],
  ["4030", "Revenue — Bookkeeping & payroll", "income", "Revenue"],
  ["4100", "Other income", "income", "Other income"],
  ["5000", "Salaries & wages", "expense", "People"],
  ["5010", "SSNIT employer contribution", "expense", "People"],
  ["5100", "Rent", "expense", "Operations"],
  ["5110", "Utilities", "expense", "Operations"],
  ["5120", "Professional fees", "expense", "Operations"],
  ["5130", "Marketing", "expense", "Growth"],
  ["5140", "Travel", "expense", "Operations"],
  ["5150", "Software subscriptions", "expense", "Technology"],
  ["5160", "Bank charges", "expense", "Finance"],
  ["5300", "Other expenses", "expense", "Operations"],
] as const;

const SEED_CLIENTS = [
  { code: "CLI-001", name: "Adansi Agro Processing Ltd", sector: "Agribusiness", contactName: "Nana Adjei", contactEmail: "finance@adansiagro.com", phone: "+233 24 512 8890", services: "Audit & assurance, Tax services", healthScore: 88, notes: "Year-end audit and GRA transfer pricing review." },
  { code: "CLI-002", name: "Volta Renewables Ghana Ltd", sector: "Renewable energy", contactName: "Akosua Frimpong", contactEmail: "akosua@voltarenewables.gh", phone: "+233 30 274 1188", services: "Advisory & consulting, Bookkeeping", healthScore: 76, notes: "Series B readiness, IFRS 9 modelling." },
  { code: "CLI-003", name: "Sankofa Logistics Ltd", sector: "Transport & logistics", contactName: "Yaw Antwi", contactEmail: "yaw@sankofalogistics.com", phone: "+233 27 880 3344", services: "Tax services, Payroll", healthScore: 64, notes: "VAT health check outstanding; monthly payroll." },
  { code: "CLI-004", name: "Golden Harvest Foods", sector: "FMCG manufacturing", contactName: "Abena Osei", contactEmail: "abena@goldenharvest.gh", phone: "+233 31 202 7788", services: "Audit & assurance", healthScore: 91, notes: "Group consolidation and inventory costing." },
  { code: "CLI-005", name: "Nkabom Health Partners", sector: "Healthcare", contactName: "Dr. Selorm Agbeko", contactEmail: "selorm@nkabomhealth.com", phone: "+233 24 119 5566", services: "Bookkeeping & payroll, Advisory", healthScore: 72, notes: "NHIA receivables ageing needs review." },
  { code: "CLI-006", name: "Coastal Homes Ltd", sector: "Real estate", contactName: "Mavis Quaye", contactEmail: "mavis@coastalhomes.gh", phone: "+233 26 445 9087", services: "Advisory & consulting", healthScore: 58, notes: "Onboarding: structuring phase 2 financing." },
];

const BANKS = [
  { name: "GCB Bank — Operating", bankName: "GCB Bank PLC", accountNo: "1204-3700-1188", glAccount: "1010", kind: "bank", openedBalance: 110_000 },
  { name: "Ecobank — Payroll", bankName: "Ecobank Ghana", accountNo: "0055-2288-9110", glAccount: "1020", kind: "bank", openedBalance: 120_000 },
  { name: "Fidelity — Tax reserve", bankName: "Fidelity Bank", accountNo: "1144-8890-2233", glAccount: "1030", kind: "bank", openedBalance: 65_000 },
  { name: "Petty cash", bankName: "Office float", accountNo: "CASH-001", glAccount: "1040", kind: "cash", openedBalance: 3_200 },
];

const SEED_INVOICES: Array<{
  clientIndex: number;
  stream: string;
  net: number;
  monthOffset: number;
  day: number;
  paid: "full" | "part" | "none";
  draft?: boolean;
}> = [
  { clientIndex: 0, stream: "Audit & assurance", net: 48_000, monthOffset: 0, day: 4, paid: "none" },
  { clientIndex: 1, stream: "Advisory & consulting", net: 96_500, monthOffset: 0, day: 6, paid: "part" },
  { clientIndex: 4, stream: "Bookkeeping & payroll", net: 21_500, monthOffset: 0, day: 9, paid: "none" },
  { clientIndex: 2, stream: "Tax services", net: 18_750, monthOffset: 1, day: 12, paid: "full" },
  { clientIndex: 3, stream: "Audit & assurance", net: 132_000, monthOffset: 1, day: 18, paid: "part" },
  { clientIndex: 5, stream: "Advisory & consulting", net: 42_000, monthOffset: 1, day: 22, paid: "full" },
  { clientIndex: 0, stream: "Tax services", net: 15_000, monthOffset: 2, day: 7, paid: "full" },
  { clientIndex: 1, stream: "Bookkeeping & payroll", net: 19_200, monthOffset: 2, day: 15, paid: "full" },
  { clientIndex: 4, stream: "Advisory & consulting", net: 64_000, monthOffset: 2, day: 24, paid: "part" },
  { clientIndex: 3, stream: "Tax services", net: 27_500, monthOffset: 3, day: 10, paid: "full" },
  { clientIndex: 2, stream: "Bookkeeping & payroll", net: 17_800, monthOffset: 3, day: 19, paid: "none" },
  { clientIndex: 5, stream: "Advisory & consulting", net: 88_000, monthOffset: 3, day: 26, paid: "part" },
  { clientIndex: 0, stream: "Audit & assurance", net: 45_000, monthOffset: 4, day: 8, paid: "full" },
  { clientIndex: 1, stream: "Advisory & consulting", net: 112_000, monthOffset: 4, day: 17, paid: "full" },
  { clientIndex: 4, stream: "Bookkeeping & payroll", net: 23_000, monthOffset: 5, day: 5, paid: "full" },
  { clientIndex: 3, stream: "Advisory & consulting", net: 57_000, monthOffset: 0, day: 12, paid: "none", draft: true },
];

const SEED_EXPENSES = [
  { vendor: "Graphic Business", category: "Marketing", net: 4_800, monthOffset: 0, day: 3, vat: true, paid: true, clientIndex: null },
  { vendor: "MTN Business", category: "Utilities", net: 2_400, monthOffset: 0, day: 5, vat: true, paid: true, clientIndex: null },
  { vendor: "Hubtel", category: "Software subscriptions", net: 1_850, monthOffset: 0, day: 7, vat: true, paid: false, clientIndex: null },
  { vendor: "British Council Ghana", category: "Professional fees", net: 9_200, monthOffset: 0, day: 9, vat: false, paid: false, clientIndex: 1 },
  { vendor: "Kotoka Travel", category: "Travel", net: 6_400, monthOffset: 1, day: 11, vat: true, paid: true, clientIndex: 0 },
  { vendor: "Landlord — Ridge Towers", category: "Rent", net: 26_000, monthOffset: 1, day: 1, vat: false, paid: true, clientIndex: null },
  { vendor: "KPMG Ghana", category: "Professional fees", net: 15_500, monthOffset: 1, day: 20, vat: true, paid: true, clientIndex: 4 },
  { vendor: "GCB Bank PLC", category: "Bank charges", net: 640, monthOffset: 2, day: 28, vat: false, paid: true, clientIndex: null },
  { vendor: "Adobe Systems", category: "Software subscriptions", net: 3_250, monthOffset: 2, day: 6, vat: true, paid: true, clientIndex: null },
  { vendor: "Landlord — Ridge Towers", category: "Rent", net: 26_000, monthOffset: 3, day: 1, vat: false, paid: true, clientIndex: null },
  { vendor: "Enterprise Insurance", category: "Other expenses", net: 7_800, monthOffset: 3, day: 16, vat: false, paid: true, clientIndex: null },
  { vendor: "Ghana Water Company", category: "Utilities", net: 1_150, monthOffset: 4, day: 12, vat: true, paid: true, clientIndex: null },
  { vendor: "Landlord — Ridge Towers", category: "Rent", net: 24_000, monthOffset: 4, day: 1, vat: false, paid: true, clientIndex: null },
  { vendor: "Bolt Business", category: "Travel", net: 980, monthOffset: 0, day: 14, vat: true, paid: false, clientIndex: 2 },
];

const SEED_EMPLOYEES = [
  { staffNo: "BPZ-001", name: "Kwesi Dadzie", role: "Managing Partner", department: "Leadership", basicSalary: 28_000, allowances: 4_500, ssnitNo: "SSNIT-889231", tin: "C0011223345" },
  { staffNo: "BPZ-002", name: "Ama Mensah", role: "Audit Manager", department: "Assurance", basicSalary: 16_500, allowances: 2_200, ssnitNo: "SSNIT-772109", tin: "C0022334456" },
  { staffNo: "BPZ-003", name: "Kofi Boateng", role: "Senior Accountant", department: "Accounting", basicSalary: 11_200, allowances: 1_500, ssnitNo: "SSNIT-661087", tin: "C0033445567" },
  { staffNo: "BPZ-004", name: "Naana Asante", role: "Tax Consultant", department: "Tax", basicSalary: 9_800, allowances: 1_200, ssnitNo: "SSNIT-554321", tin: "C0044556678" },
  { staffNo: "BPZ-005", name: "Ibrahim Musah", role: "Assurance Associate", department: "Assurance", basicSalary: 6_500, allowances: 800, ssnitNo: "SSNIT-443210", tin: "C0055667789" },
];

function isoDate(monthOffset: number, day: number): string {
  const now = new Date();
  const date = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - monthOffset, Math.min(day, 28)));
  return date.toISOString().slice(0, 10);
}

let seedPromise: Promise<void> | null = null;

/** Idempotent bootstrap: safe to call from every public page. */
export async function ensureSeed(): Promise<void> {
  if (!seedPromise) {
    seedPromise = ensureSchema()
      .then(() => runSeed())
      .catch((error) => {
        seedPromise = null;
        throw error;
      });
  }
  return seedPromise;
}

async function runSeed(): Promise<void> {
  const existing = await db.select({ count: sql<number>`count(*)::int` }).from(users);
  if ((existing[0]?.count ?? 0) > 0) return;

  // 1. Accounts and people
  for (const person of SEED_CREDENTIALS) {
    const salt = newSalt();
    await db
      .insert(users)
      .values({
        username: person.username,
        email: person.email,
        name: person.name,
        role: person.role,
        jobTitle: person.jobTitle,
        passwordHash: await hashPassword(person.password, salt),
        passwordSalt: salt,
      })
      .onConflictDoNothing();
  }

  await db.insert(accounts).values(CHART.map(([accountNo, name, type, category]) => ({ accountNo, name, type, category }))).onConflictDoNothing();
  const clientRows = await db.insert(clients).values(SEED_CLIENTS.map((client) => ({ ...client, status: "active" }))).returning();
  await db.insert(bankAccounts).values(BANKS);
  const employeeRows = await db
    .insert(employees)
    .values(SEED_EMPLOYEES.map((person) => ({ ...person, startDate: "2024-02-01", status: "active" })))
    .returning();
  const owner = (await db.select().from(users).limit(1))[0];
  const createdBy = owner?.id ?? null;

  // 2. Opening balances — one balanced journal behind every bank balance.
  const openingTotal = round2(BANKS.reduce((sum, bank) => sum + bank.openedBalance, 0));
  await postJournal(db, {
    docNo: `OB-${new Date().getFullYear()}-0001`,
    date: `${new Date().getFullYear()}-01-02`,
    module: "Manual",
    description: "Opening balances brought forward",
    createdBy,
    lines: [
      ...BANKS.map((bank) => ({ accountNo: bank.glAccount, debit: bank.openedBalance, description: `Opening balance — ${bank.name}` })),
      { accountNo: "3000", credit: openingTotal, description: "Share capital brought forward" },
    ],
  });

  // 3. Sales invoices with their receivables journals and cash receipts.
  const invoiceValues = SEED_INVOICES.map((invoice, index) => {
    const net = invoice.net;
    const vat = round2(net * 0.15);
    const total = round2(net + vat);
    const paid = invoice.paid === "full" ? total : invoice.paid === "part" ? round2(total * 0.4) : 0;
    const issueDate = isoDate(invoice.monthOffset, invoice.day);
    const dueDate = addDays(issueDate, 21);
    const status = invoice.draft ? "draft" : paid >= total ? "paid" : paid > 0 ? "partial" : new Date(`${dueDate}T23:59:59Z`).getTime() < Date.now() ? "overdue" : "sent";
    return {
      invoiceNo: `INV-${new Date().getFullYear()}-${String(index + 1).padStart(4, "0")}`,
      clientId: clientRows[invoice.clientIndex]?.id ?? null,
      customerName: clientRows[invoice.clientIndex]?.name ?? "Walk-in client",
      revenueStream: invoice.stream,
      netRevenue: net,
      vatRate: 15,
      vatAmount: vat,
      totalAmount: total,
      paidAmount: paid,
      status,
      issueDate,
      dueDate,
      notes: "Professional fees for the period. Payment by bank transfer or MoMo.",
      createdBy,
    };
  });
  const invoiceRows = await db.insert(invoices).values(invoiceValues).returning();

  for (const invoice of invoiceRows) {
    if (invoice.status === "draft") continue;
    const revenueMap: Record<string, string> = {
      "Advisory & consulting": "4000",
      "Audit & assurance": "4010",
      "Tax services": "4020",
      "Bookkeeping & payroll": "4030",
      "Other income": "4100",
    };
    await postJournal(db, {
      docNo: `INVJ-${invoice.invoiceNo}`,
      date: invoice.issueDate,
      module: "Sales",
      description: `Sales invoice ${invoice.invoiceNo} — ${invoice.customerName}`,
      clientId: invoice.clientId,
      createdBy,
      lines: [
        { accountNo: AR_ACCOUNT, debit: invoice.totalAmount, description: "Invoice receivable" },
        { accountNo: revenueMap[invoice.revenueStream] ?? "4000", credit: invoice.netRevenue, description: invoice.revenueStream },
        { accountNo: VAT_OUTPUT_ACCOUNT, credit: invoice.vatAmount, description: "VAT output (15%)" },
      ],
    });
    if (invoice.paidAmount > 0) {
      await postJournal(db, {
        docNo: `RCT-${invoice.invoiceNo}`,
        date: addDays(invoice.issueDate, 5),
        module: "Sales",
        description: `Receipt against ${invoice.invoiceNo}`,
        clientId: invoice.clientId,
        createdBy,
        lines: [
          { accountNo: "1010", debit: invoice.paidAmount, description: "Bank receipt" },
          { accountNo: AR_ACCOUNT, credit: invoice.paidAmount, description: "Receivable settled" },
        ],
      });
    }
  }

  // 4. Operating expenses and supplier payments.
  const expenseValues = SEED_EXPENSES.map((expense, index) => {
    const net = expense.net;
    const vat = expense.vat ? round2(net * 0.15) : 0;
    const total = round2(net + vat);
    const expenseDate = isoDate(expense.monthOffset, expense.day);
    return {
      reference: `EXP-${new Date().getFullYear()}-${String(index + 1).padStart(4, "0")}`,
      clientId: expense.clientIndex == null ? null : clientRows[expense.clientIndex]?.id ?? null,
      vendor: expense.vendor,
      category: expense.category,
      description: `${expense.category} — ${expense.vendor}`,
      netAmount: net,
      vatAmount: vat,
      totalAmount: total,
      paidAmount: expense.paid ? total : 0,
      status: expense.paid ? "paid" : "approved",
      expenseDate,
      dueDate: addDays(expenseDate, 30),
      glAccount: EXPENSE_ACCOUNTS[expense.category] ?? "5300",
      createdBy,
    };
  });
  const expenseRows = await db.insert(expenses).values(expenseValues).returning();

  for (const expense of expenseRows) {
    await postJournal(db, {
      docNo: `EXPJ-${expense.reference}`,
      date: expense.expenseDate,
      module: "Expenses",
      description: `${expense.vendor} — ${expense.category}`,
      clientId: expense.clientId,
      createdBy,
      lines: [
        { accountNo: expense.glAccount, debit: expense.netAmount, description: expense.category },
        ...(expense.vatAmount > 0 ? [{ accountNo: VAT_INPUT_ACCOUNT, debit: expense.vatAmount, description: "VAT input" }] : []),
        { accountNo: AP_ACCOUNT, credit: expense.totalAmount, description: "Supplier payable" },
      ],
    });
    if (expense.paidAmount > 0) {
      await postJournal(db, {
        docNo: `PMT-${expense.reference}`,
        date: addDays(expense.expenseDate, 3),
        module: "Banking",
        description: `Payment to ${expense.vendor}`,
        clientId: expense.clientId,
        createdBy,
        lines: [
          { accountNo: AP_ACCOUNT, debit: expense.paidAmount, description: "Payable settled" },
          { accountNo: "1010", credit: expense.paidAmount, description: "Bank payment" },
        ],
      });
    }
  }

  // 5. One approved payroll run for the previous month, fully posted.
  const payroll = computePayroll(employeeRows);
  const payrollPeriod = isoDate(1, 1).slice(0, 7);
  const [run] = await db
    .insert(payrollRuns)
    .values({
      period: payrollPeriod,
      status: "approved",
      gross: payroll.gross,
      paye: payroll.paye,
      ssnitEmployee: payroll.ssnitEmployee,
      ssnitEmployer: payroll.ssnitEmployer,
      netPay: payroll.netPay,
      headcount: payroll.headcount,
      lines: payroll.lines,
      createdBy,
    })
    .returning();
  if (run) {
    await postJournal(db, {
      docNo: `PAY-${payrollPeriod}`,
      date: `${payrollPeriod}-28`,
      module: "Payroll",
      description: `Payroll run for ${payrollPeriod}`,
      createdBy,
      lines: [
        { accountNo: "5000", debit: payroll.gross, description: "Gross salaries" },
        { accountNo: "5010", debit: payroll.ssnitEmployer, description: "SSNIT employer 13%" },
        { accountNo: "2200", credit: payroll.paye, description: "PAYE withheld" },
        { accountNo: "2210", credit: round2(payroll.ssnitEmployee + payroll.ssnitEmployer), description: "SSNIT employee + employer" },
        { accountNo: "2300", credit: payroll.netPay, description: "Net pay due to staff" },
      ],
    });
    await postJournal(db, {
      docNo: `PAYPAY-${payrollPeriod}`,
      date: `${payrollPeriod}-28`,
      module: "Payroll",
      description: `Net salaries disbursed for ${payrollPeriod}`,
      createdBy,
      lines: [
        { accountNo: "2300", debit: payroll.netPay, description: "Net pay settled" },
        { accountNo: "1020", credit: payroll.netPay, description: "Payroll bank account" },
      ],
    });
  }

  await db.insert(auditLog).values([
    {
      userId: createdBy,
      actorName: "System",
      action: "Workspace provisioned",
      entity: "System",
      entityRef: "BPZ-CONSULT",
      summary: "Chart of accounts, opening balances and demo transactions loaded.",
    },
    {
      userId: createdBy,
      actorName: owner?.name ?? "Kwesi Dadzie",
      action: "Credentials rotated",
      entity: "Security",
      entityRef: "owner",
      summary: "Server-side scrypt credentials provisioned for the workspace team.",
      ip: "local",
    },
  ]);

}


/**
 * Entry-point safe wrapper: a database hiccup must never replace the sign-in
 * screen with an error page. Failures are logged and surfaced in the UI instead.
 */
export async function safeEnsureSeed(): Promise<{ ok: true } | { ok: false; error: string }> {
  try {
    await ensureSeed();
    return { ok: true };
  } catch (error) {
    console.error("Database bootstrap failed", error);
    return {
      ok: false,
      error:
        "The workspace database is not reachable right now. Sign-in is temporarily unavailable — retry in a moment or contact the administrator.",
    };
  }
}
