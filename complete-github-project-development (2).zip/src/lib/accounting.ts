import { and, desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { accounts, bankAccounts, journals, journalLines, invoices, expenses, clients, employees } from "@/db/schema";
import { round2 } from "./format";

export type LedgerLineInput = {
  accountNo: string;
  debit?: number;
  credit?: number;
  description?: string;
};

export const REVENUE_ACCOUNTS: Record<string, string> = {
  "Advisory & consulting": "4000",
  "Audit & assurance": "4010",
  "Tax services": "4020",
  "Bookkeeping & payroll": "4030",
  "Other income": "4100",
};

export const EXPENSE_ACCOUNTS: Record<string, string> = {
  "Salaries & wages": "5000",
  Rent: "5100",
  Utilities: "5110",
  "Professional fees": "5120",
  Marketing: "5130",
  Travel: "5140",
  "Software subscriptions": "5150",
  "Bank charges": "5160",
  "Other expenses": "5300",
};

export const AR_ACCOUNT = "1100";
export const VAT_INPUT_ACCOUNT = "1200";
export const AP_ACCOUNT = "2000";
export const VAT_OUTPUT_ACCOUNT = "2100";
export const PAYE_ACCOUNT = "2200";
export const SSNIT_ACCOUNT = "2210";
export const NET_PAY_ACCOUNT = "2300";
export const DEFAULT_BANK_ACCOUNT = "1010";

export type DbExecutor = Pick<typeof db, "select" | "insert" | "update" | "delete">;

export function journalTotals(lines: Array<{ debit: number | string; credit: number | string }>) {
  const debit = round2(lines.reduce((sum, line) => sum + Number(line.debit || 0), 0));
  const credit = round2(lines.reduce((sum, line) => sum + Number(line.credit || 0), 0));
  return { debit, credit, balanced: Math.abs(debit - credit) < 0.005 };
}

/**
 * Writes a balanced journal with its lines. The entry is rejected when the
 * debits and credits do not agree, so the ledger can never be corrupted.
 */
export async function postJournal(
  executor: DbExecutor,
  input: {
    docNo: string;
    date: string;
    module: string;
    description: string;
    clientId?: number | null;
    createdBy?: number | null;
    lines: LedgerLineInput[];
  },
): Promise<{ journalId: number | null; error?: string }> {
  const cleaned = input.lines
    .map((line) => ({
      accountNo: line.accountNo,
      debit: round2(Number(line.debit || 0)),
      credit: round2(Number(line.credit || 0)),
      description: line.description ?? input.description,
    }))
    .filter((line) => line.debit !== 0 || line.credit !== 0);

  if (cleaned.length < 2) return { journalId: null, error: "A journal needs at least two lines." };
  const totals = journalTotals(cleaned);
  if (!totals.balanced) {
    return { journalId: null, error: `Journal is out of balance by GHS ${Math.abs(totals.debit - totals.credit).toFixed(2)}.` };
  }

  const chart = await executor.select().from(accounts);
  const lookup = new Map(chart.map((account) => [account.accountNo, account.name]));
  const unknown = cleaned.find((line) => !lookup.has(line.accountNo));
  if (unknown) return { journalId: null, error: `Unknown ledger account ${unknown.accountNo}.` };

  const inserted = await executor
    .insert(journals)
    .values({
      docNo: input.docNo,
      journalDate: input.date,
      module: input.module,
      description: input.description,
      clientId: input.clientId ?? null,
      createdBy: input.createdBy ?? null,
      status: "posted",
    })
    .returning({ id: journals.id });
  const journalId = inserted[0]?.id ?? null;
  if (!journalId) return { journalId: null, error: "Could not create the journal." };

  await executor.insert(journalLines).values(
    cleaned.map((line) => ({
      journalId,
      accountNo: line.accountNo,
      accountName: lookup.get(line.accountNo) ?? line.accountNo,
      description: line.description,
      debit: line.debit,
      credit: line.credit,
    })),
  );
  return { journalId };
}

export async function nextDocumentNumber(prefix: string, table: "invoices" | "expenses" | "journals"): Promise<string> {
  const year = new Date().getFullYear();
  const source = table === "invoices" ? invoices : table === "expenses" ? expenses : journals;
  const rows = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(source)
    .where(sql`${source.id} > 0`);
  const seq = (rows[0]?.count ?? 0) + 1;
  return `${prefix}-${year}-${String(seq).padStart(4, "0")}`;
}

export type AccountBalance = {
  accountNo: string;
  name: string;
  type: string;
  category: string;
  debit: number;
  credit: number;
  balance: number;
};

/** Signed balance: debit-positive for assets/expenses, credit-positive for the rest. */
export async function accountBalances(): Promise<AccountBalance[]> {
  const rows = await db
    .select({
      accountNo: accounts.accountNo,
      name: accounts.name,
      type: accounts.type,
      category: accounts.category,
      debit: sql<number>`coalesce(sum(${journalLines.debit}), 0)::float`,
      credit: sql<number>`coalesce(sum(${journalLines.credit}), 0)::float`,
    })
    .from(accounts)
    .leftJoin(journalLines, eq(journalLines.accountNo, accounts.accountNo))
    .leftJoin(journals, and(eq(journals.id, journalLines.journalId), eq(journals.status, "posted")))
    .groupBy(accounts.accountNo, accounts.name, accounts.type, accounts.category)
    .orderBy(accounts.accountNo);

  return rows.map((row) => {
    const normalDebit = row.type === "asset" || row.type === "expense";
    const net = round2(row.debit - row.credit);
    return {
      accountNo: row.accountNo,
      name: row.name,
      type: row.type,
      category: row.category,
      debit: round2(row.debit),
      credit: round2(row.credit),
      balance: normalDebit ? net : round2(-net),
    };
  });
}

export type FinancialStatements = {
  balances: AccountBalance[];
  trialDebit: number;
  trialCredit: number;
  balanced: boolean;
  income: AccountBalance[];
  expenses: AccountBalance[];
  assets: AccountBalance[];
  liabilities: AccountBalance[];
  equity: AccountBalance[];
  totalIncome: number;
  totalExpenses: number;
  netProfit: number;
  totalAssets: number;
  totalLiabilities: number;
  totalEquity: number;
};

export async function financialStatements(): Promise<FinancialStatements> {
  const balances = await accountBalances();
  const byType = (type: string) => balances.filter((row) => row.type === type && Math.abs(row.balance) > 0.004);
  const income = byType("income");
  const expense = byType("expense");
  const asset = byType("asset");
  const liability = byType("liability");
  const equity = byType("equity");
  const totalIncome = round2(income.reduce((sum, row) => sum + row.balance, 0));
  const totalExpenses = round2(expense.reduce((sum, row) => sum + row.balance, 0));
  const netProfit = round2(totalIncome - totalExpenses);
  const totalAssets = round2(asset.reduce((sum, row) => sum + row.balance, 0));
  const totalLiabilities = round2(liability.reduce((sum, row) => sum + row.balance, 0));
  // Retained profit is presented inside equity so the statement balances.
  const equityWithProfit = [...equity, {
    accountNo: "3900",
    name: "Retained earnings (current period)",
    type: "equity",
    category: "Equity",
    debit: 0,
    credit: 0,
    balance: netProfit,
  }];
  const totalEquity = round2(equityWithProfit.reduce((sum, row) => sum + row.balance, 0));
  const trialDebit = round2(balances.reduce((sum, row) => sum + row.debit, 0));
  const trialCredit = round2(balances.reduce((sum, row) => sum + row.credit, 0));

  return {
    balances,
    trialDebit,
    trialCredit,
    balanced: Math.abs(trialDebit - trialCredit) < 0.005,
    income,
    expenses: expense,
    assets: asset,
    liabilities: liability,
    equity: equityWithProfit,
    totalIncome,
    totalExpenses,
    netProfit,
    totalAssets,
    totalLiabilities,
    totalEquity,
  };
}

export type MonthlyPoint = { key: string; income: number; expense: number };

export async function monthlySeries(months = 6): Promise<MonthlyPoint[]> {
  const rows = await db
    .select({
      month: sql<string>`to_char(${journals.journalDate}, 'YYYY-MM')`,
      income: sql<number>`coalesce(sum(case when ${accounts.type} = 'income' then ${journalLines.credit} - ${journalLines.debit} else 0 end), 0)::float`,
      expense: sql<number>`coalesce(sum(case when ${accounts.type} = 'expense' then ${journalLines.debit} - ${journalLines.credit} else 0 end), 0)::float`,
    })
    .from(journals)
    .innerJoin(journalLines, eq(journalLines.journalId, journals.id))
    .innerJoin(accounts, eq(accounts.accountNo, journalLines.accountNo))
    .where(eq(journals.status, "posted"))
    .groupBy(sql`to_char(${journals.journalDate}, 'YYYY-MM')`);

  const map = new Map(rows.map((row) => [row.month, row]));
  const series: MonthlyPoint[] = [];
  const now = new Date();
  for (let index = months - 1; index >= 0; index -= 1) {
    const date = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - index, 1));
    const key = `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, "0")}`;
    const row = map.get(key);
    series.push({ key, income: round2(row?.income ?? 0), expense: round2(row?.expense ?? 0) });
  }
  return series;
}

export type DashboardData = Awaited<ReturnType<typeof dashboardData>>;

export async function dashboardData() {
  const emptySeries = () => {
    const series: MonthlyPoint[] = [];
    const now = new Date();
    for (let index = 5; index >= 0; index -= 1) {
      const date = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - index, 1));
      const key = `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, "0")}`;
      series.push({ key, income: 0, expense: 0 });
    }
    return series;
  };

  let statements: FinancialStatements;
  try {
    statements = await financialStatements();
  } catch (error) {
    console.error("financialStatements failed", error);
    statements = {
      balances: [],
      trialDebit: 0,
      trialCredit: 0,
      balanced: true,
      income: [],
      expenses: [],
      assets: [],
      liabilities: [],
      equity: [],
      totalIncome: 0,
      totalExpenses: 0,
      netProfit: 0,
      totalAssets: 0,
      totalLiabilities: 0,
      totalEquity: 0,
    };
  }

  const [series, bankRows, invoiceRows, expenseRows, recentJournals, clientRows, payrollRows] = await Promise.all([
    monthlySeries(6).catch((error) => {
      console.error("monthlySeries failed", error);
      return emptySeries();
    }),
    db.select().from(bankAccounts).orderBy(bankAccounts.id).catch(() => []),
    db.select().from(invoices).orderBy(desc(invoices.issueDate)).catch(() => []),
    db.select().from(expenses).orderBy(desc(expenses.expenseDate)).catch(() => []),
    db
      .select({
        id: journals.id,
        docNo: journals.docNo,
        date: journals.journalDate,
        module: journals.module,
        description: journals.description,
      })
      .from(journals)
      .where(eq(journals.status, "posted"))
      .orderBy(desc(journals.journalDate), desc(journals.id))
      .limit(7)
      .catch(() => []),
    db.select().from(clients).catch(() => []),
    db.select({ count: sql<number>`count(*)::int` }).from(employees).where(eq(employees.status, "active")).catch(() => [{ count: 0 }]),
  ]);

  const cashByGl = new Map(statements.assets.map((row) => [row.accountNo, row.balance]));
  const accountsWithCash = bankRows.map((account) => ({
    ...account,
    balance: round2((cashByGl.get(account.glAccount) ?? 0) || account.openedBalance),
  }));
  const cash = round2(accountsWithCash.reduce((sum, account) => sum + account.balance, 0));

  const receivable = round2(
    invoiceRows
      .filter((invoice) => invoice.status !== "draft" && invoice.status !== "paid")
      .reduce((sum, invoice) => sum + (invoice.totalAmount - invoice.paidAmount), 0),
  );
  const overdue = invoiceRows.filter((invoice) => {
    if (invoice.status === "paid" || invoice.status === "draft") return false;
    return new Date(`${invoice.dueDate}T23:59:59Z`).getTime() < Date.now();
  });
  const payable = round2(
    expenseRows
      .filter((expense) => expense.status !== "paid")
      .reduce((sum, expense) => sum + (expense.totalAmount - expense.paidAmount), 0),
  );
  const overdueTotal = round2(overdue.reduce((sum, invoice) => sum + (invoice.totalAmount - invoice.paidAmount), 0));
  const vatOutput = statements.balances.find((row) => row.accountNo === VAT_OUTPUT_ACCOUNT)?.balance ?? 0;
  const vatInput = statements.balances.find((row) => row.accountNo === VAT_INPUT_ACCOUNT)?.balance ?? 0;
  const paye = statements.balances.find((row) => row.accountNo === PAYE_ACCOUNT)?.balance ?? 0;
  const ssnit = statements.balances.find((row) => row.accountNo === SSNIT_ACCOUNT)?.balance ?? 0;

  const revenueByClient = new Map<number, number>();
  for (const invoice of invoiceRows) {
    if (invoice.clientId == null) continue;
    revenueByClient.set(invoice.clientId, round2((revenueByClient.get(invoice.clientId) ?? 0) + invoice.netRevenue));
  }
  const topClients = [...revenueByClient.entries()]
    .map(([id, revenue]) => ({ client: clientRows.find((row) => row.id === id), revenue }))
    .filter((row) => row.client)
    .sort((a, b) => b.revenue - a.revenue)
    .slice(0, 4);

  return {
    statements,
    series,
    cash,
    bankAccounts: accountsWithCash,
    invoiceRows,
    expenseRows,
    recentJournals,
    clients: clientRows,
    receivable,
    payable,
    overdue,
    overdueTotal,
    vatOutput,
    vatInput,
    vatNet: round2(vatOutput - vatInput),
    paye,
    ssnit,
    headcount: payrollRows[0]?.count ?? 0,
    topClients,
    currentMonth: series[series.length - 1],
  };
}
