import { round2 } from "./format";

/**
 * Ghana payroll calculation (GRA monthly PAYE bands + SSNIT contributions).
 * Rates live here so a future statutory change is a one-file edit.
 */
export const PAYE_BANDS = [
  { upTo: 490, rate: 0 },
  { upTo: 600, rate: 0.05 },
  { upTo: 730, rate: 0.1 },
  { upTo: 3896.67, rate: 0.175 },
  { upTo: 19896.67, rate: 0.25 },
  { upTo: 50416.67, rate: 0.3 },
  { upTo: Infinity, rate: 0.35 },
];

export const SSNIT_EMPLOYEE_RATE = 0.055;
export const SSNIT_EMPLOYER_RATE = 0.13;

export function monthlyPaye(taxableIncome: number): number {
  let remaining = Math.max(0, taxableIncome);
  let previous = 0;
  let tax = 0;
  for (const band of PAYE_BANDS) {
    if (remaining <= 0) break;
    const width = band.upTo - previous;
    const taxed = Math.min(remaining, width);
    tax += taxed * band.rate;
    remaining -= taxed;
    previous = band.upTo;
  }
  return round2(tax);
}

export type PayrollLine = {
  employeeId: number;
  staffNo: string;
  name: string;
  role: string;
  basicSalary: number;
  allowances: number;
  gross: number;
  ssnitEmployee: number;
  ssnitEmployer: number;
  taxableIncome: number;
  paye: number;
  netPay: number;
};

export type PayrollTotals = {
  gross: number;
  paye: number;
  ssnitEmployee: number;
  ssnitEmployer: number;
  netPay: number;
  headcount: number;
  lines: PayrollLine[];
};

export function computePayroll(
  staff: Array<{
    id: number;
    staffNo: string;
    name: string;
    role: string;
    basicSalary: number;
    allowances: number;
  }>,
): PayrollTotals {
  const lines = staff.map((person) => {
    const basic = round2(person.basicSalary);
    const allowances = round2(person.allowances);
    const gross = round2(basic + allowances);
    const ssnitEmployee = round2(basic * SSNIT_EMPLOYEE_RATE);
    const ssnitEmployer = round2(basic * SSNIT_EMPLOYER_RATE);
    const taxableIncome = Math.max(0, round2(gross - ssnitEmployee));
    const paye = monthlyPaye(taxableIncome);
    return {
      employeeId: person.id,
      staffNo: person.staffNo,
      name: person.name,
      role: person.role,
      basicSalary: basic,
      allowances,
      gross,
      ssnitEmployee,
      ssnitEmployer,
      taxableIncome,
      paye,
      netPay: round2(gross - ssnitEmployee - paye),
    };
  });

  return {
    lines,
    headcount: lines.length,
    gross: round2(lines.reduce((sum, line) => sum + line.gross, 0)),
    paye: round2(lines.reduce((sum, line) => sum + line.paye, 0)),
    ssnitEmployee: round2(lines.reduce((sum, line) => sum + line.ssnitEmployee, 0)),
    ssnitEmployer: round2(lines.reduce((sum, line) => sum + line.ssnitEmployer, 0)),
    netPay: round2(lines.reduce((sum, line) => sum + line.netPay, 0)),
  };
}
