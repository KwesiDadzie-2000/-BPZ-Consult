import { NextResponse, type NextRequest } from "next/server";

/**
 * Next.js 16 proxy.
 *
 * Keep it minimal: do not rewrite the session cookie on every request (that
 * caused SameSite / Secure mismatches behind the preview proxy). Authorisation
 * is enforced server-side against the database session row.
 */
export function proxy(request: NextRequest) {
  const response = NextResponse.next();
  response.headers.set("x-bpz-build", "v2.2");
  // Forward useful debug headers so server code can see the public host.
  const host = request.headers.get("x-forwarded-host") || request.headers.get("host");
  if (host) response.headers.set("x-bpz-host", host);
  return response;
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico|api/health).*)"],
};
