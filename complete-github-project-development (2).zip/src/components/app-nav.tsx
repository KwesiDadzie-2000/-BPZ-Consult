"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import {
  BarChart3,
  BookOpen,
  Building2,
  Calculator,
  LayoutDashboard,
  Menu,
  NotebookPen,
  ReceiptText,
  Settings,
  ShieldCheck,
  Users,
  Wallet,
  X,
} from "lucide-react";
import type { SessionUser } from "@/lib/auth";
import { Avatar, Logo, cx } from "./ui";
import { SignOutButton } from "./sign-out-button";

const GROUPS: Array<{ label: string; items: Array<{ href: string; label: string; icon: typeof LayoutDashboard; roles?: string[] }> }> = [
  {
    label: "Workspace",
    items: [
      { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
      { href: "/clients", label: "Clients", icon: Building2 },
    ],
  },
  {
    label: "Transactions",
    items: [
      { href: "/invoices", label: "Sales invoices", icon: ReceiptText },
      { href: "/expenses", label: "Expenses", icon: Wallet },
      { href: "/banking", label: "Banking & cash", icon: Building2 },
    ],
  },
  {
    label: "Accounting",
    items: [
      { href: "/journals", label: "Journal entries", icon: NotebookPen },
      { href: "/accounts", label: "Chart of accounts", icon: BookOpen },
      { href: "/payroll", label: "Payroll", icon: Calculator },
    ],
  },
  {
    label: "Insight",
    items: [
      { href: "/reports", label: "Financial reports", icon: BarChart3 },
      { href: "/team", label: "Team & access", icon: Users, roles: ["owner", "manager"] },
      { href: "/settings", label: "Settings", icon: Settings },
    ],
  },
];

export function AppNav({ user }: { user: SessionUser }) {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);

  const links = GROUPS.map((group) => ({
    ...group,
    items: group.items.filter((item) => !item.roles || item.roles.includes(user.role)),
  })).filter((group) => group.items.length > 0);

  return (
    <>
      <div className="sticky top-0 z-30 flex items-center justify-between gap-3 border-b border-line bg-white/90 px-4 py-2.5 backdrop-blur lg:hidden">
        <div className="flex items-center gap-2">
          <Logo size="sm" />
          <div>
            <p className="text-sm font-black leading-none text-navy">BPZ Consult</p>
            <p className="mt-0.5 text-[0.6rem] font-bold uppercase tracking-[0.12em] text-muted">Practice workspace</p>
          </div>
        </div>
        <button type="button" className="btn btn-ghost btn-sm" onClick={() => setOpen((value) => !value)} aria-label="Toggle navigation">
          {open ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
          Menu
        </button>
      </div>

      {open ? <button type="button" aria-label="Close navigation" className="fixed inset-0 z-30 bg-navy/40 lg:hidden" onClick={() => setOpen(false)} /> : null}

      <aside
        className={cx(
          "fixed inset-y-0 left-0 z-40 flex w-[264px] flex-col bg-navy text-white transition-transform lg:sticky lg:top-0 lg:h-screen lg:translate-x-0",
          open ? "translate-x-0" : "-translate-x-full",
        )}
      >
        <div className="flex items-center gap-3 px-5 pb-4 pt-5">
          <Logo />
          <div>
            <p className="text-[0.95rem] font-black leading-none tracking-tight">BPZ Consult</p>
            <p className="mt-1 text-[0.6rem] font-bold uppercase tracking-[0.16em] text-gold">Practice workspace</p>
          </div>
          <button type="button" className="ml-auto rounded p-1 text-white/60 hover:bg-white/10 lg:hidden" onClick={() => setOpen(false)} aria-label="Close">
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="mx-4 mb-3 rounded-xl border border-white/10 bg-white/5 px-3 py-2">
          <p className="flex items-center gap-1.5 text-[0.62rem] font-bold uppercase tracking-[0.12em] text-white/60">
            <ShieldCheck className="h-3 w-3 text-emerald-400" />
            Secure server session
          </p>
          <p className="mt-1 text-[0.7rem] font-semibold text-white/80">GHS reporting · Ghana statutory</p>
        </div>

        <nav className="flex-1 space-y-4 overflow-y-auto px-3 pb-4">
          {links.map((group) => (
            <div key={group.label}>
              <p className="px-2 pb-1.5 text-[0.58rem] font-extrabold uppercase tracking-[0.18em] text-white/35">{group.label}</p>
              <div className="space-y-0.5">
                {group.items.map((item) => {
                  const active = pathname === item.href || pathname.startsWith(`${item.href}/`);
                  const Icon = item.icon;
                  return (
                    <Link key={item.href} href={item.href} onClick={() => setOpen(false)} className={cx("nav-link", active && "nav-link-active")}>
                      <Icon className={cx("h-4 w-4", active ? "text-gold" : "text-white/60")} />
                      {item.label}
                    </Link>
                  );
                })}
              </div>
            </div>
          ))}
        </nav>

        <div className="border-t border-white/10 p-3">
          <div className="flex items-center gap-2.5 rounded-xl bg-white/5 px-2.5 py-2">
            <Avatar name={user.name} />
            <div className="min-w-0 flex-1">
              <p className="truncate text-[0.8rem] font-bold leading-tight">{user.name}</p>
              <p className="truncate text-[0.62rem] font-semibold uppercase tracking-wide text-gold/90">{user.jobTitle}</p>
            </div>
            <SignOutButton />
          </div>
          <p className="mt-2 px-1 text-[0.58rem] font-medium leading-relaxed text-white/40">
            Session renews automatically while you work · 8h TTL
          </p>
        </div>
      </aside>
    </>
  );
}
