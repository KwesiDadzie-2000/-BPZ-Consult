"use client";

import { useRouter } from "next/navigation";
import { useState, type ReactNode } from "react";
import { LogOut, Loader2 } from "lucide-react";

export function SignOutButton({
  className = "rounded p-1.5 text-white/60 transition hover:bg-white/10 hover:text-white",
  children,
  label = "Sign out",
}: {
  className?: string;
  children?: ReactNode;
  label?: string;
}) {
  const router = useRouter();
  const [pending, setPending] = useState(false);

  const onClick = async () => {
    if (pending) return;
    setPending(true);
    try {
      await fetch("/api/auth/logout", { method: "POST", credentials: "same-origin" });
    } catch {
      /* still bounce to login */
    }
    router.replace("/login?ok=You+have+been+signed+out+securely.");
    router.refresh();
  };

  return (
    <button type="button" onClick={onClick} disabled={pending} className={className} title={label} aria-label={label}>
      {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : children ? null : <LogOut className="h-4 w-4" />}
      {children ? (pending ? "Signing out…" : children) : className.includes("btn") ? <span>{pending ? "Signing out…" : label}</span> : null}
    </button>
  );
}
