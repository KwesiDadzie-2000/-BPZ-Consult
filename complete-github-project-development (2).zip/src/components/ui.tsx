import type { ReactNode } from "react";
import { AlertTriangle, ArrowDownRight, ArrowUpRight, CheckCircle2, ChevronDown, Info, Plus, ShieldCheck } from "lucide-react";
import { money } from "@/lib/format";

export function cx(...classes: Array<string | false | null | undefined>): string {
  return classes.filter(Boolean).join(" ");
}

export function Logo({ size = "md", tone = "gold" }: { size?: "sm" | "md" | "lg"; tone?: "gold" | "navy" }) {
  const dimensions = size === "lg" ? "h-14 w-14 text-lg rounded-2xl" : size === "sm" ? "h-8 w-8 text-[0.62rem] rounded-lg" : "h-11 w-11 text-sm rounded-xl";
  return (
    <span
      className={cx(
        "flex items-center justify-center font-black tracking-tight shadow-sm",
        dimensions,
        tone === "gold" ? "bg-gold text-navy-deep" : "bg-white/10 text-gold ring-1 ring-white/20",
      )}
      aria-hidden
    >
      BPZ
    </span>
  );
}

export function PageHeader({
  eyebrow,
  title,
  description,
  actions,
}: {
  eyebrow?: string;
  title: string;
  description?: string;
  actions?: ReactNode;
}) {
  return (
    <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
      <div>
        {eyebrow ? (
          <p className="text-[0.66rem] font-extrabold uppercase tracking-[0.16em] text-muted">{eyebrow}</p>
        ) : null}
        <h1 className="mt-1 text-[1.55rem] font-black leading-tight tracking-tight text-navy sm:text-[1.8rem]">{title}</h1>
        {description ? <p className="mt-1 max-w-2xl text-[0.83rem] font-medium text-muted">{description}</p> : null}
      </div>
      {actions ? <div className="flex flex-wrap items-center gap-2">{actions}</div> : null}
    </div>
  );
}

export function Card({
  children,
  className,
  padded = true,
}: {
  children: ReactNode;
  className?: string;
  padded?: boolean;
}) {
  return <section className={cx("card", padded && "p-5", className)}>{children}</section>;
}

export function CardHeader({ title, subtitle, action }: { title: string; subtitle?: string; action?: ReactNode }) {
  return (
    <div className="mb-4 flex items-start justify-between gap-3">
      <div>
        <h2 className="text-[0.95rem] font-extrabold tracking-tight text-navy">{title}</h2>
        {subtitle ? <p className="mt-0.5 text-[0.76rem] font-medium text-muted">{subtitle}</p> : null}
      </div>
      {action}
    </div>
  );
}

const toneClasses: Record<string, string> = {
  green: "pill-green",
  amber: "pill-amber",
  red: "pill-red",
  blue: "pill-blue",
  slate: "pill-slate",
  gold: "pill-gold",
};

export function Badge({ children, tone = "slate" }: { children: ReactNode; tone?: keyof typeof toneClasses }) {
  return <span className={cx("pill", toneClasses[tone] ?? "pill-slate")}>{children}</span>;
}

export function statusTone(status: string): keyof typeof toneClasses {
  switch (status.toLowerCase()) {
    case "paid":
    case "posted":
    case "active":
    case "approved":
      return "green";
    case "partial":
    case "sent":
    case "onboarding":
    case "manager":
      return "blue";
    case "pending":
    case "draft":
    case "on_leave":
      return "amber";
    case "overdue":
    case "reversed":
    case "suspended":
    case "dormant":
      return "red";
    default:
      return "slate";
  }
}

export function Alert({
  tone = "info",
  title,
  children,
}: {
  tone?: "info" | "success" | "warning" | "error";
  title?: string;
  children?: ReactNode;
}) {
  const map = {
    info: { style: "border-sky-200 bg-sky-50 text-sky-900", Icon: Info, iconClass: "text-sky-600" },
    success: { style: "border-emerald-200 bg-emerald-50 text-emerald-900", Icon: CheckCircle2, iconClass: "text-emerald-600" },
    warning: { style: "border-amber-300 bg-amber-50 text-amber-900", Icon: AlertTriangle, iconClass: "text-amber-600" },
    error: { style: "border-rose-300 bg-rose-50 text-rose-900", Icon: AlertTriangle, iconClass: "text-rose-600" },
  }[tone];
  return (
    <div className={cx("flex items-start gap-2 rounded-xl border px-3.5 py-2.5 text-[0.8rem] font-semibold", map.style)} role="status">
      <map.Icon className={cx("mt-0.5 h-4 w-4 shrink-0", map.iconClass)} />
      <div>
        {title ? <p className="font-extrabold">{title}</p> : null}
        {children ? <div className="font-medium leading-relaxed">{children}</div> : null}
      </div>
    </div>
  );
}

export function Flash({ ok, error }: { ok?: string; error?: string }) {
  if (!ok && !error) return null;
  return (
    <div className="space-y-2">
      {ok ? <Alert tone="success">{ok}</Alert> : null}
      {error ? <Alert tone="error">{error}</Alert> : null}
    </div>
  );
}

export function StatCard({
  label,
  value,
  sub,
  icon,
  trend,
  tone = "navy",
}: {
  label: string;
  value: string;
  sub?: ReactNode;
  icon?: ReactNode;
  trend?: { value: string; direction: "up" | "down" | "flat"; good?: boolean };
  tone?: "navy" | "gold" | "green" | "blue";
}) {
  const accents = {
    navy: "bg-navy text-white",
    gold: "bg-gold-soft text-[#7a5600]",
    green: "bg-emerald-50 text-emerald-700",
    blue: "bg-sky-50 text-sky-700",
  }[tone];
  const trendClass = trend ? (trend.good ?? trend.direction === "up" ? "text-emerald-600" : "text-rose-600") : "";
  return (
    <div className="card p-4">
      <div className="flex items-start justify-between gap-2">
        <p className="text-[0.68rem] font-extrabold uppercase tracking-[0.1em] text-muted">{label}</p>
        {icon ? <span className={cx("grid h-7 w-7 place-items-center rounded-lg", accents)}>{icon}</span> : null}
      </div>
      <p className="kpi-value mt-2.5 text-[1.35rem] font-black leading-none text-navy">{value}</p>
      <div className="mt-2 flex items-center justify-between gap-2">
        {sub ? <div className="text-[0.72rem] font-medium text-muted">{sub}</div> : <span />}
        {trend ? (
          <span className={cx("inline-flex items-center gap-0.5 text-[0.7rem] font-bold", trendClass)}>
            {trend.direction === "up" ? <ArrowUpRight className="h-3.5 w-3.5" /> : trend.direction === "down" ? <ArrowDownRight className="h-3.5 w-3.5" /> : null}
            {trend.value}
          </span>
        ) : null}
      </div>
    </div>
  );
}

export function Avatar({ name, size = "md" }: { name: string; size?: "sm" | "md" }) {
  const letters = name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join("");
  return (
    <span
      className={cx(
        "inline-grid shrink-0 place-items-center rounded-full bg-navy font-extrabold text-gold ring-1 ring-white/20",
        size === "sm" ? "h-7 w-7 text-[0.62rem]" : "h-9 w-9 text-[0.7rem]",
      )}
    >
      {letters || "BP"}
    </span>
  );
}

export function EmptyState({ title, message, children }: { title: string; message: string; children?: ReactNode }) {
  return (
    <div className="rounded-xl border border-dashed border-line bg-[#fafcff] px-6 py-9 text-center">
      <div className="mx-auto grid h-10 w-10 place-items-center rounded-full bg-navy/5 text-navy">
        <ShieldCheck className="h-5 w-5" />
      </div>
      <p className="mt-3 text-sm font-extrabold text-navy">{title}</p>
      <p className="mx-auto mt-1 max-w-sm text-xs font-medium text-muted">{message}</p>
      {children ? <div className="mt-4 flex justify-center">{children}</div> : null}
    </div>
  );
}

export function Field({
  label,
  htmlFor,
  hint,
  children,
  className,
}: {
  label: string;
  htmlFor?: string;
  hint?: string;
  children: ReactNode;
  className?: string;
}) {
  return (
    <div className={className}>
      <label className="label" htmlFor={htmlFor}>
        {label}
      </label>
      {children}
      {hint ? <p className="field-help">{hint}</p> : null}
    </div>
  );
}

export function Progress({ value, tone = "navy" }: { value: number; tone?: "navy" | "gold" | "green" }) {
  const bar = { navy: "bg-navy", gold: "bg-gold", green: "bg-emerald-500" }[tone];
  return (
    <div className="h-1.5 w-full overflow-hidden rounded-full bg-[#e9f0f7]">
      <div className={cx("h-full rounded-full transition-all", bar)} style={{ width: `${Math.max(0, Math.min(100, value))}%` }} />
    </div>
  );
}

export function KeyValue({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-4 py-1.5">
      <dt className="text-[0.74rem] font-semibold text-muted">{label}</dt>
      <dd className="text-right text-[0.78rem] font-bold text-navy">{children}</dd>
    </div>
  );
}

export function Amount({ value, className, compact }: { value: number | string | null | undefined; className?: string; compact?: boolean }) {
  const amount = Number(value ?? 0);
  return (
    <span className={cx("tabular-nums", amount < 0 && "text-rose-600", className)}>
      {money(amount, { compact })}
    </span>
  );
}

export function Bars({ series }: { series: Array<{ key: string; label: string; income: number; expense: number }> }) {
  const max = Math.max(1, ...series.flatMap((point) => [point.income, point.expense]));
  return (
    <div>
      <div className="flex items-end gap-3 sm:gap-4" style={{ height: 168 }}>
        {series.map((point) => (
          <div key={point.key} className="flex h-full flex-1 items-end justify-center gap-1.5">
            <div className="group relative flex h-full w-full max-w-[18px] items-end">
              <div className="w-full rounded-t bg-navy transition-all" style={{ height: `${Math.max(3, (point.income / max) * 100)}%` }} title={`Revenue ${money(point.income)}`} />
              <span className="pointer-events-none absolute -top-7 left-1/2 hidden -translate-x-1/2 whitespace-nowrap rounded bg-navy px-1.5 py-0.5 text-[0.6rem] font-bold text-white group-hover:block">
                {money(point.income, { compact: true })}
              </span>
            </div>
            <div className="group relative flex h-full w-full max-w-[18px] items-end">
              <div className="w-full rounded-t bg-gold transition-all" style={{ height: `${Math.max(3, (point.expense / max) * 100)}%` }} title={`Expenses ${money(point.expense)}`} />
              <span className="pointer-events-none absolute -top-7 left-1/2 hidden -translate-x-1/2 whitespace-nowrap rounded bg-gold px-1.5 py-0.5 text-[0.6rem] font-bold text-navy-deep group-hover:block">
                {money(point.expense, { compact: true })}
              </span>
            </div>
          </div>
        ))}
      </div>
      <div className="mt-2 flex gap-3 border-t border-line pt-2 sm:gap-4">
        {series.map((point) => (
          <p key={point.key} className="flex-1 text-center text-[0.65rem] font-bold uppercase tracking-wide text-muted">
            {point.label}
          </p>
        ))}
      </div>
    </div>
  );
}

export function Sparkline({ values, className = "text-navy" }: { values: number[]; className?: string }) {
  const width = 120;
  const height = 32;
  const max = Math.max(1, ...values);
  const min = Math.min(...values);
  const points = values
    .map((value, index) => {
      const x = (index / Math.max(1, values.length - 1)) * width;
      const y = height - ((value - min) / Math.max(1, max - min)) * (height - 4) - 2;
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(" ");
  return (
    <svg viewBox={`0 0 ${width} ${height}`} className={cx("h-8 w-full", className)} preserveAspectRatio="none" aria-hidden>
      <polyline points={points} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function SessionNote() {
  return (
    <p className="flex items-center justify-center gap-1.5 text-[0.7rem] font-medium text-muted">
      <ShieldCheck className="h-3.5 w-3.5 text-emerald-600" />
      Server-side credentials · 8-hour sliding session · lockout after 5 failed attempts
    </p>
  );
}


export function Panel({
  title,
  description,
  cta,
  children,
  defaultOpen = false,
  id,
}: {
  title: string;
  description?: string;
  cta: string;
  children: ReactNode;
  defaultOpen?: boolean;
  id?: string;
}) {
  return (
    <details className="panel card" open={defaultOpen} id={id}>
      <summary className="panel-summary flex w-full items-center justify-between gap-3 px-4 py-3.5 sm:px-5">
        <span>
          <span className="block text-[0.88rem] font-extrabold tracking-tight text-navy">{title}</span>
          {description ? <span className="mt-0.5 block text-[0.73rem] font-medium text-muted">{description}</span> : null}
        </span>
        <span className="btn btn-primary btn-sm shrink-0">
          <Plus className="h-3.5 w-3.5" />
          {cta}
          <ChevronDown className="panel-open-icon h-3.5 w-3.5 transition-transform" />
        </span>
      </summary>
      <div className="border-t border-line bg-[#fbfdff] p-4 sm:p-5">{children}</div>
    </details>
  );
}

export function FilterBar({ children }: { children: ReactNode }) {
  return <div className="flex flex-wrap items-end gap-2">{children}</div>;
}

export function TableWrap({ children, className }: { children: ReactNode; className?: string }) {
  return <div className={cx("overflow-x-auto rounded-xl border border-line bg-white", className)}>{children}</div>;
}
