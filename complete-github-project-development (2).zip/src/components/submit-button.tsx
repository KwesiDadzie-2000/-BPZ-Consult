"use client";

import type { ReactNode } from "react";
import { useFormStatus } from "react-dom";
import { Loader2 } from "lucide-react";

export function SubmitButton({
  children,
  pendingLabel,
  variant = "primary",
  className = "",
}: {
  children: ReactNode;
  pendingLabel?: string;
  variant?: "primary" | "gold" | "ghost" | "danger";
  className?: string;
}) {
  const { pending } = useFormStatus();
  const variantClass =
    variant === "gold" ? "btn-gold" : variant === "ghost" ? "btn-ghost" : variant === "danger" ? "btn-danger" : "btn-primary";
  return (
    <button type="submit" disabled={pending} className={`btn ${variantClass} ${className}`} aria-busy={pending}>
      {pending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : null}
      {pending ? pendingLabel ?? "Working…" : children}
    </button>
  );
}

export function Spinner() {
  return <Loader2 className="h-4 w-4 animate-spin" />;
}
