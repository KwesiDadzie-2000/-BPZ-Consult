"use client";

import Link from "next/link";
import { useState, useTransition } from "react";
import { Check, Copy, KeyRound, Loader2, ShieldCheck } from "lucide-react";
import { Alert, Field } from "@/components/ui";

export function ForgotForm() {
  const [identifier, setIdentifier] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [resetUrl, setResetUrl] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [pending, startTransition] = useTransition();

  if (resetUrl) {
    return (
      <div className="space-y-3">
        <Alert tone="success" title="Reset link generated">
          The link below is single-use and expires in 30 minutes. Opening it revokes your other sessions once the new
          password is saved.
        </Alert>
        <div className="rounded-xl border border-line bg-[#f7fafd] p-3">
          <p className="text-[0.64rem] font-extrabold uppercase tracking-[0.1em] text-muted">Secure reset link</p>
          <p className="mt-1 break-all font-mono text-[0.72rem] font-semibold text-navy">{resetUrl}</p>
          <div className="mt-2 flex flex-wrap gap-2">
            <Link href={resetUrl} className="btn btn-primary btn-sm">
              Open reset form
            </Link>
            <button
              type="button"
              className="btn btn-ghost btn-sm"
              onClick={async () => {
                try {
                  await navigator.clipboard.writeText(`${window.location.origin}${resetUrl}`);
                  setCopied(true);
                  setTimeout(() => setCopied(false), 2000);
                } catch {
                  setCopied(false);
                }
              }}
            >
              {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
              {copied ? "Copied" : "Copy link"}
            </button>
            <Link href="/login" className="btn btn-quiet btn-sm">
              Back to sign in
            </Link>
          </div>
        </div>
        <p className="flex items-start gap-1.5 text-[0.7rem] font-medium text-muted">
          <ShieldCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-600" />
          In production this link is emailed. The preview returns it here because no mail provider is configured.
        </p>
      </div>
    );
  }

  const onSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    setError(null);
    startTransition(async () => {
      try {
        const response = await fetch("/api/auth/forgot", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ identifier }),
        });
        const body = (await response.json()) as { ok?: boolean; error?: string; resetUrl?: string };
        if (!response.ok || !body.ok || !body.resetUrl) {
          setError(body.error || "Could not generate a reset link.");
          return;
        }
        setResetUrl(body.resetUrl);
      } catch {
        setError("Could not reach the recovery service. Try again.");
      }
    });
  };

  return (
    <div className="space-y-3">
      {error ? <Alert tone="error">{error}</Alert> : null}
      <form onSubmit={onSubmit} className="space-y-3">
        <Field label="Username or email" htmlFor="identifier">
          <div className="relative">
            <KeyRound className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-sky-500" />
            <input
              id="identifier"
              name="identifier"
              required
              value={identifier}
              onChange={(event) => setIdentifier(event.target.value)}
              className="input pl-9"
              placeholder="owner or owner@bpzconsult.com"
              disabled={pending}
            />
          </div>
        </Field>
        <button type="submit" disabled={pending} className="btn btn-primary w-full py-2.5">
          {pending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : null}
          {pending ? "Generating secure link…" : "Generate reset link"}
        </button>
      </form>
      <p className="text-center text-[0.72rem] font-medium text-muted">
        Remembered it?{" "}
        <Link href="/login" className="font-bold text-sky-700 hover:underline">
          Sign in
        </Link>
      </p>
    </div>
  );
}
