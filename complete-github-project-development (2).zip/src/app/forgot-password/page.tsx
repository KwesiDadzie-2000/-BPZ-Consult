import Link from "next/link";
import { ArrowLeft, ShieldCheck } from "lucide-react";
import { safeEnsureSeed } from "@/lib/seed";
import { Logo, SessionNote } from "@/components/ui";
import { ForgotForm } from "./forgot-form";

export const dynamic = "force-dynamic";
export const metadata = { title: "Recover access — BPZ Consult" };

export default async function ForgotPasswordPage() {
  await safeEnsureSeed();
  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-[#f0f6fc] px-4 py-10 auth-grid">
      <div className="w-full max-w-[440px]">
        <div className="mb-5 flex flex-col items-center text-center">
          <Logo size="lg" />
          <h1 className="mt-3 text-xl font-black tracking-tight text-navy">BPZ Consult</h1>
          <p className="text-xs font-semibold text-muted">Workspace access recovery</p>
        </div>
        <div className="card space-y-4 p-5 sm:p-6">
          <div>
            <h2 className="text-[1.15rem] font-black tracking-tight text-navy">Forgot your password?</h2>
            <p className="mt-1 text-[0.8rem] font-medium text-muted">
              Enter the username or email on your account. We&apos;ll issue a single-use link to set a new password.
            </p>
          </div>
          <ForgotForm />
          <div className="rounded-xl border border-sky-200 bg-sky-50/70 px-3 py-2 text-[0.7rem] font-medium leading-relaxed text-sky-900">
            <p className="flex items-center gap-1.5 font-extrabold uppercase tracking-wide">
              <ShieldCheck className="h-3.5 w-3.5" /> Locked out after failed attempts?
            </p>
            <p className="mt-1">
              Sign-in locks for 5 minutes after five failures. Wait for the timer, or generate a reset link above — resetting
              clears the lock immediately.
            </p>
          </div>
        </div>
        <div className="mt-4 space-y-2">
          <Link href="/login" className="btn btn-ghost btn-sm mx-auto flex w-fit"><ArrowLeft className="h-3.5 w-3.5" /> Back to sign in</Link>
          <SessionNote />
        </div>
      </div>
    </main>
  );
}
