import Link from "next/link";
import { Logo } from "@/components/ui";

export default function NotFound() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-[#f0f6fc] px-4 py-12 auth-grid">
      <div className="w-full max-w-md text-center">
        <div className="flex justify-center"><Logo size="lg" /></div>
        <p className="mt-4 text-[0.7rem] font-extrabold uppercase tracking-[0.18em] text-muted">404 · Not found</p>
        <h1 className="mt-1 text-2xl font-black tracking-tight text-navy">That page isn&apos;t in the workspace</h1>
        <p className="mt-2 text-sm font-medium text-muted">
          The link may be out of date. Head back to your dashboard or sign in again.
        </p>
        <div className="mt-5 flex flex-wrap justify-center gap-2">
          <Link href="/dashboard" className="btn btn-primary">Go to dashboard</Link>
          <Link href="/login" className="btn btn-ghost">Sign in</Link>
        </div>
      </div>
    </main>
  );
}
