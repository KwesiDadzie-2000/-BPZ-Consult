import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "BPZ Consult — Practice & Accounting Workspace",
  description:
    "BPZ Consult ERP: secure practice management, bookkeeping, Ghana tax and payroll workspace with server-backed credentials and double-entry ledger.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen antialiased">{children}</body>
    </html>
  );
}
