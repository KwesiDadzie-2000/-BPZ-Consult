import { NextResponse } from "next/server";
import { destroyCurrentSession, SESSION_COOKIE, sessionCookieOptions } from "@/lib/auth";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

async function clearAndRespond(request: Request, asRedirect: boolean) {
  try {
    await destroyCurrentSession();
  } catch (error) {
    console.error("Logout failed", error);
  }

  if (asRedirect) {
    const url = new URL("/login", request.url);
    url.searchParams.set("ok", "You have been signed out securely.");
    const response = NextResponse.redirect(url, 303);
    const options = await sessionCookieOptions();
    response.cookies.set(SESSION_COOKIE, "", { ...options, maxAge: 0 });
    return response;
  }

  const response = NextResponse.json({ ok: true });
  const options = await sessionCookieOptions();
  response.cookies.set(SESSION_COOKIE, "", { ...options, maxAge: 0 });
  return response;
}

export async function POST(request: Request) {
  return clearAndRespond(request, false);
}

export async function GET(request: Request) {
  return clearAndRespond(request, true);
}
