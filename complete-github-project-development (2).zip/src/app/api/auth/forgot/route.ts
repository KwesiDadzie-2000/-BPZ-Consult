import { NextResponse } from "next/server";
import { requestPasswordReset } from "@/lib/auth";
import { ensureSeed } from "@/lib/seed";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function POST(request: Request) {
  try {
    await ensureSeed();
  } catch (error) {
    console.error("Forgot bootstrap failed", error);
    return NextResponse.json({ ok: false, error: "Database unavailable." }, { status: 503 });
  }

  let body: { identifier?: string } = {};
  try {
    body = (await request.json()) as { identifier?: string };
  } catch {
    return NextResponse.json({ ok: false, error: "Invalid request body." }, { status: 400 });
  }

  try {
    const result = await requestPasswordReset(String(body.identifier ?? ""));
    if (!result.ok) return NextResponse.json({ ok: false, error: result.error }, { status: 404 });
    return NextResponse.json({
      ok: true,
      resetUrl: result.resetUrl,
      expiresInMinutes: 30,
    });
  } catch (error) {
    console.error("Forgot password failed", error);
    return NextResponse.json({ ok: false, error: "Could not generate a reset link." }, { status: 500 });
  }
}
