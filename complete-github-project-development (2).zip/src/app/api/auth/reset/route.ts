import { NextResponse } from "next/server";
import { resetPasswordWithToken } from "@/lib/auth";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function POST(request: Request) {
  let body: { token?: string; password?: string; confirmPassword?: string } = {};
  try {
    body = (await request.json()) as typeof body;
  } catch {
    return NextResponse.json({ ok: false, error: "Invalid request body." }, { status: 400 });
  }

  try {
    const result = await resetPasswordWithToken(
      String(body.token ?? ""),
      String(body.password ?? ""),
      String(body.confirmPassword ?? ""),
    );
    if (!result.ok) return NextResponse.json({ ok: false, error: result.error }, { status: 400 });
    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error("Password reset failed", error);
    return NextResponse.json({ ok: false, error: "Could not reset the password." }, { status: 500 });
  }
}
