import { NextResponse } from "next/server";
import { login, SESSION_COOKIE, sessionCookieOptions } from "@/lib/auth";
import { ensureSeed } from "@/lib/seed";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

/**
 * Classic JSON login endpoint.
 *
 * Sets the session cookie on the *response* (not via cookies() from next/headers),
 * which is the only reliable way to attach Set-Cookie behind preview proxies.
 */
export async function POST(request: Request) {
  try {
    await ensureSeed();
  } catch (error) {
    console.error("Login bootstrap failed", error);
    return NextResponse.json(
      { ok: false, error: "The workspace database is not reachable. Try again in a moment." },
      { status: 503 },
    );
  }

  let body: { identifier?: string; password?: string } = {};
  try {
    body = (await request.json()) as { identifier?: string; password?: string };
  } catch {
    return NextResponse.json({ ok: false, error: "Invalid request body." }, { status: 400 });
  }

  try {
    const result = await login(String(body.identifier ?? ""), String(body.password ?? ""));
    if (!result.ok) {
      return NextResponse.json(
        { ok: false, error: result.error, lockedForSeconds: result.lockedForSeconds },
        { status: 401 },
      );
    }

    const response = NextResponse.json({ ok: true });
    const options = await sessionCookieOptions();
    response.cookies.set(SESSION_COOKIE, result.token, options);
    return response;
  } catch (error) {
    console.error("Login failed", error);
    return NextResponse.json(
      { ok: false, error: "The sign-in service is unavailable. Please try again." },
      { status: 500 },
    );
  }
}
