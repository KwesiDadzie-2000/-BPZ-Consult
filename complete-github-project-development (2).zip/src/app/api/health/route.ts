import { sql } from "drizzle-orm";
import { db } from "@/db";
import { ensureSchema } from "@/lib/bootstrap";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await db.execute(sql`select 1`);
    // A cold database is provisioned on the first health check, so no route can
    // ever fail with "relation does not exist".
    await ensureSchema();
    return Response.json({ ok: true, database: "ready", schema: "provisioned" });
  } catch (error) {
    console.error("Health check failed", error);
    return Response.json({ ok: false }, { status: 500 });
  }
}
