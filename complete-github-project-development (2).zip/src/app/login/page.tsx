import Link from "next/link";
import { redirect } from "next/navigation";
import { ArrowRight, CheckCircle2, ShieldCheck } from "lucide-react";
import { getCurrentUser } from "@/lib/auth";
import { safeEnsureSeed, SEED_CREDENTIALS } from "@/lib/seed";
import { Alert, Logo, SessionNote } from "@/components/ui";
import { LoginForm } from "./login-form";

export const dynamic = "force-dynamic";

export const metadata = { title: "Sign in — BPZ Consult" };

export default async function LoginPage({ searchParams }: { searchParams: Promise<{ ok?: string; error?: string }> }) {
  const bootstrap = await safeEnsureSeed();
  const user = await getCurrentUser().catch(() => null);
  if (user) redirect("/dashboard");
  const params = await searchParams;

  return (
    <main className="grid min-h-screen lg:grid-cols-[1.05fr_1fr]">
      <section className="relative hidden overflow-hidden bg-navy px-10 py-12 text-white lg:flex lg:flex-col xl:px-14">
        <div className="pointer-events-none absolute -right-24 -top-24 h-80 w-80 rounded-full border border-white/10" />
        <div className="pointer-events-none absolute -bottom-32 -left-16 h-96 w-96 rounded-full border border-gold/20" />
        <div className="pointer-events-none absolute right-16 top-1/3 h-40 w-40 rounded-full bg-gold/10 blur-2xl" />

        <div className="relative flex items-center gap-3">
          <Logo />
          <div>
            <p className="text-base font-black tracking-tight">BPZ Consult</p>
            <p className="text-[0.62rem] font-bold uppercase tracking-[0.18em] text-gold">Practice & accounting workspace</p>
          </div>
        </div>

        <div className="relative mt-auto max-w-xl">
          <span className="inline-flex items-center gap-1.5 rounded-full border border-gold/30 bg-gold/10 px-3 py-1 text-[0.65rem] font-bold uppercase tracking-[0.12em] text-gold">
            <ShieldCheck className="h-3.5 w-3.5" /> Rebuilt &amp; secured
          </span>
          <h1 className="mt-5 text-[2.35rem] font-black leading-[1.08] tracking-tight xl:text-[2.75rem]">
            Close the books with
            <span className="text-gold"> total confidence.</span>
          </h1>
          <p className="mt-4 max-w-md text-[0.9rem] leading-relaxed text-white/70">
            One workspace for client accounting, GST/VAT compliance, payroll and financial reporting — with a ledger that
            proves every posting.
          </p>

          <div className="mt-7 grid grid-cols-3 gap-3">
            {[
              { label: "Ledger control", value: "Double-entry" },
              { label: "Payroll", value: "PAYE + SSNIT" },
              { label: "Session", value: "8h sliding" },
            ].map((item) => (
              <div key={item.label} className="rounded-xl border border-white/10 bg-white/5 px-3 py-2.5">
                <p className="text-[0.58rem] font-bold uppercase tracking-[0.12em] text-white/45">{item.label}</p>
                <p className="mt-1 text-[0.82rem] font-extrabold text-white">{item.value}</p>
              </div>
            ))}
          </div>

          <div className="mt-8 flex items-start gap-3 rounded-2xl border border-white/10 bg-white/[0.06] p-4">
            <span className="mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-gold text-navy-deep">
              <CheckCircle2 className="h-4 w-4" />
            </span>
            <div>
              <p className="text-[0.78rem] font-bold">Credentials are verified on the server</p>
              <p className="mt-0.5 text-[0.72rem] leading-relaxed text-white/60">
                scrypt password hashes, HttpOnly session cookies, persisted lockout and single-use reset links replace the
                old browser-only login.
              </p>
            </div>
          </div>
        </div>

        <p className="relative mt-10 text-[0.66rem] font-medium text-white/35">
          © {new Date().getFullYear()} BPZ Consult · Accra, Ghana · Confidential client information
        </p>
      </section>

      <section className="flex min-h-screen flex-col items-center justify-center bg-[#f0f6fc] px-4 py-10 sm:px-6">
        <div className="w-full max-w-[420px]">
          <div className="mb-6 flex flex-col items-center text-center lg:hidden">
            <Logo size="lg" />
            <h1 className="mt-3 text-xl font-black tracking-tight text-navy">BPZ Consult</h1>
            <p className="mt-0.5 text-xs font-semibold text-muted">Sign in to your workspace</p>
          </div>

          <div className="hidden text-center lg:block">
            <h2 className="text-[1.35rem] font-black tracking-tight text-navy">Sign in to your workspace</h2>
            <p className="mt-1 text-[0.82rem] font-medium text-muted">Use the credentials issued by the firm owner.</p>
          </div>

          <div className="card mt-4 space-y-3.5 p-5 sm:p-6">
            {bootstrap.ok ? null : <Alert tone="warning" title="Database unavailable">{bootstrap.error}</Alert>}
            {params.error ? <Alert tone="error">{params.error}</Alert> : null}
            {params.ok ? <Alert tone="success">{params.ok}</Alert> : null}
            <LoginForm accounts={SEED_CREDENTIALS.map((account) => ({ ...account }))} />
          </div>

          <div className="mt-4 space-y-2">
            <SessionNote />
            <p className="text-center text-[0.7rem] font-medium text-muted">
              Need an account? Ask the firm owner or{" "}
              <Link href="/forgot-password" className="font-bold text-sky-700 hover:underline">
                recover access
              </Link>
              .
            </p>
            <p className="flex items-center justify-center gap-1 text-[0.66rem] font-medium text-muted/80">
              <ArrowRight className="h-3 w-3" /> Accounts are created server-side; no credentials are stored in your browser.
            </p>
            <p className="text-center text-[0.62rem] font-semibold uppercase tracking-[0.14em] text-muted/60">
              Secured build v2.3 · API sessions
            </p>
          </div>
        </div>
      </section>
    </main>
  );
}
