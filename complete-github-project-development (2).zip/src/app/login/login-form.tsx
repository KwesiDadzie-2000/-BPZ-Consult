"use client";

import Link from "next/link";
import { useEffect, useRef, useState, useTransition } from "react";
import { Eye, EyeOff, KeyRound, Lock, User, Loader2 } from "lucide-react";

type DemoAccount = { username: string; password: string; name: string; role: string; jobTitle: string };

export function LoginForm({ accounts }: { accounts: DemoAccount[] }) {
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lockSeconds, setLockSeconds] = useState(0);
  const [pending, startTransition] = useTransition();
  const timer = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (lockSeconds <= 0) return;
    timer.current = setInterval(() => setLockSeconds((value) => Math.max(0, value - 1)), 1000);
    return () => {
      if (timer.current) clearInterval(timer.current);
    };
  }, [lockSeconds]);

  const fill = (account: DemoAccount) => {
    setIdentifier(account.username);
    setPassword(account.password);
    setShowPassword(false);
    setError(null);
  };

  const onSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    if (lockSeconds > 0) {
      setError(`Too many failed attempts. Try again in ${Math.ceil(lockSeconds / 60)} minute(s).`);
      return;
    }
    setError(null);
    startTransition(async () => {
      try {
        const response = await fetch("/api/auth/login", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          credentials: "include",
          body: JSON.stringify({ identifier, password }),
        });
        let body: { ok?: boolean; error?: string; lockedForSeconds?: number } = {};
        try {
          body = (await response.json()) as typeof body;
        } catch {
          body = { ok: false, error: "Unexpected response from the sign-in service." };
        }
        if (!response.ok || !body.ok) {
          if (body.lockedForSeconds && body.lockedForSeconds > 0) setLockSeconds(body.lockedForSeconds);
          setError(body.error || "Invalid username, email or password.");
          return;
        }
        // Full page navigation guarantees the Set-Cookie from the login response
        // is sent on the very next document request (router.replace can race).
        window.location.assign("/dashboard");
      } catch {
        setError("Could not reach the sign-in service. Check your connection and try again.");
      }
    });
  };

  return (
    <div className="space-y-4">
      {error ? (
        <div role="alert" className="rounded-xl border border-rose-300 bg-rose-50 px-3.5 py-2.5 text-[0.8rem] font-bold text-rose-800">
          {error}
          {lockSeconds > 0 ? (
            <span className="mt-1 block font-medium">
              Locked for {Math.floor(lockSeconds / 60)}:{String(lockSeconds % 60).padStart(2, "0")} more.
            </span>
          ) : null}
        </div>
      ) : null}

      <form onSubmit={onSubmit} className="space-y-3.5">
        <div>
          <label className="label" htmlFor="identifier">
            Username or email
          </label>
          <div className="relative">
            <User className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-sky-500" />
            <input
              id="identifier"
              name="identifier"
              type="text"
              autoComplete="username"
              required
              value={identifier}
              onChange={(event) => setIdentifier(event.target.value)}
              placeholder="owner"
              className="input pl-9"
              disabled={pending}
            />
          </div>
        </div>

        <div>
          <div className="mb-1 flex items-baseline justify-between">
            <label className="label mb-0" htmlFor="password">
              Password
            </label>
            <Link href="/forgot-password" className="text-[0.72rem] font-bold text-sky-700 hover:underline">
              Forgot password?
            </Link>
          </div>
          <div className="relative">
            <Lock className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-sky-500" />
            <input
              id="password"
              name="password"
              type={showPassword ? "text" : "password"}
              autoComplete="current-password"
              required
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              placeholder="••••••••••••"
              className="input px-9"
              disabled={pending}
            />
            <button
              type="button"
              onClick={() => setShowPassword((value) => !value)}
              className="absolute right-2 top-1.5 rounded p-1.5 text-slate-400 hover:bg-slate-100 hover:text-navy"
              aria-label={showPassword ? "Hide password" : "Show password"}
            >
              {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
        </div>

        <button type="submit" disabled={pending || lockSeconds > 0} className="btn btn-primary w-full py-2.5" aria-busy={pending}>
          {pending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : null}
          {pending ? "Verifying credentials…" : lockSeconds > 0 ? `Locked · retry in ${lockSeconds}s` : "Sign In"}
        </button>
      </form>

      <div className="rounded-xl border border-sky-200 bg-sky-50/70 p-3">
        <div className="flex items-center gap-1.5">
          <KeyRound className="h-3.5 w-3.5 text-sky-700" />
          <p className="text-[0.68rem] font-extrabold uppercase tracking-[0.1em] text-sky-900">Provisioned workspace accounts</p>
        </div>
        <p className="mt-1 text-[0.7rem] font-medium text-sky-900/80">
          Passwords were rotated and hashed server-side. Select an account to fill the form.
        </p>
        <div className="mt-2 grid gap-1.5">
          {accounts.map((account) => (
            <button
              key={account.username}
              type="button"
              onClick={() => fill(account)}
              disabled={pending}
              className="flex items-center justify-between gap-2 rounded-lg border border-sky-200 bg-white px-2.5 py-1.5 text-left transition hover:border-navy/30 hover:bg-white disabled:opacity-60"
            >
              <span className="min-w-0">
                <span className="block text-[0.76rem] font-extrabold text-navy">
                  {account.username} <span className="font-semibold text-muted">· {account.jobTitle}</span>
                </span>
                <span className="block truncate font-mono text-[0.68rem] text-muted">{account.password}</span>
              </span>
              <span className="pill pill-slate shrink-0">{account.role}</span>
            </button>
          ))}
        </div>
        <p className="mt-2 text-[0.66rem] font-medium leading-relaxed text-sky-900/70">
          Use “Forgot password?” to rotate any credential. Reset links are single-use and expire after 30 minutes.
        </p>
      </div>
    </div>
  );
}
