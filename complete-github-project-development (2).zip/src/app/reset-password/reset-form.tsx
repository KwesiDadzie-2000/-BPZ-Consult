"use client";

import Link from "next/link";
import { useState, useTransition } from "react";
import { CheckCircle2, Eye, EyeOff, Loader2, Lock } from "lucide-react";
import { Alert, Field } from "@/components/ui";

function checks(password: string) {
  return [
    { label: "10+ characters", ok: password.length >= 10 },
    { label: "Uppercase", ok: /[A-Z]/.test(password) },
    { label: "Lowercase", ok: /[a-z]/.test(password) },
    { label: "Number", ok: /[0-9]/.test(password) },
    { label: "Symbol", ok: /[^A-Za-z0-9]/.test(password) },
  ];
}

export function ResetForm({ token }: { token: string }) {
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [show, setShow] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [ok, setOk] = useState(false);
  const [pending, startTransition] = useTransition();

  if (ok) {
    return (
      <div className="space-y-4">
        <div className="flex flex-col items-center text-center">
          <span className="grid h-12 w-12 place-items-center rounded-full bg-emerald-50 text-emerald-600">
            <CheckCircle2 className="h-6 w-6" />
          </span>
          <h2 className="mt-3 text-[1.15rem] font-black tracking-tight text-navy">Password updated</h2>
          <p className="mt-1 text-[0.8rem] font-medium text-muted">
            Your credential has been rotated and all previous sessions were revoked. Sign in with your new password.
          </p>
        </div>
        <Link href="/login?ok=Password+reset.+Sign+in+with+your+new+credential." className="btn btn-primary w-full py-2.5">
          Continue to sign in
        </Link>
      </div>
    );
  }

  if (!token) {
    return (
      <div className="space-y-3">
        <Alert tone="error" title="Missing reset token">
          This page needs a valid reset link. Generate a new one from the recovery screen.
        </Alert>
        <Link href="/forgot-password" className="btn btn-primary w-full">
          Request a new link
        </Link>
      </div>
    );
  }

  const onSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    setError(null);
    startTransition(async () => {
      try {
        const response = await fetch("/api/auth/reset", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ token, password, confirmPassword: confirm }),
        });
        const body = (await response.json()) as { ok?: boolean; error?: string };
        if (!response.ok || !body.ok) {
          setError(body.error || "Could not reset the password.");
          return;
        }
        setOk(true);
      } catch {
        setError("Could not reach the reset service. Try again.");
      }
    });
  };

  return (
    <div className="space-y-3">
      {error ? <Alert tone="error">{error}</Alert> : null}
      <form onSubmit={onSubmit} className="space-y-3">
        <Field label="New password" htmlFor="password">
          <div className="relative">
            <Lock className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-sky-500" />
            <input
              id="password"
              name="password"
              type={show ? "text" : "password"}
              autoComplete="new-password"
              required
              className="input px-9"
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              placeholder="Choose a strong password"
              disabled={pending}
            />
            <button
              type="button"
              onClick={() => setShow((value) => !value)}
              className="absolute right-2 top-1.5 rounded p-1.5 text-slate-400 hover:bg-slate-100 hover:text-navy"
              aria-label={show ? "Hide password" : "Show password"}
            >
              {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
        </Field>
        <Field label="Confirm password" htmlFor="confirmPassword">
          <input
            id="confirmPassword"
            name="confirmPassword"
            type={show ? "text" : "password"}
            autoComplete="new-password"
            required
            className="input"
            value={confirm}
            onChange={(event) => setConfirm(event.target.value)}
            placeholder="Repeat the password"
            disabled={pending}
          />
        </Field>
        <div className="flex flex-wrap gap-1.5">
          {checks(password).map((check) => (
            <span key={check.label} className={`pill ${check.ok ? "pill-green" : "pill-slate"}`}>
              {check.label}
            </span>
          ))}
        </div>
        <button type="submit" disabled={pending} className="btn btn-primary w-full py-2.5">
          {pending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : null}
          {pending ? "Saving new password…" : "Set new password"}
        </button>
      </form>
      <p className="text-center text-[0.72rem] font-medium text-muted">
        Link expired or already used?{" "}
        <Link href="/forgot-password" className="font-bold text-sky-700 hover:underline">
          Request another
        </Link>
      </p>
    </div>
  );
}
