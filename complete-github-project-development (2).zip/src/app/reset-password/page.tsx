import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { Logo, SessionNote } from "@/components/ui";
import { ResetForm } from "./reset-form";

export const dynamic = "force-dynamic";
export const metadata = { title: "Set a new password — BPZ Consult" };

export default async function ResetPasswordPage({ searchParams }: { searchParams: Promise<{ token?: string }> }) {
  const params = await searchParams;
  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-[#f0f6fc] px-4 py-10 auth-grid">
      <div className="w-full max-w-[440px]">
        <div className="mb-5 flex flex-col items-center text-center">
          <Logo size="lg" />
          <h1 className="mt-3 text-xl font-black tracking-tight text-navy">BPZ Consult</h1>
          <p className="text-xs font-semibold text-muted">Secure credential reset</p>
        </div>
        <div className="card p-5 sm:p-6">
          <ResetForm token={params.token ?? ""} />
        </div>
        <div className="mt-4 space-y-2">
          <Link href="/login" className="btn btn-ghost btn-sm mx-auto flex w-fit"><ArrowLeft className="h-3.5 w-3.5" /> Back to sign in</Link>
          <SessionNote />
        </div>
      </div>
    </main>
  );
}
