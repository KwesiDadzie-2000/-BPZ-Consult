"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { accounts, clients, sessions, users } from "@/db/schema";
import { audit, requireOwner, requireWriter } from "@/lib/auth";
import { hashPassword, newSalt, passwordPolicyError } from "@/lib/password";

function text(formData: FormData, key: string): string {
  return String(formData.get(key) ?? "").trim();
}

function fail(path: string, message: string, panel = "new"): never {
  redirect(`${path}?error=${encodeURIComponent(message)}&panel=${panel}`);
}

function ok(path: string, message: string): never {
  redirect(`${path}?ok=${encodeURIComponent(message)}`);
}

/* ---------------------------------------------------------------- clients */

export async function createClientAction(formData: FormData): Promise<void> {
  const user = await requireWriter();
  const name = text(formData, "name");
  const sector = text(formData, "sector") || "Professional services";
  const contactName = text(formData, "contactName");
  const contactEmail = text(formData, "contactEmail");
  const phone = text(formData, "phone");
  const services = text(formData, "services") || "Bookkeeping";
  const currency = text(formData, "currency") || "GHS";
  const healthScore = Math.max(0, Math.min(100, Number(text(formData, "healthScore")) || 75));

  if (name.length < 2) fail("/clients", "Enter the client's legal name.");
  if (contactEmail && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(contactEmail)) fail("/clients", "Enter a valid contact email.");

  const count = await db.select({ id: clients.id }).from(clients);
  const code = `CLI-${String(count.length + 1).padStart(3, "0")}`;
  try {
    await db.insert(clients).values({
      code,
      name,
      sector,
      currency,
      contactName,
      contactEmail,
      phone,
      services,
      healthScore,
      status: "onboarding",
      notes: text(formData, "notes") || null,
    });
  } catch (error) {
    console.error("Client creation failed", error);
    fail("/clients", "Could not create the client. Please retry.");
  }
  await audit(user, "Onboarded client", "Client", code, `${name} · ${services}`);
  revalidatePath("/clients");
  revalidatePath("/dashboard");
  ok("/clients", `${name} onboarded as ${code}.`);
}

export async function updateClientAction(formData: FormData): Promise<void> {
  const user = await requireWriter();
  const id = Number(text(formData, "clientId"));
  const status = text(formData, "status");
  const healthScore = Math.max(0, Math.min(100, Number(text(formData, "healthScore")) || 0));
  if (!id) fail("/clients", "Client not found.");
  if (!["active", "onboarding", "dormant"].includes(status)) fail("/clients", "Choose a valid client status.");
  await db.update(clients).set({ status, healthScore }).where(eq(clients.id, id));
  await audit(user, "Updated client", "Client", String(id), `Status ${status} · health ${healthScore}`);
  revalidatePath("/clients");
  ok("/clients", "Client profile updated.");
}

/* --------------------------------------------------------------- accounts */

export async function createAccountAction(formData: FormData): Promise<void> {
  const user = await requireWriter();
  const accountNo = text(formData, "accountNo");
  const name = text(formData, "name");
  const type = text(formData, "type");
  const category = text(formData, "category") || "General";
  if (!/^\d{4}$/.test(accountNo)) fail("/accounts", "Account number must be four digits (e.g. 5170).", "account");
  if (!name) fail("/accounts", "Account name is required.", "account");
  if (!["asset", "liability", "equity", "income", "expense"].includes(type)) fail("/accounts", "Choose a valid account type.", "account");

  const existing = await db.select({ id: accounts.id }).from(accounts).where(eq(accounts.accountNo, accountNo)).limit(1);
  if (existing[0]) fail("/accounts", `Account ${accountNo} already exists.`, "account");
  try {
    await db.insert(accounts).values({ accountNo, name, type, category });
  } catch (error) {
    console.error("Account creation failed", error);
    fail("/accounts", "Could not create the account.", "account");
  }
  await audit(user, "Added GL account", "Account", accountNo, name);
  revalidatePath("/accounts");
  ok("/accounts", `Account ${accountNo} — ${name} added to the chart.`);
}

/* ------------------------------------------------------------------- team */

export async function createTeamMemberAction(formData: FormData): Promise<void> {
  const owner = await requireOwner();
  const name = text(formData, "name");
  const username = text(formData, "username").toLowerCase();
  const email = text(formData, "email").toLowerCase();
  const role = text(formData, "role");
  const jobTitle = text(formData, "jobTitle") || "Consultant";
  const password = String(formData.get("password") ?? "");

  if (name.length < 2) fail("/team", "Enter the team member's full name.", "invite");
  if (!/^[a-z0-9._-]{3,24}$/.test(username)) fail("/team", "Username must be 3–24 letters, numbers, dots or dashes.", "invite");
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) fail("/team", "Enter a valid email address.", "invite");
  if (!["manager", "accountant", "auditor"].includes(role)) fail("/team", "Choose manager, accountant or auditor.", "invite");
  const policyError = passwordPolicyError(password);
  if (policyError) fail("/team", policyError, "invite");

  const clash = await db
    .select({ id: users.id })
    .from(users)
    .where(sql`lower(${users.username}) = ${username} or lower(${users.email}) = ${email}`)
    .limit(1);
  if (clash[0]) fail("/team", "That username or email is already in use.", "invite");

  const salt = newSalt();
  let newUserId: number | null = null;
  try {
    const [created] = await db
      .insert(users)
      .values({
        username,
        email,
        name,
        role,
        jobTitle,
        passwordHash: await hashPassword(password, salt),
        passwordSalt: salt,
      })
      .returning({ id: users.id });
    newUserId = created?.id ?? null;
  } catch (error) {
    console.error("Team member creation failed", error);
    fail("/team", "Could not create the account.", "invite");
  }
  await audit(owner, "Provisioned access", "User", username, `${name} · ${role}`);
  revalidatePath("/team");
  ok("/team", `${name} can now sign in as “${username}”. Share the password securely.`);
  void newUserId;
}

export async function resetMemberPasswordAction(formData: FormData): Promise<void> {
  const owner = await requireOwner();
  const userId = Number(text(formData, "userId"));
  const password = String(formData.get("password") ?? "");
  const member = (await db.select().from(users).where(eq(users.id, userId)).limit(1))[0];
  if (!member) fail("/team", "Team member not found.", "invite");
  const policyError = passwordPolicyError(password);
  if (policyError) fail("/team", policyError, "invite");
  const salt = newSalt();
  await db
    .update(users)
    .set({ passwordHash: await hashPassword(password, salt), passwordSalt: salt })
    .where(eq(users.id, userId));
  await db.delete(sessions).where(eq(sessions.userId, userId));
  await audit(owner, "Reset member password", "User", member.username, "Credential rotated by the firm owner; sessions revoked.");
  revalidatePath("/team");
  ok("/team", `Password reset for ${member.name}. Existing sessions were revoked.`);
}

export async function setUserStatusAction(formData: FormData): Promise<void> {
  const owner = await requireOwner();
  const userId = Number(text(formData, "userId"));
  const status = text(formData, "status");
  if (!["active", "suspended"].includes(status)) fail("/team", "Invalid account status.", "team");
  const member = (await db.select().from(users).where(eq(users.id, userId)).limit(1))[0];
  if (!member) fail("/team", "Team member not found.", "team");
  if (member.role === "owner") fail("/team", "The firm owner's account cannot be suspended.", "team");
  await db.update(users).set({ status }).where(eq(users.id, userId));
  if (status === "suspended") await db.delete(sessions).where(eq(sessions.userId, userId));
  await audit(owner, status === "suspended" ? "Suspended access" : "Restored access", "User", member.username, `${member.name} is now ${status}.`);
  revalidatePath("/team");
  ok("/team", `${member.name} is now ${status}.`);
}
