"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { bankAccounts, clients, employees, expenses, invoices, payrollRuns } from "@/db/schema";
import { audit, requireUser, requireWriter } from "@/lib/auth";
import {
  AR_ACCOUNT,
  AP_ACCOUNT,
  DEFAULT_BANK_ACCOUNT,
  EXPENSE_ACCOUNTS,
  REVENUE_ACCOUNTS,
  VAT_INPUT_ACCOUNT,
  VAT_OUTPUT_ACCOUNT,
  nextDocumentNumber,
  postJournal,
  type DbExecutor,
} from "@/lib/accounting";
import { addDays, round2, today } from "@/lib/format";
import { computePayroll } from "@/lib/payroll";

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

function text(formData: FormData, key: string): string {
  return String(formData.get(key) ?? "").trim();
}

function amount(formData: FormData, key: string): number {
  return round2(Number(String(formData.get(key) ?? "0").replace(/,/g, "")) || 0);
}

function fail(path: string, message: string, panel = "new"): never {
  redirect(`${path}?error=${encodeURIComponent(message)}&panel=${panel}`);
}

function ok(path: string, message: string): never {
  redirect(`${path}?ok=${encodeURIComponent(message)}`);
}

function freshPath(path: string) {
  revalidatePath(path);
  revalidatePath("/dashboard");
  revalidatePath("/reports");
  revalidatePath("/journals");
}

/* ------------------------------------------------------------------ sales */

export async function createInvoiceAction(formData: FormData): Promise<void> {
  const user = await requireWriter();
  const clientId = Number(text(formData, "clientId"));
  const stream = text(formData, "revenueStream");
  const netRevenue = amount(formData, "netRevenue");
  const vatRate = Number(text(formData, "vatRate") || "15");
  const issueDate = text(formData, "issueDate") || today();
  const dueDate = text(formData, "dueDate") || addDays(issueDate, 21);
  const status = text(formData, "status") || "sent";

  if (!clientId) fail("/invoices", "Choose the client this invoice belongs to.");
  if (!REVENUE_ACCOUNTS[stream]) fail("/invoices", "Choose a valid revenue stream.");
  if (netRevenue <= 0) fail("/invoices", "Invoice net revenue must be greater than zero.");
  if (!DATE_RE.test(issueDate) || !DATE_RE.test(dueDate)) fail("/invoices", "Enter a valid issue and due date.");
  if (dueDate < issueDate) fail("/invoices", "The due date cannot be before the issue date.");
  if (!Number.isFinite(vatRate) || vatRate < 0 || vatRate > 30) fail("/invoices", "VAT rate must be between 0% and 30%.");

  const vatAmount = round2((netRevenue * vatRate) / 100);
  const totalAmount = round2(netRevenue + vatAmount);
  const invoiceNo = await nextDocumentNumber("INV", "invoices");

  const client = (await db.select().from(clients).where(eq(clients.id, clientId)).limit(1))[0];
  const customerName = client?.name ?? text(formData, "customerName");
  if (!customerName) fail("/invoices", "Client or customer name is required.");

  try {
    await db.transaction(async (tx) => {
      await tx.insert(invoices).values({
        invoiceNo,
        clientId,
        customerName,
        revenueStream: stream,
        netRevenue,
        vatRate,
        vatAmount,
        totalAmount,
        paidAmount: 0,
        status: status === "draft" ? "draft" : "sent",
        issueDate,
        dueDate,
        notes: text(formData, "notes") || null,
        createdBy: user.id,
      });
      if (status !== "draft") {
        await postJournal(tx as unknown as DbExecutor, {
          docNo: `INVJ-${invoiceNo}`,
          date: issueDate,
          module: "Sales",
          description: `Sales invoice ${invoiceNo} — ${customerName}`,
          clientId,
          createdBy: user.id,
          lines: [
            { accountNo: AR_ACCOUNT, debit: totalAmount, description: "Invoice receivable" },
            { accountNo: REVENUE_ACCOUNTS[stream], credit: netRevenue, description: stream },
            { accountNo: VAT_OUTPUT_ACCOUNT, credit: vatAmount, description: `VAT output (${vatRate}%)` },
          ],
        });
      }
    });
  } catch (error) {
    console.error("Invoice creation failed", error);
    fail("/invoices", "The invoice could not be saved. Please retry.");
  }

  await audit(user, "Raised invoice", "Invoice", invoiceNo, `${customerName} · ${stream} · GHS ${totalAmount.toFixed(2)}`);
  freshPath("/invoices");
  ok("/invoices", `Invoice ${invoiceNo} posted to the ledger.`);
}

export async function recordInvoicePaymentAction(formData: FormData): Promise<void> {
  const user = await requireWriter();
  const invoiceId = Number(text(formData, "invoiceId"));
  const payment = amount(formData, "amount");
  const paidOn = text(formData, "paidOn") || today();
  const bankAccountId = Number(text(formData, "bankAccountId"));

  const rows = await db.select().from(invoices).where(eq(invoices.id, invoiceId)).limit(1);
  const invoice = rows[0];
  if (!invoice) fail("/invoices", "Invoice not found.", "payments");
  if (invoice.status === "draft") fail("/invoices", "Post the draft invoice before recording a receipt.");
  const outstanding = round2(invoice.totalAmount - invoice.paidAmount);
  if (payment <= 0) fail("/invoices", "Enter a receipt amount greater than zero.");
  if (payment > outstanding + 0.005) fail("/invoices", `The receipt exceeds the outstanding balance of GHS ${outstanding.toFixed(2)}.`);
  if (!DATE_RE.test(paidOn)) fail("/invoices", "Enter a valid receipt date.");

  let bankGl = DEFAULT_BANK_ACCOUNT;
  if (bankAccountId) {
    const bank = await db.select().from(bankAccounts).where(eq(bankAccounts.id, bankAccountId)).limit(1);
    if (bank[0]) bankGl = bank[0].glAccount;
  }
  const newPaid = round2(invoice.paidAmount + payment);
  const newStatus = newPaid >= invoice.totalAmount - 0.005 ? "paid" : "partial";

  try {
    await db.transaction(async (tx) => {
      await tx.update(invoices).set({ paidAmount: newPaid, status: newStatus }).where(eq(invoices.id, invoice.id));
      await postJournal(tx as unknown as DbExecutor, {
        docNo: `RCT-${invoice.invoiceNo}-${Date.now().toString().slice(-4)}`,
        date: paidOn,
        module: "Sales",
        description: `Receipt against ${invoice.invoiceNo} — ${invoice.customerName}`,
        clientId: invoice.clientId,
        createdBy: user.id,
        lines: [
          { accountNo: bankGl, debit: payment, description: "Cash receipt" },
          { accountNo: AR_ACCOUNT, credit: payment, description: "Receivable settled" },
        ],
      });
    });
  } catch (error) {
    console.error("Receipt failed", error);
    fail("/invoices", "The receipt could not be posted. Please retry.", "payments");
  }

  await audit(user, "Recorded receipt", "Invoice", invoice.invoiceNo, `GHS ${payment.toFixed(2)} received`);
  freshPath("/invoices");
  ok("/invoices", `Receipt of GHS ${payment.toFixed(2)} recorded against ${invoice.invoiceNo}.`);
}

/* --------------------------------------------------------------- expenses */

export async function createExpenseAction(formData: FormData): Promise<void> {
  const user = await requireWriter();
  const vendor = text(formData, "vendor");
  const category = text(formData, "category");
  const netAmount = amount(formData, "netAmount");
  const vatInput = amount(formData, "vatAmount");
  const expenseDate = text(formData, "expenseDate") || today();
  const dueDate = text(formData, "dueDate") || addDays(expenseDate, 30);
  const clientIdRaw = text(formData, "clientId");
  const clientId = clientIdRaw ? Number(clientIdRaw) : null;

  if (!vendor) fail("/expenses", "Enter the supplier or vendor name.");
  if (!EXPENSE_ACCOUNTS[category]) fail("/expenses", "Choose a valid expense category.");
  if (netAmount <= 0) fail("/expenses", "Net expense must be greater than zero.");
  if (vatInput < 0) fail("/expenses", "VAT cannot be negative.");
  if (!DATE_RE.test(expenseDate) || !DATE_RE.test(dueDate)) fail("/expenses", "Enter valid expense and due dates.");

  const totalAmount = round2(netAmount + vatInput);
  const reference = await nextDocumentNumber("EXP", "expenses");
  const glAccount = EXPENSE_ACCOUNTS[category];

  try {
    await db.transaction(async (tx) => {
      await tx.insert(expenses).values({
        reference,
        clientId,
        vendor,
        category,
        description: text(formData, "description") || `${category} — ${vendor}`,
        netAmount,
        vatAmount: vatInput,
        totalAmount,
        paidAmount: 0,
        status: "approved",
        expenseDate,
        dueDate,
        glAccount,
        createdBy: user.id,
      });
      await postJournal(tx as unknown as DbExecutor, {
        docNo: `EXPJ-${reference}`,
        date: expenseDate,
        module: "Expenses",
        description: `${vendor} — ${category}`,
        clientId,
        createdBy: user.id,
        lines: [
          { accountNo: glAccount, debit: netAmount, description: category },
          ...(vatInput > 0 ? [{ accountNo: VAT_INPUT_ACCOUNT, debit: vatInput, description: "VAT input" }] : []),
          { accountNo: AP_ACCOUNT, credit: totalAmount, description: "Supplier payable" },
        ],
      });
    });
  } catch (error) {
    console.error("Expense creation failed", error);
    fail("/expenses", "The expense could not be saved. Please retry.");
  }

  await audit(user, "Recorded expense", "Expense", reference, `${vendor} · GHS ${totalAmount.toFixed(2)}`);
  freshPath("/expenses");
  ok("/expenses", `Expense ${reference} posted.`);
}

export async function payExpenseAction(formData: FormData): Promise<void> {
  const user = await requireWriter();
  const expenseId = Number(text(formData, "expenseId"));
  const payment = amount(formData, "amount");
  const bankAccountId = Number(text(formData, "bankAccountId"));
  const paidOn = today();
  const rows = await db.select().from(expenses).where(eq(expenses.id, expenseId)).limit(1);
  const expense = rows[0];
  if (!expense) fail("/expenses", "Expense not found.", "payments");
  if (expense.status === "paid") fail("/expenses", "This expense is already settled.");
  const outstanding = round2(expense.totalAmount - expense.paidAmount);
  if (payment <= 0) fail("/expenses", "Enter a payment amount greater than zero.");
  if (payment > outstanding + 0.005) fail("/expenses", "Payment exceeds the outstanding supplier balance.");

  let bankGl = DEFAULT_BANK_ACCOUNT;
  if (bankAccountId) {
    const bank = await db.select().from(bankAccounts).where(eq(bankAccounts.id, bankAccountId)).limit(1);
    if (bank[0]) bankGl = bank[0].glAccount;
  }
  const newPaid = round2(expense.paidAmount + payment);

  try {
    await db.transaction(async (tx) => {
      await tx
        .update(expenses)
        .set({ paidAmount: newPaid, status: newPaid >= expense.totalAmount - 0.005 ? "paid" : "approved" })
        .where(eq(expenses.id, expense.id));
      await postJournal(tx as unknown as DbExecutor, {
        docNo: `PMT-${expense.reference}-${Date.now().toString().slice(-4)}`,
        date: paidOn,
        module: "Banking",
        description: `Payment to ${expense.vendor}`,
        clientId: expense.clientId,
        createdBy: user.id,
        lines: [
          { accountNo: AP_ACCOUNT, debit: payment, description: "Payable settled" },
          { accountNo: bankGl, credit: payment, description: "Bank payment" },
        ],
      });
    });
  } catch (error) {
    console.error("Supplier payment failed", error);
    fail("/expenses", "The payment could not be posted. Please retry.", "payments");
  }
  await audit(user, "Paid supplier", "Expense", expense.reference, `GHS ${payment.toFixed(2)} to ${expense.vendor}`);
  freshPath("/expenses");
  ok("/expenses", `Payment to ${expense.vendor} posted.`);
}

/* ---------------------------------------------------------------- journal */

export type JournalState = { error?: string; ok?: string };

export async function createJournalAction(_prev: JournalState, formData: FormData): Promise<JournalState> {
  const user = await requireUser();
  if (user.role === "auditor") return { error: "Your auditor seat is read-only." };

  const description = text(formData, "description");
  const date = text(formData, "journalDate") || today();
  const clientIdRaw = text(formData, "clientId");
  const lines: Array<{ accountNo: string; debit: number; credit: number; description: string }> = [];
  for (let index = 0; index < 10; index += 1) {
    const accountNo = text(formData, `account_${index}`);
    const debit = amount(formData, `debit_${index}`);
    const credit = amount(formData, `credit_${index}`);
    if (!accountNo && debit === 0 && credit === 0) continue;
    if (!accountNo) return { error: `Line ${index + 1}: choose a ledger account.` };
    if (debit > 0 && credit > 0) return { error: `Line ${index + 1}: enter either a debit or a credit, not both.` };
    if (debit === 0 && credit === 0) continue;
    lines.push({ accountNo, debit, credit, description: text(formData, `lineDescription_${index}`) || description });
  }
  if (!description) return { error: "A journal description is required." };
  if (!DATE_RE.test(date)) return { error: "Enter a valid journal date." };
  if (lines.length < 2) return { error: "Add at least two journal lines." };

  const docNo = await nextDocumentNumber("JRN", "journals");
  try {
    const result = await db.transaction(async (tx) =>
      postJournal(tx as unknown as DbExecutor, {
        docNo,
        date,
        module: "Manual",
        description,
        clientId: clientIdRaw ? Number(clientIdRaw) : null,
        createdBy: user.id,
        lines,
      }),
    );
    if (result.error) return { error: result.error };
  } catch (error) {
    console.error("Manual journal failed", error);
    return { error: "The journal could not be posted. Please retry." };
  }

  await audit(user, "Posted journal", "Journal", docNo, description);
  freshPath("/journals");
  redirect(`/journals?ok=${encodeURIComponent(`Journal ${docNo} posted and ledger reconciled.`)}`);
}

/* ---------------------------------------------------------------- banking */

export async function recordBankTransactionAction(formData: FormData): Promise<void> {
  const user = await requireWriter();
  const bankAccountId = Number(text(formData, "bankAccountId"));
  const type = text(formData, "type");
  const value = amount(formData, "amount");
  const offsetAccount = text(formData, "offsetAccount");
  const date = text(formData, "date") || today();
  const description = text(formData, "description");

  const bank = (await db.select().from(bankAccounts).where(eq(bankAccounts.id, bankAccountId)).limit(1))[0];
  if (!bank) fail("/banking", "Choose a valid bank or cash account.");
  if (type !== "deposit" && type !== "withdrawal") fail("/banking", "Choose a deposit or a withdrawal.");
  if (value <= 0) fail("/banking", "Amount must be greater than zero.");
  if (!offsetAccount) fail("/banking", "Choose the counter account for this movement.");
  if (offsetAccount === bank.glAccount) fail("/banking", "The counter account must differ from the bank account.");
  if (!description) fail("/banking", "Add a short description for the movement.");
  if (!DATE_RE.test(date)) fail("/banking", "Enter a valid date.");

  const docNo = `BNK-${new Date().getFullYear()}-${Date.now().toString().slice(-6)}`;
  try {
    const result = await db.transaction(async (tx) =>
      postJournal(tx as unknown as DbExecutor, {
        docNo,
        date,
        module: "Banking",
        description,
        createdBy: user.id,
        lines:
          type === "deposit"
            ? [
                { accountNo: bank.glAccount, debit: value, description },
                { accountNo: offsetAccount, credit: value, description },
              ]
            : [
                { accountNo: offsetAccount, debit: value, description },
                { accountNo: bank.glAccount, credit: value, description },
              ],
      }),
    );
    if (result.error) fail("/banking", result.error);
  } catch (error) {
    console.error("Bank movement failed", error);
    fail("/banking", "The movement could not be posted.");
  }
  await audit(user, type === "deposit" ? "Bank deposit" : "Bank withdrawal", "Bank", bank.name, `GHS ${value.toFixed(2)} · ${description}`);
  freshPath("/banking");
  ok("/banking", `${type === "deposit" ? "Deposit" : "Withdrawal"} of GHS ${value.toFixed(2)} posted to ${bank.name}.`);
}

/* ---------------------------------------------------------------- payroll */

export async function runPayrollAction(formData: FormData): Promise<void> {
  const user = await requireWriter();
  const period = text(formData, "period");
  if (!/^\d{4}-\d{2}$/.test(period)) fail("/payroll", "Choose a valid payroll period.");

  const duplicate = await db.select({ id: payrollRuns.id }).from(payrollRuns).where(eq(payrollRuns.period, period)).limit(1);
  if (duplicate[0]) fail("/payroll", `A payroll run for ${period} already exists.`, "run");

  const staff = await db.select().from(employees).where(eq(employees.status, "active"));
  if (staff.length === 0) fail("/payroll", "Add active staff before running payroll.", "run");
  const payroll = computePayroll(staff);

  try {
    await db.transaction(async (tx) => {
      await tx.insert(payrollRuns).values({
        period,
        status: "approved",
        gross: payroll.gross,
        paye: payroll.paye,
        ssnitEmployee: payroll.ssnitEmployee,
        ssnitEmployer: payroll.ssnitEmployer,
        netPay: payroll.netPay,
        headcount: payroll.headcount,
        lines: payroll.lines,
        createdBy: user.id,
      });
      await postJournal(tx as unknown as DbExecutor, {
        docNo: `PAY-${period}`,
        date: `${period}-28`,
        module: "Payroll",
        description: `Payroll run for ${period} (${payroll.headcount} staff)`,
        createdBy: user.id,
        lines: [
          { accountNo: "5000", debit: payroll.gross, description: "Gross salaries" },
          { accountNo: "5010", debit: payroll.ssnitEmployer, description: "SSNIT employer 13%" },
          { accountNo: "2200", credit: payroll.paye, description: "PAYE withheld" },
          { accountNo: "2210", credit: round2(payroll.ssnitEmployee + payroll.ssnitEmployer), description: "SSNIT payable" },
          { accountNo: "2300", credit: payroll.netPay, description: "Net pay due to staff" },
        ],
      });
    });
  } catch (error) {
    console.error("Payroll run failed", error);
    fail("/payroll", "Payroll could not be posted. Please retry.", "run");
  }
  await audit(user, "Ran payroll", "Payroll", period, `${payroll.headcount} staff · net GHS ${payroll.netPay.toFixed(2)}`);
  freshPath("/payroll");
  ok("/payroll", `Payroll for ${period} approved: PAYE GHS ${payroll.paye.toFixed(2)}, SSNIT GHS ${payroll.ssnitEmployee.toFixed(2)}.`);
}

export async function markPayrollPaidAction(formData: FormData): Promise<void> {
  const user = await requireWriter();
  const runId = Number(text(formData, "runId"));
  const run = (await db.select().from(payrollRuns).where(and(eq(payrollRuns.id, runId), eq(payrollRuns.status, "approved"))).limit(1))[0];
  if (!run) fail("/payroll", "Approved payroll run not found.", "run");
  try {
    await db.transaction(async (tx) => {
      await tx.update(payrollRuns).set({ status: "paid" }).where(eq(payrollRuns.id, run.id));
      await postJournal(tx as unknown as DbExecutor, {
        docNo: `PAYPAY-${run.period}`,
        date: today(),
        module: "Payroll",
        description: `Net salaries disbursed for ${run.period}`,
        createdBy: user.id,
        lines: [
          { accountNo: "2300", debit: run.netPay, description: "Net pay settled" },
          { accountNo: "1020", credit: run.netPay, description: "Payroll bank account" },
        ],
      });
    });
  } catch (error) {
    console.error("Payroll settlement failed", error);
    fail("/payroll", "Could not settle payroll.", "run");
  }
  await audit(user, "Settled payroll", "Payroll", run.period, `Net GHS ${run.netPay.toFixed(2)} disbursed`);
  freshPath("/payroll");
  ok("/payroll", `Payroll for ${run.period} settled from the payroll bank account.`);
}

export async function addEmployeeAction(formData: FormData): Promise<void> {
  const user = await requireWriter();
  const name = text(formData, "name");
  const role = text(formData, "role");
  const department = text(formData, "department") || "Advisory";
  const basicSalary = amount(formData, "basicSalary");
  const allowances = amount(formData, "allowances");
  const startDate = text(formData, "startDate") || today();
  if (!name || !role) fail("/payroll", "Employee name and role are required.", "staff");
  if (basicSalary <= 0) fail("/payroll", "Basic salary must be greater than zero.", "staff");
  if (!DATE_RE.test(startDate)) fail("/payroll", "Enter a valid start date.", "staff");

  const count = await db.select({ id: employees.id }).from(employees);
  const staffNo = `BPZ-${String(count.length + 1).padStart(3, "0")}`;
  try {
    await db.insert(employees).values({
      staffNo,
      name,
      role,
      department,
      basicSalary,
      allowances,
      ssnitNo: text(formData, "ssnitNo") || "PENDING",
      tin: text(formData, "tin") || "PENDING",
      status: text(formData, "status") === "on_leave" ? "on_leave" : "active",
      startDate,
    });
  } catch (error) {
    console.error("Add employee failed", error);
    fail("/payroll", "Could not add the employee. Check the staff number.", "staff");
  }
  await audit(user, "Added employee", "Employee", staffNo, `${name} · ${role}`);
  freshPath("/payroll");
  ok("/payroll", `${name} added to payroll as ${staffNo}.`);
}
