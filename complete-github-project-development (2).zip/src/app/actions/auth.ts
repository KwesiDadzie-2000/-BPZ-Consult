"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import {
  changePassword,
  destroyAllSessions,
  destroyCurrentSession,
  login,
  requireUser,
  requestPasswordReset,
  resetPasswordWithToken,
  revokeSession,
  SESSION_COOKIE,
  sessionCookieOptions,
} from "@/lib/auth";
import { cookies } from "next/headers";
import { ensureSeed } from "@/lib/seed";
import { passwordPolicyError } from "@/lib/password";

export type LoginState = {
  error?: string;
  lockedForSeconds?: number;
  identifier?: string;
};

export async function loginAction(_prev: LoginState, formData: FormData): Promise<LoginState> {
  const identifier = String(formData.get("identifier") ?? "");
  const password = String(formData.get("password") ?? "");
  try {
    await ensureSeed();
    const result = await login(identifier, password);
    if (!result.ok) {
      return { error: result.error, lockedForSeconds: result.lockedForSeconds, identifier };
    }
    const store = await cookies();
    store.set(SESSION_COOKIE, result.token, await sessionCookieOptions());
  } catch (error) {
    console.error("Login failed", error);
    return { error: "The sign-in service is unavailable. Please try again in a moment.", identifier };
  }
  redirect("/dashboard");
}

export async function signOutAction(): Promise<void> {
  await destroyCurrentSession();
  redirect("/login?ok=You+have+been+signed+out+securely.");
}

export type ResetRequestState = {
  error?: string;
  resetUrl?: string;
  expiresInMinutes?: number;
  identifier?: string;
};

export async function requestResetAction(_prev: ResetRequestState, formData: FormData): Promise<ResetRequestState> {
  const identifier = String(formData.get("identifier") ?? "");
  try {
    await ensureSeed();
    const result = await requestPasswordReset(identifier);
    if (!result.ok) return { error: result.error, identifier };
    return { resetUrl: result.resetUrl, expiresInMinutes: 30, identifier };
  } catch (error) {
    console.error("Reset request failed", error);
    return { error: "Could not generate a reset link. Please try again.", identifier };
  }
}

export type ResetState = { error?: string; ok?: boolean };

export async function resetPasswordAction(_prev: ResetState, formData: FormData): Promise<ResetState> {
  const token = String(formData.get("token") ?? "");
  const password = String(formData.get("password") ?? "");
  const confirm = String(formData.get("confirmPassword") ?? "");
  const result = await resetPasswordWithToken(token, password, confirm);
  if (!result.ok) return { error: result.error };
  return { ok: true };
}

export type SettingsState = { error?: string; ok?: string };

export async function updateProfileAction(_prev: SettingsState, formData: FormData): Promise<SettingsState> {
  const user = await requireUser();
  const name = String(formData.get("name") ?? "").trim();
  const email = String(formData.get("email") ?? "").trim().toLowerCase();
  const jobTitle = String(formData.get("jobTitle") ?? "").trim();
  if (name.length < 2) return { error: "Enter your full name." };
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return { error: "Enter a valid email address." };
  if (email !== user.email) {
    const clash = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
    if (clash[0]) return { error: "Another account already uses that email." };
  }
  await db.update(users).set({ name, email, jobTitle: jobTitle || user.jobTitle }).where(eq(users.id, user.id));
  revalidatePath("/settings");
  return { ok: "Profile updated." };
}

export async function changePasswordAction(_prev: SettingsState, formData: FormData): Promise<SettingsState> {
  const user = await requireUser();
  const current = String(formData.get("currentPassword") ?? "");
  const next = String(formData.get("newPassword") ?? "");
  const confirm = String(formData.get("confirmPassword") ?? "");
  const policyError = passwordPolicyError(next);
  if (policyError) return { error: policyError };
  const result = await changePassword(user, current, next, confirm);
  if (!result.ok) return { error: result.error };
  return { ok: "Password changed. Keep it somewhere safe." };
}

export async function signOutEverywhereAction(): Promise<void> {
  const user = await requireUser();
  await destroyAllSessions(user.id);
  redirect("/login?ok=All+sessions+revoked.+Sign+in+again.");
}

export async function revokeSessionAction(formData: FormData): Promise<void> {
  const user = await requireUser();
  const sessionId = String(formData.get("sessionId") ?? "");
  if (sessionId) await revokeSession(user.id, sessionId);
  revalidatePath("/settings");
}
