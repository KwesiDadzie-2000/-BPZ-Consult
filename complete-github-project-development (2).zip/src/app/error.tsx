"use client";

import Link from "next/link";
import { useEffect } from "react";
import { AlertTriangle, RotateCcw } from "lucide-react";

export default function AppError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    console.error("Unhandled application error", error?.message, error?.digest, error);
  }, [error]);

  return (
    <main className="flex min-h-screen items-center justify-center bg-mist px-4 py-12">
      <div className="card w-full max-w-lg p-6 text-center">
        <span className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-amber-50 text-amber-600">
          <AlertTriangle className="h-6 w-6" />
        </span>
        <h1 className="mt-4 text-xl font-black tracking-tight text-navy">Something interrupted that page</h1>
        <p className="mt-1.5 text-[0.85rem] font-medium text-muted">
          Your data is safe — nothing was half-posted. The workspace could not finish rendering this screen, so try again.
        </p>
        {error?.message ? (
          <p className="mt-2 rounded-lg bg-mist px-3 py-2 text-left font-mono text-[0.68rem] text-navy/80">
            {error.message.slice(0, 240)}
          </p>
        ) : null}
        {error?.digest ? <p className="mt-2 font-mono text-[0.66rem] text-muted">Reference {error.digest}</p> : null}
        <div className="mt-5 flex flex-wrap justify-center gap-2">
          <button type="button" onClick={reset} className="btn btn-primary">
            <RotateCcw className="h-3.5 w-3.5" /> Reload this page
          </button>
          <Link href="/dashboard" className="btn btn-ghost">
            Go to dashboard
          </Link>
          <Link href="/login" className="btn btn-quiet">
            Sign in again
          </Link>
        </div>
        <p className="mt-4 text-[0.7rem] font-medium text-muted">
          If this repeats, open the browser console (F12) and share the message above with support.
        </p>
      </div>
    </main>
  );
}
