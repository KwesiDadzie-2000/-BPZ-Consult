"use client";

export default function GlobalError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <html lang="en">
      <body
        style={{
          margin: 0,
          minHeight: "100vh",
          display: "grid",
          placeItems: "center",
          background: "#f0f6fc",
          fontFamily: "ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, sans-serif",
          color: "#102a43",
          padding: "24px",
        }}
      >
        <div
          style={{
            maxWidth: "520px",
            background: "#fff",
            border: "1px solid #dbe7f2",
            borderRadius: "16px",
            padding: "28px",
            textAlign: "center",
            boxShadow: "0 12px 28px -24px rgba(10,47,82,0.45)",
          }}
        >
          <div
            style={{
              display: "inline-grid",
              placeItems: "center",
              width: "46px",
              height: "46px",
              borderRadius: "12px",
              background: "#f5b719",
              color: "#06233d",
              fontWeight: 900,
              letterSpacing: "-0.02em",
            }}
          >
            BPZ
          </div>
          <h1 style={{ margin: "16px 0 6px", fontSize: "1.25rem", fontWeight: 900, color: "#0a2f52" }}>
            BPZ Consult could not start that screen
          </h1>
          <p style={{ margin: 0, fontSize: "0.86rem", lineHeight: 1.6, color: "#5b7288", fontWeight: 500 }}>
            The workspace hit an unexpected error. Reload to try again — your posted transactions are stored server-side and
            remain intact.
          </p>
          {error.digest ? (
            <p style={{ margin: "10px 0 0", fontSize: "0.68rem", color: "#5b7288", fontFamily: "monospace" }}>
              Reference {error.digest}
            </p>
          ) : null}
          <div style={{ marginTop: "18px", display: "flex", gap: "8px", justifyContent: "center", flexWrap: "wrap" }}>
            <button
              type="button"
              onClick={reset}
              style={{
                background: "#0a2f52",
                color: "#fff",
                border: "none",
                borderRadius: "9px",
                padding: "10px 18px",
                fontWeight: 800,
                fontSize: "0.82rem",
                cursor: "pointer",
              }}
            >
              Reload
            </button>
            <a
              href="/login"
              style={{
                background: "#fff",
                color: "#0a2f52",
                border: "1px solid #dbe7f2",
                borderRadius: "9px",
                padding: "10px 18px",
                fontWeight: 800,
                fontSize: "0.82rem",
                textDecoration: "none",
              }}
            >
              Back to sign in
            </a>
          </div>
        </div>
      </body>
    </html>
  );
}
