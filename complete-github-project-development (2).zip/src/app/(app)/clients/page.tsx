import { desc } from "drizzle-orm";
import Link from "next/link";
import { Building2, Mail, Phone, Plus } from "lucide-react";
import { db } from "@/db";
import { clients, invoices } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { money, prettyDate, round2 } from "@/lib/format";
import { Badge, Card, EmptyState, Field, Flash, PageHeader, Panel, Progress, StatCard, statusTone } from "@/components/ui";
import { SubmitButton } from "@/components/submit-button";
import { createClientAction, updateClientAction } from "@/app/actions/practice";

export const dynamic = "force-dynamic";
export const metadata = { title: "Clients — BPZ Consult" };

const SECTORS = ["Agribusiness", "Renewable energy", "Transport & logistics", "FMCG manufacturing", "Healthcare", "Real estate", "Financial services", "Technology", "Professional services"];
const SERVICES = ["Audit & assurance", "Advisory & consulting", "Tax services", "Bookkeeping & payroll", "Audit & assurance, Tax services", "Advisory & consulting, Bookkeeping"];

export default async function ClientsPage({
  searchParams,
}: {
  searchParams: Promise<{ ok?: string; error?: string; panel?: string }>;
}) {
  await requireUser();
  const params = await searchParams;
  const [clientRows, invoiceRows] = await Promise.all([
    db.select().from(clients).orderBy(clients.name),
    db.select().from(invoices).orderBy(desc(invoices.issueDate)),
  ]);

  const metrics = new Map<number, { billed: number; open: number; last: string | null; invoices: number }>();
  for (const invoice of invoiceRows) {
    if (invoice.clientId == null) continue;
    const entry = metrics.get(invoice.clientId) ?? { billed: 0, open: 0, last: null, invoices: 0 };
    if (invoice.status !== "draft") {
      entry.billed = round2(entry.billed + invoice.totalAmount);
      entry.open = round2(entry.open + (invoice.totalAmount - invoice.paidAmount));
      entry.invoices += 1;
      if (!entry.last || invoice.issueDate > entry.last) entry.last = invoice.issueDate;
    }
    metrics.set(invoice.clientId, entry);
  }

  const totalBilled = [...metrics.values()].reduce((sum, entry) => sum + entry.billed, 0);
  const totalOpen = [...metrics.values()].reduce((sum, entry) => sum + entry.open, 0);
  const activeCount = clientRows.filter((client) => client.status === "active").length;

  return (
    <div className="space-y-4">
      <PageHeader
        eyebrow="Client book"
        title="Clients & engagements"
        description="The firms, contacts and services behind the numbers — with revenue and collection health."
        actions={<a href="#new-client" className="btn btn-primary"><Plus className="h-3.5 w-3.5" /> Onboard client</a>}
      />

      <Flash ok={params.ok} error={params.error} />

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Clients" value={String(clientRows.length)} sub={`${activeCount} active engagements`} icon={<Building2 className="h-4 w-4" />} />
        <StatCard label="Lifetime billed" value={money(totalBilled, { compact: true })} sub="Issued invoices, VAT inclusive" tone="gold" />
        <StatCard label="Open balances" value={money(totalOpen, { compact: true })} sub="Across the client book" tone="blue" />
        <StatCard label="Average health" value={`${Math.round(clientRows.reduce((sum, client) => sum + client.healthScore, 0) / Math.max(1, clientRows.length))}%`} sub="Relationship score" tone="green" />
      </div>

      <Panel
        id="new-client"
        title="Onboard a client"
        description="Client codes are generated automatically; health score drives the review prioritisation."
        cta="Onboard client"
        defaultOpen={params.panel === "new"}
      >
        <form action={createClientAction} className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          <Field label="Legal name" htmlFor="name">
            <input id="name" name="name" required className="input" placeholder="e.g. Ashanti Cocoa Traders Ltd" />
          </Field>
          <Field label="Sector" htmlFor="sector">
            <select id="sector" name="sector" className="select" defaultValue="Agribusiness">
              {SECTORS.map((sector) => <option key={sector} value={sector}>{sector}</option>)}
            </select>
          </Field>
          <Field label="Services" htmlFor="services">
            <select id="services" name="services" className="select" defaultValue={SERVICES[0]}>
              {SERVICES.map((service) => <option key={service} value={service}>{service}</option>)}
            </select>
          </Field>
          <Field label="Contact name" htmlFor="contactName">
            <input id="contactName" name="contactName" className="input" placeholder="e.g. Nana Adjei" />
          </Field>
          <Field label="Contact email" htmlFor="contactEmail">
            <input id="contactEmail" name="contactEmail" type="email" className="input" placeholder="finance@client.com" />
          </Field>
          <Field label="Phone" htmlFor="phone">
            <input id="phone" name="phone" className="input" placeholder="+233 …" />
          </Field>
          <Field label="Health score" htmlFor="healthScore" hint="0–100. Used in portfolio reviews.">
            <input id="healthScore" name="healthScore" type="number" min="0" max="100" defaultValue="75" className="input" />
          </Field>
          <Field label="Currency" htmlFor="currency">
            <select id="currency" name="currency" className="select" defaultValue="GHS">
              {["GHS", "USD", "GBP", "EUR"].map((currency) => <option key={currency} value={currency}>{currency}</option>)}
            </select>
          </Field>
          <Field label="Notes" htmlFor="notes">
            <input id="notes" name="notes" className="input" placeholder="Scope, deadlines or risks" />
          </Field>
          <div className="flex items-end">
            <SubmitButton>Create client</SubmitButton>
          </div>
        </form>
      </Panel>

      <Panel title="Update engagement health" description="Keep the portfolio review current as engagements progress." cta="Update client">
        <form action={updateClientAction} className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <Field label="Client" htmlFor="clientId" className="lg:col-span-2">
            <select id="clientId" name="clientId" className="select" required defaultValue="">
              <option value="" disabled>Choose client…</option>
              {clientRows.map((client) => <option key={client.id} value={client.id}>{client.code} · {client.name}</option>)}
            </select>
          </Field>
          <Field label="Status" htmlFor="status">
            <select id="status" name="status" className="select" defaultValue="active">
              <option value="active">Active</option>
              <option value="onboarding">Onboarding</option>
              <option value="dormant">Dormant</option>
            </select>
          </Field>
          <Field label="Health score" htmlFor="healthScoreUpdate">
            <div className="flex items-end gap-2">
              <input id="healthScoreUpdate" name="healthScore" type="number" min="0" max="100" defaultValue="80" className="input" />
              <SubmitButton className="shrink-0">Save</SubmitButton>
            </div>
          </Field>
        </form>
      </Panel>

      {clientRows.length === 0 ? (
        <EmptyState title="No clients yet" message="Onboard your first client to start booking revenue and engagements." />
      ) : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {clientRows.map((client) => {
            const stats = metrics.get(client.id) ?? { billed: 0, open: 0, last: null, invoices: 0 };
            return (
              <Card key={client.id} className="flex flex-col">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="truncate text-[0.92rem] font-extrabold text-navy">{client.name}</p>
                    <p className="text-[0.68rem] font-bold uppercase tracking-wide text-muted">{client.code} · {client.sector}</p>
                  </div>
                  <Badge tone={statusTone(client.status)}>{client.status}</Badge>
                </div>

                <div className="mt-3 space-y-1.5 text-[0.72rem] font-medium text-muted">
                  {client.contactName ? <p className="font-semibold text-ink">{client.contactName}</p> : null}
                  {client.contactEmail ? <p className="flex items-center gap-1.5 truncate"><Mail className="h-3 w-3" /> {client.contactEmail}</p> : null}
                  {client.phone ? <p className="flex items-center gap-1.5"><Phone className="h-3 w-3" /> {client.phone}</p> : null}
                </div>

                <div className="mt-3 flex flex-wrap gap-1">
                  {client.services.split(",").map((service) => (
                    <Badge key={service} tone="slate">{service.trim()}</Badge>
                  ))}
                </div>

                <div className="mt-3 grid grid-cols-2 gap-2 rounded-xl bg-[#f7fafd] p-2.5">
                  <div>
                    <p className="text-[0.58rem] font-extrabold uppercase tracking-wide text-muted">Billed</p>
                    <p className="text-[0.8rem] font-extrabold text-navy">{money(stats.billed, { compact: true })}</p>
                  </div>
                  <div>
                    <p className="text-[0.58rem] font-extrabold uppercase tracking-wide text-muted">Open balance</p>
                    <p className={`text-[0.8rem] font-extrabold ${stats.open > 0 ? "text-amber-700" : "text-emerald-600"}`}>{money(stats.open, { compact: true })}</p>
                  </div>
                </div>

                <div className="mt-3">
                  <div className="flex items-center justify-between text-[0.66rem] font-bold text-muted">
                    <span>Relationship health</span>
                    <span>{client.healthScore}%</span>
                  </div>
                  <div className="mt-1"><Progress value={client.healthScore} tone={client.healthScore >= 75 ? "green" : client.healthScore >= 60 ? "gold" : "navy"} /></div>
                </div>

                {client.notes ? <p className="mt-3 rounded-lg bg-mist px-2.5 py-2 text-[0.68rem] font-medium leading-relaxed text-navy">{client.notes}</p> : null}

                <div className="mt-auto flex items-center justify-between pt-3 text-[0.68rem] font-semibold text-muted">
                  <span>{stats.invoices} invoices{stats.last ? ` · last ${prettyDate(stats.last)}` : ""}</span>
                  <Link href={`/invoices?q=${encodeURIComponent(client.name)}`} className="font-bold text-sky-700 hover:underline">Invoices</Link>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
