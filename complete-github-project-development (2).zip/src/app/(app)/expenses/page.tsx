import Link from "next/link";
import { desc } from "drizzle-orm";
import { Plus } from "lucide-react";
import { db } from "@/db";
import { bankAccounts, clients, expenses } from "@/db/schema";
import { EXPENSE_ACCOUNTS } from "@/lib/accounting";
import { addDays, money, prettyDate, round2, today } from "@/lib/format";
import { requireUser } from "@/lib/auth";
import { Badge, Card, EmptyState, Field, FilterBar, Flash, PageHeader, Panel, StatCard, TableWrap, statusTone } from "@/components/ui";
import { SubmitButton } from "@/components/submit-button";
import { createExpenseAction, payExpenseAction } from "@/app/actions/ledger";

export const dynamic = "force-dynamic";
export const metadata = { title: "Expenses — BPZ Consult" };

export default async function ExpensesPage({
  searchParams,
}: {
  searchParams: Promise<{ ok?: string; error?: string; panel?: string; q?: string; status?: string }>;
}) {
  await requireUser();
  const params = await searchParams;
  const [expenseRows, clientRows, bankRows] = await Promise.all([
    db.select().from(expenses).orderBy(desc(expenses.expenseDate), desc(expenses.id)),
    db.select().from(clients).orderBy(clients.name),
    db.select().from(bankAccounts).orderBy(bankAccounts.id),
  ]);

  const q = (params.q ?? "").toLowerCase();
  const statusFilter = params.status ?? "all";
  const filtered = expenseRows.filter((expense) => {
    const matchesStatus = statusFilter === "all" ? true : statusFilter === "open" ? expense.status !== "paid" : expense.status === statusFilter;
    const matchesQuery = !q || expense.vendor.toLowerCase().includes(q) || expense.category.toLowerCase().includes(q) || expense.reference.toLowerCase().includes(q);
    return matchesStatus && matchesQuery;
  });

  const total = round2(expenseRows.reduce((sum, expense) => sum + expense.totalAmount, 0));
  const paid = round2(expenseRows.reduce((sum, expense) => sum + expense.paidAmount, 0));
  const payable = round2(total - paid);
  const vatRecoverable = round2(expenseRows.reduce((sum, expense) => sum + expense.vatAmount, 0));
  const openExpenses = expenseRows.filter((expense) => expense.status !== "paid");

  return (
    <div className="space-y-4">
      <PageHeader
        eyebrow="Cost control"
        title="Expenses & supplier bills"
        description="Capture operating costs, recover VAT input and settle supplier payables."
        actions={
          <>
            <Link href="/reports?tab=pl" className="btn btn-ghost">Cost report</Link>
            <a href="#new-expense" className="btn btn-primary"><Plus className="h-3.5 w-3.5" /> New expense</a>
          </>
        }
      />

      <Flash ok={params.ok} error={params.error} />

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Total costs" value={money(total, { compact: true })} sub={`${expenseRows.length} supplier bills`} />
        <StatCard label="Paid" value={money(paid, { compact: true })} sub={`${round2((paid / Math.max(1, total)) * 100)}% settled`} tone="green" />
        <StatCard label="Supplier payables" value={money(payable, { compact: true })} sub={`${openExpenses.length} open bills`} tone="gold" />
        <StatCard label="VAT input" value={money(vatRecoverable, { compact: true })} sub="Recoverable from GRA" tone="blue" />
      </div>

      <Panel
        id="new-expense"
        title="Capture a supplier bill"
        description="Choose the natural expense account — the payable and VAT input post automatically."
        cta="New expense"
        defaultOpen={params.panel === "new"}
      >
        <form action={createExpenseAction} className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          <Field label="Vendor" htmlFor="vendor">
            <input id="vendor" name="vendor" required className="input" placeholder="e.g. Landlord — Ridge Towers" />
          </Field>
          <Field label="Expense category" htmlFor="category">
            <select id="category" name="category" className="select" required defaultValue="Professional fees">
              {Object.keys(EXPENSE_ACCOUNTS).map((category) => (
                <option key={category} value={category}>{category}</option>
              ))}
            </select>
          </Field>
          <Field label="Net amount (GHS)" htmlFor="netAmount">
            <input id="netAmount" name="netAmount" type="number" min="0.01" step="0.01" required className="input" placeholder="0.00" />
          </Field>
          <Field label="VAT input (GHS)" htmlFor="vatAmount" hint="Enter 0 where the supplier is not VAT registered.">
            <input id="vatAmount" name="vatAmount" type="number" min="0" step="0.01" defaultValue="0" className="input" />
          </Field>
          <Field label="Expense date" htmlFor="expenseDate">
            <input id="expenseDate" name="expenseDate" type="date" defaultValue={today()} className="input" required />
          </Field>
          <Field label="Payment due" htmlFor="dueDate">
            <input id="dueDate" name="dueDate" type="date" defaultValue={addDays(today(), 30)} className="input" required />
          </Field>
          <Field label="Related client (optional)" htmlFor="clientId" hint="Tag client-recharged costs for recovery.">
            <select id="clientId" name="clientId" className="select" defaultValue="">
              <option value="">Firm overhead (no client)</option>
              {clientRows.map((client) => (
                <option key={client.id} value={client.id}>{client.code} · {client.name}</option>
              ))}
            </select>
          </Field>
          <Field label="Description" htmlFor="description" className="lg:col-span-2">
            <input id="description" name="description" className="input" placeholder="What was purchased?" />
          </Field>
          <div className="flex items-end">
            <SubmitButton>Post expense</SubmitButton>
          </div>
        </form>
      </Panel>

      <Panel
        title="Settle a supplier bill"
        description="Clears the payable from the bank account and keeps cash movement reconciled."
        cta="Pay supplier"
        defaultOpen={params.panel === "payments"}
      >
        {openExpenses.length === 0 ? (
          <p className="text-[0.8rem] font-semibold text-muted">No supplier bills are outstanding.</p>
        ) : (
          <form action={payExpenseAction} className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <Field label="Open bill" htmlFor="expenseId" className="lg:col-span-2">
              <select id="expenseId" name="expenseId" className="select" required defaultValue="">
                <option value="" disabled>Choose supplier bill…</option>
                {openExpenses.map((expense) => (
                  <option key={expense.id} value={expense.id}>
                    {expense.reference} · {expense.vendor} · {money(expense.totalAmount - expense.paidAmount)}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Amount (GHS)" htmlFor="amount">
              <input id="amount" name="amount" type="number" min="0.01" step="0.01" required className="input" placeholder="0.00" />
            </Field>
            <Field label="Paid from" htmlFor="bankAccountId">
              <div className="flex items-end gap-2">
                <select id="bankAccountId" name="bankAccountId" className="select" defaultValue={String(bankRows[0]?.id ?? "")}>
                  {bankRows.map((bank) => (
                    <option key={bank.id} value={bank.id}>{bank.name}</option>
                  ))}
                </select>
                <SubmitButton className="shrink-0">Pay</SubmitButton>
              </div>
            </Field>
          </form>
        )}
      </Panel>

      <Card padded={false}>
        <div className="flex flex-col gap-3 border-b border-line px-4 py-3.5 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="text-[0.92rem] font-extrabold text-navy">Expense register</h2>
            <p className="text-[0.72rem] font-medium text-muted">{filtered.length} of {expenseRows.length} bills</p>
          </div>
          <form method="get" className="w-full sm:w-auto">
            <FilterBar>
              <input name="q" defaultValue={params.q ?? ""} placeholder="Search vendor or category" className="input w-full sm:w-52" />
              <select name="status" defaultValue={statusFilter} className="select w-full sm:w-36">
                <option value="all">All statuses</option>
                <option value="open">Open bills</option>
                <option value="approved">Approved</option>
                <option value="paid">Paid</option>
              </select>
              <button type="submit" className="btn btn-ghost">Filter</button>
              <Link href="/expenses" className="btn btn-quiet">Reset</Link>
            </FilterBar>
          </form>
        </div>

        {filtered.length === 0 ? (
          <div className="p-4">
            <EmptyState title="No expenses found" message="Capture a supplier bill to start tracking costs." />
          </div>
        ) : (
          <TableWrap className="rounded-none border-0">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Reference</th>
                  <th>Vendor</th>
                  <th>Category</th>
                  <th>Date</th>
                  <th className="num">Net</th>
                  <th className="num">VAT</th>
                  <th className="num">Total</th>
                  <th className="num">Outstanding</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((expense) => {
                  const balance = round2(expense.totalAmount - expense.paidAmount);
                  return (
                    <tr key={expense.id}>
                      <td className="whitespace-nowrap font-extrabold text-navy">{expense.reference}</td>
                      <td className="max-w-[190px] truncate text-[0.78rem] font-semibold">{expense.vendor}</td>
                      <td className="whitespace-nowrap text-[0.72rem] text-muted">{expense.category}</td>
                      <td className="whitespace-nowrap text-[0.72rem] text-muted">{prettyDate(expense.expenseDate)}</td>
                      <td className="num">{money(expense.netAmount)}</td>
                      <td className="num text-muted">{money(expense.vatAmount)}</td>
                      <td className="num font-bold text-navy">{money(expense.totalAmount)}</td>
                      <td className="num font-bold">{balance > 0 ? money(balance) : <span className="text-emerald-600">Settled</span>}</td>
                      <td><Badge tone={statusTone(expense.status)}>{expense.status}</Badge></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </TableWrap>
        )}
      </Card>

      <p className="text-[0.7rem] font-medium text-muted">
        Each bill posts Dr Expense · Dr VAT input · Cr Accounts payable. Supplier payments clear the payable against the chosen bank account.
      </p>
    </div>
  );
}
