import Link from "next/link";
import { financialStatements, monthlySeries } from "@/lib/accounting";
import { requireUser } from "@/lib/auth";
import { money, monthLabel, round2 } from "@/lib/format";
import { Badge, Bars, Card, CardHeader, EmptyState, PageHeader, StatCard } from "@/components/ui";
import { PrintButton } from "./print-button";

export const dynamic = "force-dynamic";
export const metadata = { title: "Financial reports — BPZ Consult" };

type Tab = "pl" | "bs" | "tb";

const TABS: Array<{ id: Tab; label: string }> = [
  { id: "pl", label: "Profit & loss" },
  { id: "bs", label: "Balance sheet" },
  { id: "tb", label: "Trial balance" },
];

function StatementRows({ rows, total }: { rows: Array<{ accountNo: string; name: string; balance: number }>; total: number }) {
  if (rows.length === 0) return <EmptyState title="No balances" message="Post journals to populate this section." />;
  return (
    <>
      <table className="data-table">
        <tbody>
          {rows.map((row) => (
            <tr key={row.accountNo}>
              <td className="w-16 font-mono text-[0.7rem] font-bold text-muted">{row.accountNo}</td>
              <td className="text-[0.78rem] font-semibold text-ink">{row.name}</td>
              <td className="num font-bold text-navy">{money(row.balance)}</td>
            </tr>
          ))}
          <tr className="bg-[#f7fafd]">
            <td />
            <td className="font-extrabold text-navy">Total</td>
            <td className="num font-extrabold text-navy">{money(total)}</td>
          </tr>
        </tbody>
      </table>
    </>
  );
}

export default async function ReportsPage({ searchParams }: { searchParams: Promise<{ tab?: string }> }) {
  const user = await requireUser();
  const params = await searchParams;
  const tab: Tab = params.tab === "bs" ? "bs" : params.tab === "tb" ? "tb" : "pl";
  const [statements, series] = await Promise.all([financialStatements(), monthlySeries(6)]);
  const margin = statements.totalIncome > 0 ? round2((statements.netProfit / statements.totalIncome) * 100) : 0;
  const bsDifference = round2(statements.totalAssets - (statements.totalLiabilities + statements.totalEquity));

  return (
    <div className="space-y-4">
      <PageHeader
        eyebrow="Insight"
        title="Financial reports"
        description="Generated live from posted journals. Figures are in Ghana cedis unless stated."
        actions={<PrintButton />}
      />

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Total income" value={money(statements.totalIncome, { compact: true })} sub="All posted income accounts" />
        <StatCard label="Total expenses" value={money(statements.totalExpenses, { compact: true })} sub={`${statements.expenses.length} expense accounts`} tone="gold" />
        <StatCard label="Net profit" value={money(statements.netProfit, { compact: true })} sub={`${margin}% net margin`} tone="green" />
        <StatCard label="Trial balance" value={statements.balanced ? "Balanced" : "Review"} sub={`Dr ${money(statements.trialDebit, { compact: true })} · Cr ${money(statements.trialCredit, { compact: true })}`} tone="blue" />
      </div>

      <div className="no-print flex flex-wrap items-center gap-2">
        {TABS.map((item) => (
          <Link key={item.id} href={`/reports?tab=${item.id}`} className={tab === item.id ? "btn btn-primary btn-sm" : "btn btn-ghost btn-sm"}>
            {item.label}
          </Link>
        ))}
        <span className="ml-auto text-[0.7rem] font-semibold text-muted">
          Prepared by {user.name} · {user.jobTitle}
        </span>
      </div>

      {tab === "pl" ? (
        <div className="grid gap-4 xl:grid-cols-[1.5fr_1fr]">
          <Card>
            <CardHeader
              title="Statement of profit or loss"
              subtitle="For the period to date · GHS"
              action={<Badge tone={statements.netProfit >= 0 ? "green" : "red"}>{statements.netProfit >= 0 ? "Profitable" : "Loss"}</Badge>}
            />
            <div className="space-y-5">
              <div>
                <h3 className="mb-1 text-[0.68rem] font-extrabold uppercase tracking-[0.12em] text-muted">Revenue</h3>
                <StatementRows rows={statements.income} total={statements.totalIncome} />
              </div>
              <div>
                <h3 className="mb-1 text-[0.68rem] font-extrabold uppercase tracking-[0.12em] text-muted">Operating expenses</h3>
                <StatementRows rows={statements.expenses} total={statements.totalExpenses} />
              </div>
              <div className="flex items-center justify-between rounded-xl bg-navy px-4 py-3 text-white">
                <p className="text-[0.82rem] font-extrabold">Net profit / (loss)</p>
                <p className="text-[1.05rem] font-extrabold tabular-nums text-gold">{money(statements.netProfit)}</p>
              </div>
            </div>
          </Card>
          <div className="space-y-4">
            <Card>
              <CardHeader title="Revenue vs cost trend" subtitle="Last six months" />
              <Bars series={series.map((point) => ({ ...point, label: monthLabel(point.key) }))} />
            </Card>
            <Card>
              <CardHeader title="Key ratios" subtitle="Derived from the current ledger" />
              <dl className="space-y-2 text-[0.78rem]">
                {[
                  ["Gross / net margin", `${margin}%`],
                  ["Cost ratio", `${statements.totalIncome > 0 ? Math.round((statements.totalExpenses / statements.totalIncome) * 100) : 0}%`],
                  ["Receivables", money(statements.assets.find((row) => row.accountNo === "1100")?.balance ?? 0)],
                  ["Payables", money(statements.liabilities.find((row) => row.accountNo === "2000")?.balance ?? 0)],
                  ["Cash & bank", money(statements.assets.filter((row) => row.accountNo.startsWith("10")).reduce((sum, row) => sum + row.balance, 0))],
                ].map(([label, value]) => (
                  <div key={label} className="flex items-center justify-between border-b border-line pb-1.5 last:border-0">
                    <dt className="font-semibold text-muted">{label}</dt>
                    <dd className="font-extrabold text-navy">{value}</dd>
                  </div>
                ))}
              </dl>
            </Card>
          </div>
        </div>
      ) : null}

      {tab === "bs" ? (
        <div className="grid gap-4 lg:grid-cols-2">
          <Card>
            <CardHeader title="Assets" subtitle="What the firm owns" action={<Badge tone="blue">GHS</Badge>} />
            <StatementRows rows={statements.assets} total={statements.totalAssets} />
          </Card>
          <div className="space-y-4">
            <Card>
              <CardHeader title="Liabilities" subtitle="What the firm owes" action={<Badge tone="amber">GHS</Badge>} />
              <StatementRows rows={statements.liabilities} total={statements.totalLiabilities} />
            </Card>
            <Card>
              <CardHeader title="Equity" subtitle="Owner capital and current earnings" action={<Badge tone="green">GHS</Badge>} />
              <StatementRows rows={statements.equity} total={statements.totalEquity} />
            </Card>
            <div className={`flex items-center justify-between rounded-xl px-4 py-3 text-white ${Math.abs(bsDifference) < 0.005 ? "bg-emerald-700" : "bg-rose-700"}`}>
              <div>
                <p className="text-[0.8rem] font-extrabold">Assets = Liabilities + Equity</p>
                <p className="text-[0.68rem] font-medium text-white/70">Difference {money(bsDifference)}</p>
              </div>
              <Badge tone="green">{Math.abs(bsDifference) < 0.005 ? "Balanced" : "Check"}</Badge>
            </div>
          </div>
        </div>
      ) : null}

      {tab === "tb" ? (
        <Card padded={false}>
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-line px-4 py-3.5">
            <div>
              <h2 className="text-[0.92rem] font-extrabold text-navy">Trial balance</h2>
              <p className="text-[0.72rem] font-medium text-muted">All posted ledger movements, debit and credit columns</p>
            </div>
            <Badge tone={statements.balanced ? "green" : "red"}>{statements.balanced ? "Debits equal credits" : "Out of balance"}</Badge>
          </div>
          <div className="overflow-x-auto">
            <table className="data-table">
              <thead>
                <tr>
                  <th>No.</th>
                  <th>Account</th>
                  <th>Type</th>
                  <th className="num">Debit</th>
                  <th className="num">Credit</th>
                </tr>
              </thead>
              <tbody>
                {statements.balances.map((row) => (
                  <tr key={row.accountNo}>
                    <td className="font-mono text-[0.7rem] font-bold text-muted">{row.accountNo}</td>
                    <td className="text-[0.78rem] font-semibold text-ink">{row.name}</td>
                    <td className="text-[0.68rem] uppercase tracking-wide text-muted">{row.type}</td>
                    <td className="num">{row.debit > 0 ? money(row.debit) : "—"}</td>
                    <td className="num">{row.credit > 0 ? money(row.credit) : "—"}</td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="bg-[#f7fafd]">
                  <td colSpan={3} className="px-4 py-2.5 text-[0.78rem] font-extrabold text-navy">Totals</td>
                  <td className="num px-4 py-2.5 font-extrabold text-navy">{money(statements.trialDebit)}</td>
                  <td className="num px-4 py-2.5 font-extrabold text-navy">{money(statements.trialCredit)}</td>
                </tr>
              </tfoot>
            </table>
          </div>
        </Card>
      ) : null}
    </div>
  );
}
