import { requireUser } from "@/lib/auth";
import { accountBalances, financialStatements } from "@/lib/accounting";
import { money } from "@/lib/format";
import { Badge, Card, EmptyState, Field, Flash, PageHeader, Panel, StatCard } from "@/components/ui";
import { SubmitButton } from "@/components/submit-button";
import { createAccountAction } from "@/app/actions/practice";

export const dynamic = "force-dynamic";
export const metadata = { title: "Chart of accounts — BPZ Consult" };

const TYPE_ORDER = ["asset", "liability", "equity", "income", "expense"] as const;
const TYPE_LABEL: Record<string, string> = {
  asset: "Assets",
  liability: "Liabilities",
  equity: "Equity",
  income: "Income",
  expense: "Expenses",
};

export default async function AccountsPage({
  searchParams,
}: {
  searchParams: Promise<{ ok?: string; error?: string; panel?: string }>;
}) {
  const user = await requireUser();
  const params = await searchParams;
  const [balances, statements] = await Promise.all([accountBalances(), financialStatements()]);
  const grouped = TYPE_ORDER.map((type) => ({ type, rows: balances.filter((row) => row.type === type) }));
  const readOnly = user.role === "auditor";

  return (
    <div className="space-y-4">
      <PageHeader
        eyebrow="Accounting"
        title="Chart of accounts"
        description="IFRS-aligned master chart with live balances from posted journals."
        actions={<Badge tone={statements.balanced ? "green" : "red"}>{statements.balanced ? "Trial balance balanced" : "Investigate difference"}</Badge>}
      />

      <Flash ok={params.ok} error={params.error} />

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Total assets" value={money(statements.totalAssets, { compact: true })} sub={`${statements.assets.length} active accounts`} />
        <StatCard label="Total liabilities" value={money(statements.totalLiabilities, { compact: true })} sub={`${statements.liabilities.length} active accounts`} tone="gold" />
        <StatCard label="Equity incl. profit" value={money(statements.totalEquity, { compact: true })} sub={`Profit ${money(statements.netProfit, { compact: true })}`} tone="green" />
        <StatCard label="Chart size" value={String(balances.length)} sub="accounts available firm-wide" tone="blue" />
      </div>

      {!readOnly ? (
        <Panel title="Add a ledger account" description="Extend the master chart — new accounts are immediately available for journals." cta="New account" defaultOpen={params.panel === "account"}>
          <form action={createAccountAction} className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
            <Field label="Account number" htmlFor="accountNo">
              <input id="accountNo" name="accountNo" className="input" required pattern="\d{4}" placeholder="5170" inputMode="numeric" />
            </Field>
            <Field label="Account name" htmlFor="name" className="lg:col-span-2">
              <input id="name" name="name" className="input" required placeholder="e.g. Depreciation — office equipment" />
            </Field>
            <Field label="Type" htmlFor="type">
              <select id="type" name="type" className="select" defaultValue="expense">
                {TYPE_ORDER.map((type) => (
                  <option key={type} value={type}>{TYPE_LABEL[type]}</option>
                ))}
              </select>
            </Field>
            <Field label="Category" htmlFor="category">
              <div className="flex items-end gap-2">
                <input id="category" name="category" className="input" placeholder="Operations" />
                <SubmitButton className="shrink-0">Add</SubmitButton>
              </div>
            </Field>
          </form>
        </Panel>
      ) : null}

      <div className="grid gap-4 xl:grid-cols-2">
        {grouped.map((group) => {
          const total = group.rows.reduce((sum, row) => sum + row.balance, 0);
          return (
            <Card key={group.type} padded={false}>
              <div className="flex items-center justify-between border-b border-line px-4 py-3">
                <div>
                  <h2 className="text-[0.9rem] font-extrabold text-navy">{TYPE_LABEL[group.type]}</h2>
                  <p className="text-[0.68rem] font-medium text-muted">{group.rows.length} accounts</p>
                </div>
                <p className="text-[0.82rem] font-extrabold tabular-nums text-navy">{money(total, { compact: true })}</p>
              </div>
              {group.rows.length === 0 ? (
                <div className="p-4"><EmptyState title="No accounts" message="Add an account to this category." /></div>
              ) : (
                <div className="max-h-[360px] overflow-auto">
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th>No.</th>
                        <th>Account</th>
                        <th className="num">Debits</th>
                        <th className="num">Credits</th>
                        <th className="num">Balance</th>
                      </tr>
                    </thead>
                    <tbody>
                      {group.rows.map((row) => (
                        <tr key={row.accountNo}>
                          <td className="font-mono text-[0.7rem] font-bold text-muted">{row.accountNo}</td>
                          <td>
                            <p className="text-[0.78rem] font-bold text-navy">{row.name}</p>
                            <p className="text-[0.64rem] font-medium text-muted">{row.category}</p>
                          </td>
                          <td className="num text-[0.72rem] text-muted">{money(row.debit, { compact: true })}</td>
                          <td className="num text-[0.72rem] text-muted">{money(row.credit, { compact: true })}</td>
                          <td className="num font-bold text-navy">{money(row.balance, { compact: true })}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </Card>
          );
        })}
      </div>
    </div>
  );
}
