export default function WorkspaceLoading() {
  return (
    <div className="space-y-4">
      <div className="h-16 animate-pulse rounded-xl bg-white/70" />
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {[0, 1, 2, 3].map((item) => (
          <div key={item} className="h-24 animate-pulse rounded-xl bg-white/70" />
        ))}
      </div>
      <div className="h-72 animate-pulse rounded-xl bg-white/70" />
    </div>
  );
}
