"use client";

import Link from "next/link";
import { useEffect } from "react";
import { AlertTriangle } from "lucide-react";

export default function WorkspaceError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    console.error("Workspace screen error", error);
  }, [error]);

  return (
    <div className="card p-6 text-center">
      <span className="mx-auto grid h-12 w-12 place-items-center rounded-full bg-amber-50 text-amber-600">
        <AlertTriangle className="h-6 w-6" />
      </span>
      <h1 className="mt-4 text-lg font-black tracking-tight text-navy">This screen failed to render</h1>
      <p className="mx-auto mt-1.5 max-w-md text-[0.83rem] font-medium text-muted">
        Nothing was posted twice or lost — the ledger writes are transactional. Retry the screen, or move on to another
        module while the page recovers.
      </p>
      {error.digest ? <p className="mt-2 font-mono text-[0.66rem] text-muted">Reference {error.digest}</p> : null}
      <div className="mt-5 flex flex-wrap justify-center gap-2">
        <button type="button" onClick={reset} className="btn btn-primary">Retry screen</button>
        <Link href="/dashboard" className="btn btn-ghost">Dashboard</Link>
        <Link href="/reports" className="btn btn-quiet">Reports</Link>
      </div>
    </div>
  );
}
