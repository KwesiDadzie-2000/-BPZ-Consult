"use client";

import { useActionState, useState } from "react";
import { Eye, EyeOff } from "lucide-react";
import { changePasswordAction, updateProfileAction, type SettingsState } from "@/app/actions/auth";
import { SubmitButton } from "@/components/submit-button";
import { Alert, Field } from "@/components/ui";

export function ProfileForm({ name, email, jobTitle }: { name: string; email: string; jobTitle: string }) {
  const [state, formAction] = useActionState<SettingsState, FormData>(updateProfileAction, {});
  return (
    <form action={formAction} className="space-y-3">
      {state.ok ? <Alert tone="success">{state.ok}</Alert> : null}
      {state.error ? <Alert tone="error">{state.error}</Alert> : null}
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Full name" htmlFor="name">
          <input id="name" name="name" defaultValue={name} className="input" required />
        </Field>
        <Field label="Email address" htmlFor="email">
          <input id="email" name="email" type="email" defaultValue={email} className="input" required />
        </Field>
        <Field label="Job title" htmlFor="jobTitle">
          <input id="jobTitle" name="jobTitle" defaultValue={jobTitle} className="input" />
        </Field>
      </div>
      <SubmitButton variant="ghost">Save profile</SubmitButton>
    </form>
  );
}

function policyChecks(password: string) {
  return [
    { label: "At least 10 characters", ok: password.length >= 10 },
    { label: "Uppercase letter", ok: /[A-Z]/.test(password) },
    { label: "Lowercase letter", ok: /[a-z]/.test(password) },
    { label: "A number", ok: /[0-9]/.test(password) },
    { label: "A symbol", ok: /[^A-Za-z0-9]/.test(password) },
  ];
}

export function PasswordForm() {
  const [state, formAction] = useActionState<SettingsState, FormData>(changePasswordAction, {});
  const [password, setPassword] = useState("");
  const [show, setShow] = useState(false);
  const checks = policyChecks(password);

  return (
    <form action={formAction} className="space-y-3">
      {state.ok ? <Alert tone="success">{state.ok}</Alert> : null}
      {state.error ? <Alert tone="error">{state.error}</Alert> : null}
      <Field label="Current password" htmlFor="currentPassword">
        <input id="currentPassword" name="currentPassword" type="password" autoComplete="current-password" className="input" required />
      </Field>
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="New password" htmlFor="newPassword">
          <div className="relative">
            <input
              id="newPassword"
              name="newPassword"
              type={show ? "text" : "password"}
              autoComplete="new-password"
              className="input pr-9"
              required
              value={password}
              onChange={(event) => setPassword(event.target.value)}
            />
            <button
              type="button"
              onClick={() => setShow((value) => !value)}
              className="absolute right-2 top-1.5 rounded p-1.5 text-slate-400 hover:bg-slate-100 hover:text-navy"
              aria-label={show ? "Hide password" : "Show password"}
            >
              {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
        </Field>
        <Field label="Confirm new password" htmlFor="confirmPassword">
          <input id="confirmPassword" name="confirmPassword" type={show ? "text" : "password"} autoComplete="new-password" className="input" required />
        </Field>
      </div>
      <div className="flex flex-wrap gap-1.5">
        {checks.map((check) => (
          <span key={check.label} className={`pill ${check.ok ? "pill-green" : "pill-slate"}`}>
            {check.label}
          </span>
        ))}
      </div>
      <SubmitButton>Update password</SubmitButton>
    </form>
  );
}
