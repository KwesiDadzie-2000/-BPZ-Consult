import Link from "next/link";
import { desc, eq } from "drizzle-orm";
import { Laptop, KeyRound, LogOut, ShieldCheck, UserCog } from "lucide-react";
import { db } from "@/db";
import { auditLog } from "@/db/schema";
import { activeSessionsFor, requireUser } from "@/lib/auth";
import { revokeSessionAction, signOutEverywhereAction } from "@/app/actions/auth";
import { prettyDateTime } from "@/lib/format";
import { Alert, Avatar, Badge, Card, CardHeader, EmptyState, PageHeader, StatCard } from "@/components/ui";
import { SignOutButton } from "@/components/sign-out-button";
import { SubmitButton } from "@/components/submit-button";
import { PasswordForm, ProfileForm } from "./settings-forms";

export const dynamic = "force-dynamic";
export const metadata = { title: "Settings — BPZ Consult" };

export default async function SettingsPage({ searchParams }: { searchParams: Promise<{ ok?: string; error?: string }> }) {
  const user = await requireUser();
  const params = await searchParams;
  const [sessionRows, logRows] = await Promise.all([
    activeSessionsFor(user.id),
    (user.role === "owner"
      ? db.select().from(auditLog).orderBy(desc(auditLog.createdAt)).limit(12)
      : db.select().from(auditLog).where(eq(auditLog.userId, user.id)).orderBy(desc(auditLog.createdAt)).limit(12)),
  ]);

  return (
    <div className="space-y-4">
      <PageHeader
        eyebrow="Your account"
        title="Settings & security"
        description="Manage your profile, rotate your password and review session activity."
      />

      {params.ok ? <Alert tone="success">{params.ok}</Alert> : null}
      {params.error ? <Alert tone="error">{params.error}</Alert> : null}

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Your role" value={user.role} sub={user.jobTitle} icon={<UserCog className="h-4 w-4" />} />
        <StatCard label="Session policy" value="8 hours" sub="Sliding renewal while active" icon={<ShieldCheck className="h-4 w-4" />} tone="green" />
        <StatCard label="Active sessions" value={String(sessionRows.length)} sub="Devices signed in as you" icon={<Laptop className="h-4 w-4" />} tone="blue" />
        <StatCard label="Password storage" value="scrypt" sub="64-byte key, unique salt" icon={<KeyRound className="h-4 w-4" />} tone="gold" />
      </div>

      <div className="grid gap-4 xl:grid-cols-2">
        <Card>
          <CardHeader title="Profile" subtitle="How your name appears on reports and audit trails" />
          <div className="mb-4 flex items-center gap-3 rounded-xl bg-mist px-3 py-2.5">
            <Avatar name={user.name} />
            <div>
              <p className="text-[0.82rem] font-extrabold text-navy">{user.name}</p>
              <p className="text-[0.68rem] font-semibold text-muted">@{user.username} · {user.role}</p>
            </div>
            <Badge tone="green">Active</Badge>
          </div>
          <ProfileForm name={user.name} email={user.email} jobTitle={user.jobTitle} />
        </Card>

        <Card>
          <CardHeader title="Change password" subtitle="Rotating your password keeps this workspace secure" />
          <PasswordForm />
        </Card>
      </div>

      <div className="grid gap-4 xl:grid-cols-[1.3fr_1fr]">
        <Card padded={false}>
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-line px-4 py-3.5">
            <div>
              <h2 className="text-[0.92rem] font-extrabold text-navy">Active sessions</h2>
              <p className="text-[0.72rem] font-medium text-muted">Database-backed; revoking a session ends it immediately</p>
            </div>
            <form action={signOutEverywhereAction}>
              <SubmitButton variant="danger" className="btn-sm" pendingLabel="Revoking…">
                <LogOut className="h-3.5 w-3.5" /> Sign out everywhere
              </SubmitButton>
            </form>
          </div>
          {sessionRows.length === 0 ? (
            <div className="p-4"><EmptyState title="No active sessions" message="Sign in again to create a fresh session." /></div>
          ) : (
            <ul className="divide-line px-4 py-2">
              {sessionRows.map((session, index) => (
                <li key={session.id} className="flex items-start justify-between gap-3 py-2.5">
                  <div className="flex items-start gap-2.5">
                    <span className="mt-0.5 grid h-7 w-7 place-items-center rounded-lg bg-mist text-navy">
                      <Laptop className="h-3.5 w-3.5" />
                    </span>
                    <div>
                      <p className="text-[0.76rem] font-bold text-navy">
                        {index === 0 ? "Current device" : `Session ${index + 1}`}{" "}
                        <span className="font-medium text-muted">· {session.ip ?? "local"}</span>
                      </p>
                      <p className="max-w-[320px] truncate text-[0.66rem] font-medium text-muted">{session.userAgent ?? "Unknown browser"}</p>
                      <p className="text-[0.64rem] font-medium text-muted">Last seen {prettyDateTime(session.lastSeenAt)} · expires {prettyDateTime(session.expiresAt)}</p>
                    </div>
                  </div>
                  <form action={revokeSessionAction}>
                    <input type="hidden" name="sessionId" value={session.id} />
                    <SubmitButton variant="ghost" className="btn-sm" pendingLabel="Revoking…">Revoke</SubmitButton>
                  </form>
                </li>
              ))}
            </ul>
          )}
          <div className="border-t border-line px-4 py-3">
            <SignOutButton className="btn btn-ghost btn-sm" label="Sign out of this device">
              Sign out of this device
            </SignOutButton>
          </div>
        </Card>

        <div className="space-y-4">
          <Card>
            <CardHeader title="Security posture" subtitle="Enabled in this build" />
            <ul className="space-y-2 text-[0.75rem] font-medium text-navy">
              {[
                "scrypt password hashing with per-user salt",
                "HttpOnly, SameSite=Lax session cookie (no tokens in localStorage)",
                "Opaque 256-bit tokens stored as SHA-256 hashes",
                "Persisted lockout after five failed attempts (5 minutes)",
                "Single-use password reset links, valid 30 minutes",
                "Auditor role is read-only at the server boundary",
              ].map((item) => (
                <li key={item} className="flex items-start gap-2">
                  <ShieldCheck className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-600" />
                  {item}
                </li>
              ))}
            </ul>
            <div className="mt-3 flex flex-wrap gap-2">
              <Link href="/team" className="btn btn-ghost btn-sm">Team &amp; access</Link>
              <Link href="/forgot-password" className="btn btn-quiet btn-sm">Recovery flow</Link>
            </div>
          </Card>

          <Card>
            <CardHeader title="Need your credentials reset?" subtitle="Support path" />
            <p className="text-[0.76rem] font-medium leading-relaxed text-muted">
              Use the <strong className="text-navy">Forgot password?</strong> link on the sign-in screen to generate a
              single-use reset link for your account. Firm owners can also reset any team member from{" "}
              <Link href="/team" className="font-bold text-sky-700 hover:underline">Team &amp; access</Link>. Every reset
              revokes open sessions.
            </p>
          </Card>
        </div>
      </div>

      <Card padded={false}>
        <div className="border-b border-line px-4 py-3.5">
          <h2 className="text-[0.92rem] font-extrabold text-navy">Audit trail</h2>
          <p className="text-[0.72rem] font-medium text-muted">{user.role === "owner" ? "Firm-wide activity" : "Your account activity"} · latest 12 events</p>
        </div>
        {logRows.length === 0 ? (
          <div className="p-4"><EmptyState title="No audit events yet" message="Actions you take will be recorded here." /></div>
        ) : (
          <ul className="divide-line px-4 py-1">
            {logRows.map((log) => (
              <li key={log.id} className="flex flex-wrap items-center justify-between gap-2 py-2.5">
                <div>
                  <p className="text-[0.78rem] font-bold text-navy">{log.action}</p>
                  <p className="text-[0.68rem] font-medium text-muted">{log.summary}</p>
                </div>
                <div className="text-right">
                  <p className="text-[0.68rem] font-semibold text-navy">{log.actorName}</p>
                  <p className="text-[0.62rem] font-medium text-muted">{prettyDateTime(log.createdAt)} · {log.ip ?? "local"}</p>
                </div>
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
}
