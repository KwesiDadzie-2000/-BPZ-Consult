import { desc } from "drizzle-orm";
import { Calculator, Users } from "lucide-react";
import { db } from "@/db";
import { employees, payrollRuns } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { money, prettyDate, today } from "@/lib/format";
import { PAYE_BANDS, SSNIT_EMPLOYEE_RATE, SSNIT_EMPLOYER_RATE, type PayrollLine } from "@/lib/payroll";
import { Alert, Badge, Card, CardHeader, EmptyState, Field, Flash, PageHeader, Panel, StatCard, TableWrap, statusTone } from "@/components/ui";
import { SubmitButton } from "@/components/submit-button";
import { addEmployeeAction, markPayrollPaidAction, runPayrollAction } from "@/app/actions/ledger";

export const dynamic = "force-dynamic";
export const metadata = { title: "Payroll — BPZ Consult" };

export default async function PayrollPage({
  searchParams,
}: {
  searchParams: Promise<{ ok?: string; error?: string; panel?: string }>;
}) {
  const user = await requireUser();
  const params = await searchParams;
  const [staff, runs] = await Promise.all([
    db.select().from(employees).orderBy(employees.staffNo),
    db.select().from(payrollRuns).orderBy(desc(payrollRuns.period), desc(payrollRuns.id)),
  ]);

  const activeStaff = staff.filter((person) => person.status === "active");
  const latest = runs[0];
  const latestLines = (latest?.lines as PayrollLine[] | undefined) ?? [];
  const currentPeriod = today().slice(0, 7);
  const annualGross = activeStaff.reduce((sum, person) => sum + person.basicSalary + person.allowances, 0);
  const readOnly = user.role === "auditor";

  return (
    <div className="space-y-4">
      <PageHeader
        eyebrow="People"
        title="Payroll & statutory"
        description="Ghana PAYE bands, SSNIT tier contributions and net pay — calculated once, posted to the ledger."
        actions={<Badge tone="green">GRA 2025/26 bands</Badge>}
      />

      <Flash ok={params.ok} error={params.error} />

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Active staff" value={String(activeStaff.length)} sub={`${staff.length - activeStaff.length} on leave / exited`} icon={<Users className="h-4 w-4" />} />
        <StatCard label="Monthly gross" value={money(annualGross, { compact: true })} sub="Basic + allowances" icon={<Calculator className="h-4 w-4" />} tone="gold" />
        <StatCard label="Last PAYE" value={latest ? money(latest.paye, { compact: true }) : "—"} sub={latest ? `Period ${latest.period}` : "No run yet"} tone="green" />
        <StatCard label="Last SSNIT" value={latest ? money(latest.ssnitEmployee + latest.ssnitEmployer, { compact: true }) : "—"} sub={latest ? "Employee + employer" : "No run yet"} tone="blue" />
      </div>

      {!readOnly ? (
        <>
          <Panel
            title="Run payroll for a period"
            description="One run per month. PAYE and SSNIT are withheld and posted automatically."
            cta="Run payroll"
            defaultOpen={params.panel === "run"}
          >
            <form action={runPayrollAction} className="grid gap-3 sm:grid-cols-3">
              <Field label="Payroll period" htmlFor="period" hint="Salaries are dated the 28th of the period.">
                <input id="period" name="period" type="month" defaultValue={currentPeriod} className="input" required />
              </Field>
              <div className="flex items-end">
                <SubmitButton pendingLabel="Calculating PAYE…">Approve &amp; post payroll</SubmitButton>
              </div>
              <p className="flex items-end text-[0.7rem] font-medium text-muted">
                Dr Salaries &amp; SSNIT expense · Cr PAYE payable · Cr SSNIT payable · Cr Net pay payable.
              </p>
            </form>
          </Panel>

          <Panel
            title="Add a team member to payroll"
            description="Staff numbers are generated automatically (BPZ-00x)."
            cta="Add staff"
            defaultOpen={params.panel === "staff"}
          >
            <form action={addEmployeeAction} className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
              <Field label="Full name" htmlFor="name">
                <input id="name" name="name" className="input" required placeholder="e.g. Akosua Frimpong" />
              </Field>
              <Field label="Role" htmlFor="role">
                <input id="role" name="role" className="input" required placeholder="Tax Consultant" />
              </Field>
              <Field label="Department" htmlFor="department">
                <select id="department" name="department" className="select" defaultValue="Advisory">
                  {["Leadership", "Assurance", "Accounting", "Tax", "Advisory", "Operations"].map((department) => (
                    <option key={department} value={department}>{department}</option>
                  ))}
                </select>
              </Field>
              <Field label="Basic salary (GHS)" htmlFor="basicSalary">
                <input id="basicSalary" name="basicSalary" type="number" min="1" step="0.01" className="input" required placeholder="0.00" />
              </Field>
              <Field label="Allowances (GHS)" htmlFor="allowances">
                <input id="allowances" name="allowances" type="number" min="0" step="0.01" defaultValue="0" className="input" />
              </Field>
              <Field label="SSNIT number" htmlFor="ssnitNo">
                <input id="ssnitNo" name="ssnitNo" className="input" placeholder="SSNIT-000000" />
              </Field>
              <Field label="TIN" htmlFor="tin">
                <input id="tin" name="tin" className="input" placeholder="C0000000000" />
              </Field>
              <Field label="Start date" htmlFor="startDate">
                <div className="flex items-end gap-2">
                  <input id="startDate" name="startDate" type="date" defaultValue={today()} className="input" />
                  <SubmitButton className="shrink-0">Add</SubmitButton>
                </div>
              </Field>
            </form>
          </Panel>
        </>
      ) : (
        <Alert tone="info">Your auditor seat can review payroll but cannot approve runs.</Alert>
      )}

      <Card padded={false}>
        <div className="border-b border-line px-4 py-3.5">
          <h2 className="text-[0.92rem] font-extrabold text-navy">Payroll register</h2>
          <p className="text-[0.72rem] font-medium text-muted">{runs.length} approved runs</p>
        </div>
        {runs.length === 0 ? (
          <div className="p-4"><EmptyState title="No payroll runs yet" message="Approve a payroll period to calculate PAYE and SSNIT for active staff." /></div>
        ) : (
          <TableWrap className="rounded-none border-0">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Period</th>
                  <th>Staff</th>
                  <th className="num">Gross</th>
                  <th className="num">PAYE</th>
                  <th className="num">SSNIT (EE+ER)</th>
                  <th className="num">Net pay</th>
                  <th>Status</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {runs.map((run) => (
                  <tr key={run.id}>
                    <td>
                      <p className="font-extrabold text-navy">{run.period}</p>
                      <p className="text-[0.64rem] text-muted">posted {prettyDate(run.createdAt.toISOString())}</p>
                    </td>
                    <td className="text-[0.76rem] font-semibold">{run.headcount}</td>
                    <td className="num">{money(run.gross)}</td>
                    <td className="num">{money(run.paye)}</td>
                    <td className="num">{money(run.ssnitEmployee + run.ssnitEmployer)}</td>
                    <td className="num font-bold text-navy">{money(run.netPay)}</td>
                    <td><Badge tone={statusTone(run.status)}>{run.status}</Badge></td>
                    <td>
                      {run.status === "approved" && !readOnly ? (
                        <form action={markPayrollPaidAction}>
                          <input type="hidden" name="runId" value={run.id} />
                          <SubmitButton variant="ghost" className="btn-sm" pendingLabel="Settling…">Mark paid</SubmitButton>
                        </form>
                      ) : null}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </TableWrap>
        )}
      </Card>

      <div className="grid gap-4 xl:grid-cols-[1.3fr_1fr]">
        <Card padded={false}>
          <div className="border-b border-line px-4 py-3.5">
            <h2 className="text-[0.92rem] font-extrabold text-navy">Employee master</h2>
            <p className="text-[0.72rem] font-medium text-muted">Active and on-leave staff included in the next run</p>
          </div>
          <TableWrap className="rounded-none border-0">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Staff</th>
                  <th>Department</th>
                  <th className="num">Basic</th>
                  <th className="num">Allowances</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {staff.map((person) => (
                  <tr key={person.id}>
                    <td>
                      <p className="text-[0.78rem] font-bold text-navy">{person.name}</p>
                      <p className="text-[0.64rem] text-muted">{person.staffNo} · {person.role}</p>
                    </td>
                    <td className="text-[0.72rem] font-semibold text-muted">{person.department}</td>
                    <td className="num">{money(person.basicSalary)}</td>
                    <td className="num">{money(person.allowances)}</td>
                    <td><Badge tone={statusTone(person.status)}>{person.status.replace("_", " ")}</Badge></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </TableWrap>
        </Card>

        <div className="space-y-4">
          {latest ? (
            <Card padded={false}>
              <div className="flex items-center justify-between border-b border-line px-4 py-3.5">
                <CardHeader title={`Payslips · ${latest.period}`} subtitle="Employee-level statutory breakdown" />
                <Badge tone={statusTone(latest.status)}>{latest.status}</Badge>
              </div>
              <div className="max-h-[340px] space-y-2 overflow-auto px-4 py-3">
                {latestLines.map((line) => (
                  <details key={line.employeeId} className="rounded-lg border border-line bg-white px-3 py-2">
                    <summary className="cursor-pointer list-none">
                      <span className="flex items-center justify-between gap-2">
                        <span>
                          <span className="block text-[0.78rem] font-bold text-navy">{line.name}</span>
                          <span className="block text-[0.64rem] text-muted">{line.staffNo} · gross {money(line.gross)}</span>
                        </span>
                        <span className="text-[0.8rem] font-extrabold text-navy">{money(line.netPay)}</span>
                      </span>
                    </summary>
                    <dl className="mt-2 space-y-1 border-t border-line pt-2 text-[0.7rem]">
                      {[
                        ["Basic", line.basicSalary],
                        ["Allowances", line.allowances],
                        ["SSNIT (5.5%)", -line.ssnitEmployee],
                        ["PAYE", -line.paye],
                        ["Net pay", line.netPay],
                      ].map(([label, value]) => (
                        <div key={String(label)} className="flex justify-between">
                          <dt className="font-semibold text-muted">{label}</dt>
                          <dd className="font-bold tabular-nums text-navy">{money(Number(value))}</dd>
                        </div>
                      ))}
                      <div className="flex justify-between border-t border-line pt-1">
                        <dt className="font-semibold text-muted">Employer SSNIT (13%)</dt>
                        <dd className="font-bold tabular-nums text-muted">{money(line.ssnitEmployer)}</dd>
                      </div>
                    </dl>
                  </details>
                ))}
              </div>
            </Card>
          ) : null}

          <Card>
            <CardHeader title="PAYE band reference" subtitle="Monthly chargeable income (GRA)" />
            <table className="data-table">
              <thead>
                <tr>
                  <th>Band</th>
                  <th className="num">Rate</th>
                </tr>
              </thead>
              <tbody>
                {PAYE_BANDS.map((band, index) => (
                  <tr key={index}>
                    <td className="text-[0.72rem] font-semibold text-muted">
                      {band.upTo === Infinity ? "Above GHS 50,416.67" : `Up to GHS ${band.upTo.toLocaleString("en-GH", { minimumFractionDigits: 2 })}`}
                    </td>
                    <td className="num font-bold text-navy">{(band.rate * 100).toFixed(1)}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <p className="mt-2 text-[0.68rem] font-medium text-muted">
              SSNIT: employee {(SSNIT_EMPLOYEE_RATE * 100).toFixed(1)}% of basic · employer {(SSNIT_EMPLOYER_RATE * 100).toFixed(0)}%.
            </p>
          </Card>
        </div>
      </div>
    </div>
  );
}
