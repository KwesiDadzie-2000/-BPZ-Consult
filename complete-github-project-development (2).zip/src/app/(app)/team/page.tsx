import { redirect } from "next/navigation";
import { desc, gt, sql } from "drizzle-orm";
import { KeyRound, ShieldCheck, UserPlus } from "lucide-react";
import { db } from "@/db";
import { sessions, users } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { prettyDateTime } from "@/lib/format";
import { Avatar, Badge, Card, EmptyState, Field, Flash, PageHeader, Panel, StatCard, TableWrap, statusTone } from "@/components/ui";
import { SubmitButton } from "@/components/submit-button";
import { createTeamMemberAction, resetMemberPasswordAction, setUserStatusAction } from "@/app/actions/practice";

export const dynamic = "force-dynamic";
export const metadata = { title: "Team & access — BPZ Consult" };

export default async function TeamPage({ searchParams }: { searchParams: Promise<{ ok?: string; error?: string; panel?: string }> }) {
  const user = await requireUser();
  if (user.role !== "owner" && user.role !== "manager") {
    redirect("/dashboard?error=Team+management+is+restricted+to+owners+and+managers.");
  }
  const params = await searchParams;
  const isOwner = user.role === "owner";
  const [teamRows, sessionCounts] = await Promise.all([
    db.select().from(users).orderBy(users.id),
    db
      .select({ userId: sessions.userId, active: sql<number>`count(*)::int` })
      .from(sessions)
      .where(gt(sessions.expiresAt, new Date()))
      .groupBy(sessions.userId),
  ]);
  const activeByUser = new Map(sessionCounts.map((row) => [row.userId, row.active]));
  const activeSessions = sessionCounts.reduce((sum, row) => sum + row.active, 0);

  return (
    <div className="space-y-4">
      <PageHeader
        eyebrow="Administration"
        title="Team & access"
        description="Issue workspace credentials, rotate passwords and suspend access without touching the database."
        actions={<Badge tone="green"><ShieldCheck className="h-3 w-3" /> scrypt + server sessions</Badge>}
      />

      <Flash ok={params.ok} error={params.error} />

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Team accounts" value={String(teamRows.length)} sub={`${teamRows.filter((row) => row.role === "owner").length} owner seat`} />
        <StatCard label="Active sessions" value={String(activeSessions)} sub="Live across all devices" tone="green" />
        <StatCard label="Suspended" value={String(teamRows.filter((row) => row.status !== "active").length)} sub="Access revoked immediately" tone="gold" />
        <StatCard label="Password policy" value="10+ chars" sub="Upper, lower, digit, symbol" tone="blue" />
      </div>

      {isOwner ? (
        <>
          <Panel
            title="Provision a new team member"
            description="Passwords are hashed with a per-user salt before storage and can never be read back."
            cta="Invite member"
            defaultOpen={params.panel === "invite"}
          >
            <form action={createTeamMemberAction} className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              <Field label="Full name" htmlFor="name">
                <input id="name" name="name" required className="input" placeholder="e.g. Akosua Frimpong" />
              </Field>
              <Field label="Username" htmlFor="username" hint="Lowercase letters, numbers, dots or dashes.">
                <input id="username" name="username" required className="input" placeholder="akosua" />
              </Field>
              <Field label="Email" htmlFor="email">
                <input id="email" name="email" type="email" required className="input" placeholder="akosua@bpzconsult.com" />
              </Field>
              <Field label="Role" htmlFor="role">
                <select id="role" name="role" className="select" defaultValue="accountant">
                  <option value="manager">Manager — review &amp; write</option>
                  <option value="accountant">Accountant — day-to-day write</option>
                  <option value="auditor">Auditor — read only</option>
                </select>
              </Field>
              <Field label="Job title" htmlFor="jobTitle">
                <input id="jobTitle" name="jobTitle" className="input" placeholder="Tax Consultant" />
              </Field>
              <Field label="Temporary password" htmlFor="password" hint="Share it securely; the member should rotate it in Settings.">
                <div className="flex items-end gap-2">
                  <input id="password" name="password" type="text" required className="input font-mono" placeholder="e.g. BpzAkosua2026!" />
                  <SubmitButton className="shrink-0"><UserPlus className="h-3.5 w-3.5" /> Create</SubmitButton>
                </div>
              </Field>
            </form>
          </Panel>

          <Panel title="Reset a member password" description="Revokes that member's sessions immediately. Use this when someone is locked out." cta="Reset password">
            <form action={resetMemberPasswordAction} className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              <Field label="Team member" htmlFor="userId" className="lg:col-span-2">
                <select id="userId" name="userId" className="select" required defaultValue="">
                  <option value="" disabled>Choose account…</option>
                  {teamRows.map((member) => (
                    <option key={member.id} value={member.id}>{member.name} · {member.username} · {member.role}</option>
                  ))}
                </select>
              </Field>
              <Field label="New password" htmlFor="newPassword">
                <div className="flex items-end gap-2">
                  <input id="newPassword" name="password" type="text" required className="input font-mono" placeholder="e.g. BpzTemp2026!" />
                  <SubmitButton className="shrink-0" pendingLabel="Rotating…"><KeyRound className="h-3.5 w-3.5" /> Reset</SubmitButton>
                </div>
              </Field>
            </form>
          </Panel>
        </>
      ) : (
        <Card>
          <p className="text-[0.8rem] font-semibold text-navy">
            Managers can review team access. Only the firm owner can provision accounts or reset passwords.
          </p>
        </Card>
      )}

      <Card padded={false}>
        <div className="flex items-center justify-between border-b border-line px-4 py-3.5">
          <div>
            <h2 className="text-[0.92rem] font-extrabold text-navy">Workspace accounts</h2>
            <p className="text-[0.72rem] font-medium text-muted">Credentials are stored as salted scrypt hashes</p>
          </div>
          <Badge tone="slate">{teamRows.length} seats</Badge>
        </div>
        {teamRows.length === 0 ? (
          <div className="p-4"><EmptyState title="No accounts" message="Provision the first team member." /></div>
        ) : (
          <TableWrap className="rounded-none border-0">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Member</th>
                  <th>Username</th>
                  <th>Role</th>
                  <th>Sessions</th>
                  <th>Last sign-in</th>
                  <th>Status</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {teamRows.map((member) => (
                  <tr key={member.id}>
                    <td>
                      <div className="flex items-center gap-2">
                        <Avatar name={member.name} size="sm" />
                        <div>
                          <p className="text-[0.78rem] font-bold text-navy">{member.name}</p>
                          <p className="text-[0.64rem] text-muted">{member.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="font-mono text-[0.72rem] font-semibold text-muted">{member.username}</td>
                    <td><Badge tone={member.role === "owner" ? "gold" : member.role === "auditor" ? "slate" : "blue"}>{member.role}</Badge></td>
                    <td className="text-[0.76rem] font-bold text-navy">{activeByUser.get(member.id) ?? 0}</td>
                    <td className="whitespace-nowrap text-[0.7rem] font-medium text-muted">{member.lastLoginAt ? prettyDateTime(member.lastLoginAt) : "Never"}</td>
                    <td><Badge tone={statusTone(member.status)}>{member.status}</Badge></td>
                    <td>
                      {isOwner && member.role !== "owner" ? (
                        <form action={setUserStatusAction}>
                          <input type="hidden" name="userId" value={member.id} />
                          <input type="hidden" name="status" value={member.status === "active" ? "suspended" : "active"} />
                          <SubmitButton variant={member.status === "active" ? "danger" : "ghost"} className="btn-sm" pendingLabel="Saving…">
                            {member.status === "active" ? "Suspend" : "Restore"}
                          </SubmitButton>
                        </form>
                      ) : (
                        <span className="text-[0.68rem] font-semibold text-muted">Protected</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </TableWrap>
        )}
      </Card>

      <Card>
        <div className="flex items-start gap-2.5 rounded-xl bg-mist px-3.5 py-3">
          <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" />
          <p className="text-[0.74rem] font-medium leading-relaxed text-navy">
            Locked out? Team members can rotate their own password from Settings, or use the public “Forgot password?”
            recovery link. Owners can force a reset above. Every reset revokes existing sessions.
          </p>
        </div>
      </Card>
    </div>
  );
}
