import Link from "next/link";
import { desc, eq } from "drizzle-orm";
import { Plus } from "lucide-react";
import { db } from "@/db";
import { bankAccounts, clients, invoices } from "@/db/schema";
import { REVENUE_ACCOUNTS } from "@/lib/accounting";
import { addDays, money, prettyDate, round2, today } from "@/lib/format";
import { requireUser } from "@/lib/auth";
import { Badge, Card, EmptyState, Field, FilterBar, Flash, PageHeader, Panel, StatCard, TableWrap, statusTone } from "@/components/ui";
import { SubmitButton } from "@/components/submit-button";
import { createInvoiceAction, recordInvoicePaymentAction } from "@/app/actions/ledger";

export const dynamic = "force-dynamic";
export const metadata = { title: "Sales invoices — BPZ Consult" };

export default async function InvoicesPage({
  searchParams,
}: {
  searchParams: Promise<{ ok?: string; error?: string; panel?: string; status?: string; q?: string }>;
}) {
  await requireUser();
  const params = await searchParams;
  const [invoiceRows, clientRows, bankRows] = await Promise.all([
    db.select().from(invoices).orderBy(desc(invoices.issueDate), desc(invoices.id)),
    db.select().from(clients).orderBy(clients.name),
    db.select().from(bankAccounts).orderBy(bankAccounts.id),
  ]);

  const q = (params.q ?? "").toLowerCase();
  const statusFilter = params.status ?? "all";
  const filtered = invoiceRows.filter((invoice) => {
    const matchesStatus =
      statusFilter === "all"
        ? true
        : statusFilter === "open"
          ? invoice.status !== "paid" && invoice.status !== "draft"
          : invoice.status === statusFilter;
    const matchesQuery = !q || invoice.customerName.toLowerCase().includes(q) || invoice.invoiceNo.toLowerCase().includes(q) || invoice.revenueStream.toLowerCase().includes(q);
    return matchesStatus && matchesQuery;
  });

  const issued = invoiceRows.filter((invoice) => invoice.status !== "draft");
  const billed = round2(issued.reduce((sum, invoice) => sum + invoice.totalAmount, 0));
  const collected = round2(issued.reduce((sum, invoice) => sum + invoice.paidAmount, 0));
  const outstanding = round2(billed - collected);
  const overdue = issued.filter((invoice) => invoice.status === "overdue");
  const openInvoices = invoiceRows.filter((invoice) => invoice.status !== "paid" && invoice.status !== "draft");

  return (
    <div className="space-y-4">
      <PageHeader
        eyebrow="Revenue"
        title="Sales invoices"
        description="Raise professional-fee invoices, track receipts and post VAT output automatically."
        actions={
          <>
            <Link href="/reports?tab=pl" className="btn btn-ghost">Revenue report</Link>
            <a href="#new-invoice" className="btn btn-primary"><Plus className="h-3.5 w-3.5" /> New invoice</a>
          </>
        }
      />

      <Flash ok={params.ok} error={params.error} />

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Billed (all time)" value={money(billed, { compact: true })} sub={`${issued.length} issued invoices`} />
        <StatCard label="Collected" value={money(collected, { compact: true })} sub={`${money(billed - collected, { compact: true })} open`} tone="green" />
        <StatCard label="Outstanding" value={money(outstanding, { compact: true })} sub={`${openInvoices.length} awaiting settlement`} tone="gold" />
        <StatCard label="Overdue" value={money(overdue.reduce((sum, invoice) => sum + invoice.totalAmount - invoice.paidAmount, 0), { compact: true })} sub={`${overdue.length} past due date`} tone="blue" />
      </div>

      <Panel
        id="new-invoice"
        title="Raise a new invoice"
        description="VAT is calculated on the server and posted with the receivable in one journal."
        cta="New invoice"
        defaultOpen={params.panel === "new"}
      >
        <form action={createInvoiceAction} className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          <Field label="Client" htmlFor="clientId">
            <select id="clientId" name="clientId" className="select" required defaultValue="">
              <option value="" disabled>Choose client…</option>
              {clientRows.map((client) => (
                <option key={client.id} value={client.id}>{client.code} · {client.name}</option>
              ))}
            </select>
          </Field>
          <Field label="Revenue stream" htmlFor="revenueStream">
            <select id="revenueStream" name="revenueStream" className="select" required defaultValue="Advisory & consulting">
              {Object.keys(REVENUE_ACCOUNTS).map((stream) => (
                <option key={stream} value={stream}>{stream}</option>
              ))}
            </select>
          </Field>
          <Field label="Net revenue (GHS)" htmlFor="netRevenue">
            <input id="netRevenue" name="netRevenue" type="number" min="0.01" step="0.01" required placeholder="e.g. 45000" className="input" />
          </Field>
          <Field label="VAT rate" htmlFor="vatRate" hint="Standard rate is 15%. Choose 0% for exempt or out-of-scope services.">
            <select id="vatRate" name="vatRate" className="select" defaultValue="15">
              <option value="15">15% — standard rated</option>
              <option value="0">0% — exempt / out of scope</option>
            </select>
          </Field>
          <Field label="Issue date" htmlFor="issueDate">
            <input id="issueDate" name="issueDate" type="date" defaultValue={today()} className="input" required />
          </Field>
          <Field label="Due date" htmlFor="dueDate">
            <input id="dueDate" name="dueDate" type="date" defaultValue={addDays(today(), 21)} className="input" required />
          </Field>
          <Field label="Posting status" htmlFor="status" hint="Draft invoices stay out of the ledger and receivables.">
            <select id="status" name="status" className="select" defaultValue="sent">
              <option value="sent">Issue now (post to ledger)</option>
              <option value="draft">Save as draft</option>
            </select>
          </Field>
          <Field label="Notes" htmlFor="notes" className="sm:col-span-2">
            <input id="notes" name="notes" className="input" placeholder="Engagement reference or payment instructions" />
          </Field>
          <div className="flex items-end gap-2">
            <SubmitButton>Post invoice</SubmitButton>
          </div>
        </form>
      </Panel>

      <Panel
        title="Record a client receipt"
        description="Posts cash received and clears the receivable — no manual journal needed."
        cta="Record receipt"
        defaultOpen={params.panel === "payments"}
      >
        {openInvoices.length === 0 ? (
          <p className="text-[0.8rem] font-semibold text-muted">Every issued invoice is settled. 🎉</p>
        ) : (
          <form action={recordInvoicePaymentAction} className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
            <Field label="Open invoice" htmlFor="invoiceId" className="lg:col-span-2">
              <select id="invoiceId" name="invoiceId" className="select" required defaultValue="">
                <option value="" disabled>Choose invoice…</option>
                {openInvoices.map((invoice) => (
                  <option key={invoice.id} value={invoice.id}>
                    {invoice.invoiceNo} · {invoice.customerName} · {money(invoice.totalAmount - invoice.paidAmount)}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Amount (GHS)" htmlFor="amount">
              <input id="amount" name="amount" type="number" min="0.01" step="0.01" required className="input" placeholder="0.00" />
            </Field>
            <Field label="Received into" htmlFor="bankAccountId">
              <select id="bankAccountId" name="bankAccountId" className="select" defaultValue={String(bankRows[0]?.id ?? "")}>
                {bankRows.filter((bank) => bank.kind !== "cash").map((bank) => (
                  <option key={bank.id} value={bank.id}>{bank.name}</option>
                ))}
              </select>
            </Field>
            <Field label="Receipt date" htmlFor="paidOn">
              <div className="flex items-end gap-2">
                <input id="paidOn" name="paidOn" type="date" defaultValue={today()} className="input" />
                <SubmitButton className="shrink-0">Record</SubmitButton>
              </div>
            </Field>
          </form>
        )}
      </Panel>

      <Card padded={false}>
        <div className="flex flex-col gap-3 border-b border-line px-4 py-3.5 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="text-[0.92rem] font-extrabold text-navy">Invoice register</h2>
            <p className="text-[0.72rem] font-medium text-muted">{filtered.length} of {invoiceRows.length} invoices</p>
          </div>
          <form method="get" className="w-full sm:w-auto">
            <FilterBar>
              <input name="q" defaultValue={params.q ?? ""} placeholder="Search invoice or client" className="input w-full sm:w-52" />
              <select name="status" defaultValue={statusFilter} className="select w-full sm:w-36">
                <option value="all">All statuses</option>
                <option value="open">Open items</option>
                <option value="sent">Sent</option>
                <option value="partial">Part paid</option>
                <option value="paid">Paid</option>
                <option value="overdue">Overdue</option>
                <option value="draft">Draft</option>
              </select>
              <button type="submit" className="btn btn-ghost">Filter</button>
              <Link href="/invoices" className="btn btn-quiet">Reset</Link>
            </FilterBar>
          </form>
        </div>

        {filtered.length === 0 ? (
          <div className="p-4">
            <EmptyState title="No invoices match" message="Adjust the filters or raise a new invoice to get started." />
          </div>
        ) : (
          <TableWrap className="rounded-none border-0">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Invoice</th>
                  <th>Client</th>
                  <th>Stream</th>
                  <th>Issued / due</th>
                  <th className="num">Net</th>
                  <th className="num">VAT</th>
                  <th className="num">Total</th>
                  <th className="num">Balance</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((invoice) => {
                  const balance = round2(invoice.totalAmount - invoice.paidAmount);
                  return (
                    <tr key={invoice.id}>
                      <td className="whitespace-nowrap font-extrabold text-navy">{invoice.invoiceNo}</td>
                      <td className="max-w-[200px] truncate text-[0.78rem] font-semibold">{invoice.customerName}</td>
                      <td className="whitespace-nowrap text-[0.72rem] text-muted">{invoice.revenueStream}</td>
                      <td className="whitespace-nowrap text-[0.72rem] text-muted">
                        {prettyDate(invoice.issueDate)}
                        <span className="block text-[0.66rem]">due {prettyDate(invoice.dueDate)}</span>
                      </td>
                      <td className="num">{money(invoice.netRevenue)}</td>
                      <td className="num text-muted">{money(invoice.vatAmount)}</td>
                      <td className="num font-bold text-navy">{money(invoice.totalAmount)}</td>
                      <td className="num font-bold">{balance > 0 ? money(balance) : <span className="text-emerald-600">Settled</span>}</td>
                      <td><Badge tone={statusTone(invoice.status)}>{invoice.status}</Badge></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </TableWrap>
        )}
      </Card>

      <p className="text-[0.7rem] font-medium text-muted">
        Issuing an invoice posts Dr Accounts receivable · Cr Revenue · Cr VAT output. Drafts can be issued later from the register.
      </p>
    </div>
  );
}
