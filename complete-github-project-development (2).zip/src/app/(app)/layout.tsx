import type { ReactNode } from "react";
import { redirect } from "next/navigation";
import { AppNav } from "@/components/app-nav";
import { getCurrentUser } from "@/lib/auth";
import { ensureSeed } from "@/lib/seed";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

/**
 * Workspace shell. Every failure path either redirects to sign-in or renders a
 * recoverable card — it must never throw out to the global error boundary.
 */
export default async function WorkspaceLayout({ children }: { children: ReactNode }) {
  try {
    await ensureSeed();
  } catch (error) {
    console.error("Workspace bootstrap failed", error);
    redirect("/login?error=The+workspace+database+is+temporarily+unavailable.+Please+try+again.");
  }

  let user: Awaited<ReturnType<typeof getCurrentUser>> = null;
  try {
    user = await getCurrentUser();
  } catch (error) {
    console.error("Session resolution failed", error);
    redirect("/login?error=Your+session+could+not+be+verified.+Please+sign+in+again.");
  }

  if (!user) {
    redirect("/login?error=Your+session+expired.+Please+sign+in+again.");
  }

  const today = new Intl.DateTimeFormat("en-GB", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(new Date());

  return (
    <div className="min-h-screen lg:flex">
      <AppNav user={user} />
      <div className="min-w-0 flex-1">
        <div className="mx-auto w-full max-w-[1320px] px-4 pb-12 pt-5 sm:px-6 lg:px-8 lg:pt-7">
          <div className="no-print mb-5 flex flex-wrap items-center justify-between gap-2 text-[0.7rem] font-semibold text-muted">
            <div className="flex items-center gap-2">
              <span className="inline-flex h-1.5 w-1.5 rounded-full bg-emerald-500" />
              Ledger live · {today}
            </div>
            <div className="flex items-center gap-3">
              <span className="hidden sm:inline">Signed in as {user.username}</span>
              <span className="pill pill-gold">{user.role}</span>
            </div>
          </div>
          {children}
          <footer className="no-print mt-10 flex flex-col gap-1 border-t border-line pt-4 text-[0.68rem] font-medium text-muted sm:flex-row sm:items-center sm:justify-between">
            <p>© {new Date().getFullYear()} BPZ Consult · Practice &amp; accounting workspace</p>
            <p>GHS · Ghana PAYE &amp; SSNIT ready · Double-entry enforced · Secured build v2.3</p>
          </footer>
        </div>
      </div>
    </div>
  );
}
