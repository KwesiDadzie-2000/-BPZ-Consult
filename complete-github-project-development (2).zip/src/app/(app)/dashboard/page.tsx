import Link from "next/link";
import {
  ArrowUpRight,
  Banknote,
  BookOpenCheck,
  CalendarClock,
  CircleDollarSign,
  Landmark,
  ReceiptText,
  ShieldCheck,
  TrendingUp,
  Wallet,
} from "lucide-react";
import { getCurrentUser } from "@/lib/auth";
import { dashboardData } from "@/lib/accounting";
import { monthLabel, money, prettyDate } from "@/lib/format";
import { redirect } from "next/navigation";
import { Alert, Amount, Badge, Bars, Card, CardHeader, EmptyState, PageHeader, Progress, StatCard, statusTone } from "@/components/ui";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";
export const metadata = { title: "Dashboard — BPZ Consult" };

export default async function DashboardPage({ searchParams }: { searchParams: Promise<{ ok?: string; error?: string }> }) {
  const user = await getCurrentUser();
  if (!user) redirect("/login?error=Your+session+expired.+Please+sign+in+again.");

  const params = await searchParams;

  let data: Awaited<ReturnType<typeof dashboardData>> | null = null;
  let loadError: string | null = null;
  try {
    data = await dashboardData();
  } catch (error) {
    console.error("Dashboard data failed", error);
    loadError = error instanceof Error ? error.message : "Could not load dashboard figures.";
  }

  const firstName = user.name.split(" ")[0];
  const hour = new Date().getHours();
  const greeting = hour < 12 ? "Good morning" : hour < 17 ? "Good afternoon" : "Good evening";

  if (!data) {
    return (
      <div className="space-y-4">
        <PageHeader eyebrow="Firm overview" title={`${greeting}, ${firstName}`} description="The ledger is online, but this screen could not load its figures." />
        <Alert tone="warning" title="Dashboard figures unavailable">
          {loadError || "Please retry. Your session is valid and no data was lost."}
        </Alert>
        <div className="flex flex-wrap gap-2">
          <Link href="/dashboard" className="btn btn-primary">Retry dashboard</Link>
          <Link href="/invoices" className="btn btn-ghost">Sales invoices</Link>
          <Link href="/reports" className="btn btn-quiet">Reports</Link>
        </div>
      </div>
    );
  }

  const monthSeries = data.series.map((point) => ({ ...point, label: monthLabel(point.key) }));
  const previous = data.series[data.series.length - 2];
  const current = data.series[data.series.length - 1] ?? { key: "0000-00", income: 0, expense: 0 };
  const revenueTrend = previous && previous.income > 0 ? Math.round(((current.income - previous.income) / previous.income) * 100) : 0;
  const margin = data.statements.totalIncome > 0 ? Math.round((data.statements.netProfit / data.statements.totalIncome) * 100) : 0;
  const attention = data.invoiceRows
    .filter((invoice) => invoice.status === "overdue" || invoice.status === "partial" || invoice.status === "sent")
    .sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime())
    .slice(0, 5);

  return (
    <div className="space-y-5">
      <PageHeader
        eyebrow="Firm overview"
        title={`${greeting}, ${firstName}`}
        description="Live position across client bookkeeping, statutory obligations and the ledger."
        actions={
          <>
            <Link href="/invoices" className="btn btn-ghost">
              <ReceiptText className="h-3.5 w-3.5" /> Raise invoice
            </Link>
            <Link href="/journals" className="btn btn-primary">
              <BookOpenCheck className="h-3.5 w-3.5" /> Post journal
            </Link>
          </>
        }
      />

      {params.ok ? <Alert tone="success">{params.ok}</Alert> : null}
      {params.error ? <Alert tone="error">{params.error}</Alert> : null}

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          label="Cash & bank"
          value={money(data.cash, { compact: true })}
          sub={`${data.bankAccounts.length} accounts reconciled`}
          icon={<Landmark className="h-4 w-4" />}
          tone="navy"
        />
        <StatCard
          label="Revenue (YTD)"
          value={money(data.statements.totalIncome, { compact: true })}
          sub={`${monthLabel(current.key)} · ${money(current.income, { compact: true })}`}
          icon={<CircleDollarSign className="h-4 w-4" />}
          tone="gold"
          trend={{ value: `${revenueTrend >= 0 ? "+" : ""}${revenueTrend}% MoM`, direction: revenueTrend >= 0 ? "up" : "down", good: revenueTrend >= 0 }}
        />
        <StatCard
          label="Net profit"
          value={money(data.statements.netProfit, { compact: true })}
          sub={`${margin}% margin`}
          icon={<TrendingUp className="h-4 w-4" />}
          tone="green"
          trend={{ value: `${money(data.statements.totalExpenses, { compact: true })} cost`, direction: "down", good: data.statements.netProfit >= 0 }}
        />
        <StatCard
          label="Receivables"
          value={money(data.receivable, { compact: true })}
          sub={<span className={data.overdueTotal > 0 ? "font-bold text-rose-600" : ""}>{money(data.overdueTotal, { compact: true })} overdue</span>}
          icon={<Wallet className="h-4 w-4" />}
          tone="blue"
        />
      </div>

      <div className="grid gap-4 xl:grid-cols-[1.65fr_1fr]">
        <Card>
          <CardHeader
            title="Revenue vs operating costs"
            subtitle="Posted journals, last six months"
            action={
              <div className="flex items-center gap-3 text-[0.66rem] font-bold uppercase tracking-wide text-muted">
                <span className="inline-flex items-center gap-1"><span className="h-2 w-2 rounded-sm bg-navy" /> Revenue</span>
                <span className="inline-flex items-center gap-1"><span className="h-2 w-2 rounded-sm bg-gold" /> Costs</span>
              </div>
            }
          />
          <Bars series={monthSeries} />
          <div className="mt-4 grid grid-cols-3 gap-3 border-t border-line pt-3.5">
            <div>
              <p className="text-[0.62rem] font-extrabold uppercase tracking-wide text-muted">Income</p>
              <p className="mt-0.5 text-sm font-extrabold text-navy">{money(data.statements.totalIncome, { compact: true })}</p>
            </div>
            <div>
              <p className="text-[0.62rem] font-extrabold uppercase tracking-wide text-muted">Operating costs</p>
              <p className="mt-0.5 text-sm font-extrabold text-navy">{money(data.statements.totalExpenses, { compact: true })}</p>
            </div>
            <div>
              <p className="text-[0.62rem] font-extrabold uppercase tracking-wide text-muted">Gross margin</p>
              <p className="mt-0.5 text-sm font-extrabold text-emerald-600">{margin}%</p>
            </div>
          </div>
        </Card>

        <div className="space-y-4">
          <Card>
            <CardHeader
              title="Ledger health"
              subtitle="Every document posts double-entry"
              action={<Badge tone={data.statements.balanced ? "green" : "red"}>{data.statements.balanced ? "Balanced" : "Review"}</Badge>}
            />
            <dl className="space-y-2">
              <div className="flex items-center justify-between text-[0.78rem]">
                <dt className="font-semibold text-muted">Total debits</dt>
                <dd className="font-extrabold text-navy">{money(data.statements.trialDebit)}</dd>
              </div>
              <div className="flex items-center justify-between text-[0.78rem]">
                <dt className="font-semibold text-muted">Total credits</dt>
                <dd className="font-extrabold text-navy">{money(data.statements.trialCredit)}</dd>
              </div>
              <div className="flex items-center justify-between border-t border-line pt-2 text-[0.78rem]">
                <dt className="font-semibold text-muted">VAT net position</dt>
                <dd className="font-extrabold text-navy">{money(data.vatNet)}</dd>
              </div>
              <div className="flex items-center justify-between text-[0.78rem]">
                <dt className="font-semibold text-muted">PAYE payable</dt>
                <dd className="font-extrabold text-navy">{money(data.paye)}</dd>
              </div>
              <div className="flex items-center justify-between text-[0.78rem]">
                <dt className="font-semibold text-muted">SSNIT payable</dt>
                <dd className="font-extrabold text-navy">{money(data.ssnit)}</dd>
              </div>
            </dl>
            <div className="mt-3 flex items-center gap-2 rounded-lg bg-emerald-50 px-2.5 py-2 text-[0.7rem] font-semibold text-emerald-800">
              <ShieldCheck className="h-3.5 w-3.5" />
              Trial balance agrees to {money(data.statements.trialDebit, { showCurrency: false })}.
            </div>
            <Link href="/reports" className="mt-3 inline-flex items-center gap-1 text-[0.74rem] font-bold text-sky-700 hover:underline">
              Open financial reports <ArrowUpRight className="h-3.5 w-3.5" />
            </Link>
          </Card>

          <Card>
            <CardHeader title="Firm pulse" subtitle="Operational context" />
            <div className="space-y-3">
              <div>
                <div className="flex items-center justify-between text-[0.72rem] font-bold text-navy">
                  <span>Client portfolio</span>
                  <span>{data.clients.length}</span>
                </div>
                <div className="mt-1.5"><Progress value={Math.min(100, data.clients.length * 12)} tone="gold" /></div>
                <p className="mt-1 text-[0.66rem] font-medium text-muted">{data.clients.filter((client) => client.status === "active").length} active · {data.clients.filter((client) => client.status === "onboarding").length} onboarding</p>
              </div>
              <div>
                <div className="flex items-center justify-between text-[0.72rem] font-bold text-navy">
                  <span>Payroll headcount</span>
                  <span>{data.headcount}</span>
                </div>
                <div className="mt-1.5"><Progress value={Math.min(100, data.headcount * 12)} tone="navy" /></div>
                <p className="mt-1 text-[0.66rem] font-medium text-muted">PAYE, SSNIT and tier-2 tracked in one run.</p>
              </div>
            </div>
          </Card>
        </div>
      </div>

      <div className="grid gap-4 xl:grid-cols-[1.3fr_1fr]">
        <Card padded={false}>
          <div className="flex items-center justify-between gap-3 px-5 pb-3 pt-4">
            <CardHeader title="Invoices needing attention" subtitle="Chase before month end" />
            <Link href="/invoices" className="btn btn-ghost btn-sm">All invoices</Link>
          </div>
          {attention.length === 0 ? (
            <div className="px-4 pb-4">
              <EmptyState title="Nothing overdue" message="Every issued invoice is settled. Keep the momentum going." />
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Invoice</th>
                    <th>Client</th>
                    <th>Due</th>
                    <th className="num">Balance</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {attention.map((invoice) => (
                    <tr key={invoice.id}>
                      <td className="font-bold text-navy">{invoice.invoiceNo}</td>
                      <td className="max-w-[170px] truncate text-[0.78rem] font-semibold text-ink">{invoice.customerName}</td>
                      <td className="whitespace-nowrap text-[0.74rem] text-muted">{prettyDate(invoice.dueDate)}</td>
                      <td className="num font-bold text-navy">{money(invoice.totalAmount - invoice.paidAmount, { compact: true })}</td>
                      <td><Badge tone={statusTone(invoice.status)}>{invoice.status}</Badge></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>

        <Card padded={false}>
          <div className="flex items-center justify-between px-5 pb-2 pt-4">
            <CardHeader title="Latest ledger activity" subtitle="Most recent postings" />
            <Link href="/journals" className="btn btn-ghost btn-sm">Ledger</Link>
          </div>
          <ul className="divide-line px-5 pb-4">
            {data.recentJournals.map((journal) => (
              <li key={journal.id} className="flex items-start gap-3 py-2.5">
                <span className="mt-0.5 grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-mist text-navy">
                  {journal.module === "Sales" ? <ReceiptText className="h-3.5 w-3.5" /> : journal.module === "Expenses" ? <Banknote className="h-3.5 w-3.5" /> : journal.module === "Payroll" ? <CalendarClock className="h-3.5 w-3.5" /> : <BookOpenCheck className="h-3.5 w-3.5" />}
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[0.78rem] font-bold text-navy">{journal.description}</p>
                  <p className="text-[0.66rem] font-semibold text-muted">{journal.docNo} · {prettyDate(journal.date)}</p>
                </div>
                <Badge tone="slate">{journal.module}</Badge>
              </li>
            ))}
          </ul>
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader title="Cash & bank accounts" subtitle="Balances derived from posted journals" action={<Link href="/banking" className="btn btn-ghost btn-sm">Manage</Link>} />
          <ul className="divide-line">
            {data.bankAccounts.map((account) => (
              <li key={account.id} className="flex items-center justify-between gap-3 py-2.5">
                <div>
                  <p className="text-[0.8rem] font-bold text-navy">{account.name}</p>
                  <p className="text-[0.66rem] font-medium text-muted">{account.bankName} · {account.accountNo}</p>
                </div>
                <p className="text-[0.82rem] font-extrabold tabular-nums text-navy">{money(account.balance)}</p>
              </li>
            ))}
          </ul>
        </Card>

        <Card>
          <CardHeader title="Top clients by billed revenue" subtitle="Net of VAT" action={<Link href="/clients" className="btn btn-ghost btn-sm">Client book</Link>} />
          {data.topClients.length === 0 ? (
            <EmptyState title="No client revenue yet" message="Raise your first invoice to start tracking client performance." />
          ) : (
            <ul className="space-y-3">
              {data.topClients.map((row) => (
                <li key={row.client?.id}>
                  <div className="flex items-center justify-between text-[0.78rem] font-bold text-navy">
                    <span className="truncate">{row.client?.name}</span>
                    <Amount value={row.revenue} compact />
                  </div>
                  <div className="mt-1.5">
                    <Progress value={(row.revenue / Math.max(1, data.topClients[0].revenue)) * 100} tone="gold" />
                  </div>
                  <p className="mt-1 text-[0.64rem] font-medium text-muted">{row.client?.sector} · health {row.client?.healthScore}%</p>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {[
          { href: "/invoices", label: "Sales invoices", copy: "Raise, chase and settle", icon: ReceiptText },
          { href: "/expenses", label: "Expenses", copy: "Approve supplier bills", icon: Wallet },
          { href: "/payroll", label: "Payroll", copy: "PAYE + SSNIT in one run", icon: CalendarClock },
          { href: "/reports", label: "Reports", copy: "P&L, balance sheet, TB", icon: TrendingUp },
        ].map((action) => (
          <Link key={action.href} href={action.href} className="card group flex items-center gap-3 p-3.5 transition hover:border-navy/25">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-navy text-gold">
              <action.icon className="h-4 w-4" />
            </span>
            <span className="min-w-0">
              <span className="block text-[0.8rem] font-extrabold text-navy">{action.label}</span>
              <span className="block text-[0.68rem] font-medium text-muted">{action.copy}</span>
            </span>
            <ArrowUpRight className="ml-auto h-4 w-4 text-muted transition group-hover:text-navy" />
          </Link>
        ))}
      </div>
    </div>
  );
}
