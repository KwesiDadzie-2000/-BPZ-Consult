import Link from "next/link";
import { desc, eq, inArray } from "drizzle-orm";
import { Banknote, Landmark, Smartphone, Wallet } from "lucide-react";
import { db } from "@/db";
import { accounts, bankAccounts, journalLines, journals } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { financialStatements } from "@/lib/accounting";
import { money, prettyDate, round2, today } from "@/lib/format";
import { Badge, Card, CardHeader, EmptyState, Field, Flash, PageHeader, Panel, StatCard, TableWrap } from "@/components/ui";
import { SubmitButton } from "@/components/submit-button";
import { recordBankTransactionAction } from "@/app/actions/ledger";

export const dynamic = "force-dynamic";
export const metadata = { title: "Banking & cash — BPZ Consult" };

export default async function BankingPage({
  searchParams,
}: {
  searchParams: Promise<{ ok?: string; error?: string; panel?: string }>;
}) {
  const user = await requireUser();
  const params = await searchParams;
  const [bankRows, statements, accountRows] = await Promise.all([
    db.select().from(bankAccounts).orderBy(bankAccounts.id),
    financialStatements(),
    db.select().from(accounts).orderBy(accounts.accountNo),
  ]);

  const cashGl = new Set(bankRows.map((bank) => bank.glAccount));
  const balanceByGl = new Map(statements.balances.map((row) => [row.accountNo, row.balance]));
  const enriched = bankRows.map((bank) => ({ ...bank, balance: round2(balanceByGl.get(bank.glAccount) ?? bank.openedBalance) }));
  const cashTotal = round2(enriched.reduce((sum, bank) => sum + bank.balance, 0));

  const movementRows = cashGl.size === 0 ? [] : await db
    .select({
      id: journalLines.id,
      date: journals.journalDate,
      docNo: journals.docNo,
      module: journals.module,
      description: journalLines.description,
      accountNo: journalLines.accountNo,
      accountName: journalLines.accountName,
      debit: journalLines.debit,
      credit: journalLines.credit,
    })
    .from(journalLines)
    .innerJoin(journals, eq(journals.id, journalLines.journalId))
    .where(inArray(journalLines.accountNo, [...cashGl]))
    .orderBy(desc(journals.journalDate), desc(journalLines.id))
    .limit(14);

  const offsetAccounts = accountRows.filter((account) => !cashGl.has(account.accountNo));

  return (
    <div className="space-y-4">
      <PageHeader
        eyebrow="Treasury"
        title="Banking & cash"
        description="Monitor liquidity, post receipts and reconcile movements straight into the ledger."
        actions={<Link href="/reports?tab=bs" className="btn btn-ghost">Balance sheet</Link>}
      />

      <Flash ok={params.ok} error={params.error} />

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Total cash & bank" value={money(cashTotal, { compact: true })} sub={`${bankRows.length} accounts`} icon={<Landmark className="h-4 w-4" />} />
        {enriched.slice(0, 3).map((bank) => (
          <StatCard
            key={bank.id}
            label={bank.name}
            value={money(bank.balance, { compact: true })}
            sub={`${bank.bankName} · ${bank.accountNo}`}
            icon={bank.kind === "cash" ? <Wallet className="h-4 w-4" /> : bank.kind === "momo" ? <Smartphone className="h-4 w-4" /> : <Banknote className="h-4 w-4" />}
            tone={bank.kind === "cash" ? "gold" : "blue"}
          />
        ))}
      </div>

      {user.role !== "auditor" ? (
        <Panel
          title="Record a bank movement"
          description="Deposits and withdrawals post against the bank's GL account and your chosen counter account."
          cta="New movement"
          defaultOpen={params.panel === "new"}
        >
          <form action={recordBankTransactionAction} className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            <Field label="Bank / cash account" htmlFor="bankAccountId">
              <select id="bankAccountId" name="bankAccountId" className="select" required defaultValue="">
                <option value="" disabled>Choose account…</option>
                {enriched.map((bank) => (
                  <option key={bank.id} value={bank.id}>{bank.name} · {money(bank.balance)}</option>
                ))}
              </select>
            </Field>
            <Field label="Movement type" htmlFor="type">
              <select id="type" name="type" className="select" defaultValue="deposit">
                <option value="deposit">Deposit / receipt</option>
                <option value="withdrawal">Withdrawal / payment</option>
              </select>
            </Field>
            <Field label="Amount (GHS)" htmlFor="amount">
              <input id="amount" name="amount" type="number" min="0.01" step="0.01" required className="input" placeholder="0.00" />
            </Field>
            <Field label="Counter account" htmlFor="offsetAccount" hint="The other side of the entry, e.g. other income or rent expense.">
              <select id="offsetAccount" name="offsetAccount" className="select" required defaultValue="">
                <option value="" disabled>Choose account…</option>
                {offsetAccounts.map((account) => (
                  <option key={account.accountNo} value={account.accountNo}>{account.accountNo} · {account.name}</option>
                ))}
              </select>
            </Field>
            <Field label="Date" htmlFor="date">
              <input id="date" name="date" type="date" defaultValue={today()} className="input" required />
            </Field>
            <Field label="Description" htmlFor="description">
              <div className="flex items-end gap-2">
                <input id="description" name="description" className="input" required placeholder="e.g. Transfer to tax reserve" />
                <SubmitButton className="shrink-0">Post</SubmitButton>
              </div>
            </Field>
          </form>
        </Panel>
      ) : null}

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader title="Account positions" subtitle="Derived from the cash & bank GL accounts" />
          <ul className="divide-line">
            {enriched.map((bank) => (
              <li key={bank.id} className="flex items-center justify-between gap-3 py-2.5">
                <div className="flex items-center gap-2.5">
                  <span className="grid h-8 w-8 place-items-center rounded-lg bg-mist text-navy">
                    {bank.kind === "cash" ? <Wallet className="h-3.5 w-3.5" /> : <Landmark className="h-3.5 w-3.5" />}
                  </span>
                  <div>
                    <p className="text-[0.8rem] font-bold text-navy">{bank.name}</p>
                    <p className="text-[0.66rem] font-medium text-muted">GL {bank.glAccount} · {bank.accountNo}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-[0.82rem] font-extrabold tabular-nums text-navy">{money(bank.balance)}</p>
                  <Badge tone={bank.kind === "cash" ? "gold" : "blue"}>{bank.kind}</Badge>
                </div>
              </li>
            ))}
          </ul>
        </Card>

        <Card>
          <CardHeader title="Cash & bank control" subtitle="Reconciliation posture" />
          <dl className="space-y-2.5">
            <div className="flex items-center justify-between text-[0.8rem]">
              <dt className="font-semibold text-muted">Total liquid funds</dt>
              <dd className="font-extrabold text-navy">{money(cashTotal)}</dd>
            </div>
            <div className="flex items-center justify-between text-[0.8rem]">
              <dt className="font-semibold text-muted">Receivables outstanding</dt>
              <dd className="font-extrabold text-navy">{money(statements.balances.find((row) => row.accountNo === "1100")?.balance ?? 0)}</dd>
            </div>
            <div className="flex items-center justify-between text-[0.8rem]">
              <dt className="font-semibold text-muted">Payables outstanding</dt>
              <dd className="font-extrabold text-navy">{money(statements.balances.find((row) => row.accountNo === "2000")?.balance ?? 0)}</dd>
            </div>
            <div className="flex items-center justify-between border-t border-line pt-2.5 text-[0.8rem]">
              <dt className="font-semibold text-muted">VAT payable / (recoverable)</dt>
              <dd className="font-extrabold text-navy">{money((statements.balances.find((row) => row.accountNo === "2100")?.balance ?? 0) - (statements.balances.find((row) => row.accountNo === "1200")?.balance ?? 0))}</dd>
            </div>
          </dl>
          <div className="mt-3 rounded-lg bg-mist px-3 py-2 text-[0.7rem] font-semibold text-navy">
            Cash balances move only through posted journals — no browser-side edits are possible.
          </div>
        </Card>
      </div>

      <Card padded={false}>
        <div className="border-b border-line px-4 py-3.5">
          <h2 className="text-[0.92rem] font-extrabold text-navy">Recent cash movements</h2>
          <p className="text-[0.72rem] font-medium text-muted">Last 14 ledger lines hitting a bank or cash account</p>
        </div>
        {movementRows.length === 0 ? (
          <div className="p-4"><EmptyState title="No cash movement yet" message="Record a deposit or settle an invoice to see activity here." /></div>
        ) : (
          <TableWrap className="rounded-none border-0">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Document</th>
                  <th>Account</th>
                  <th>Description</th>
                  <th className="num">In</th>
                  <th className="num">Out</th>
                </tr>
              </thead>
              <tbody>
                {movementRows.map((row) => (
                  <tr key={row.id}>
                    <td className="whitespace-nowrap text-[0.72rem] text-muted">{prettyDate(row.date)}</td>
                    <td className="whitespace-nowrap font-mono text-[0.7rem] font-bold text-navy">{row.docNo}</td>
                    <td className="whitespace-nowrap text-[0.72rem] font-semibold">{row.accountName}</td>
                    <td className="max-w-[280px] truncate text-[0.74rem]">{row.description}</td>
                    <td className="num font-bold text-emerald-600">{row.debit > 0 ? money(row.debit) : "—"}</td>
                    <td className="num font-bold text-rose-600">{row.credit > 0 ? money(row.credit) : "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </TableWrap>
        )}
      </Card>
    </div>
  );
}
