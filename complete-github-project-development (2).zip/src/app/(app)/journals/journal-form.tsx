"use client";

import { useActionState, useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import { createJournalAction } from "@/app/actions/ledger";
import { SubmitButton } from "@/components/submit-button";
import { Badge, Field } from "@/components/ui";

type Account = { accountNo: string; name: string; type: string };
type Client = { id: number; name: string; code: string };
type Row = { key: number; accountNo: string; debit: string; credit: string; description: string };

function newRow(key: number): Row {
  return { key, accountNo: "", debit: "", credit: "", description: "" };
}

const number = (value: string) => (Number(value.replace(/,/g, "")) || 0);

export function JournalForm({ accounts, clients, today }: { accounts: Account[]; clients: Client[]; today: string }) {
  const [state, formAction] = useActionState<{ error?: string }, FormData>(createJournalAction, {});
  const [rows, setRows] = useState<Row[]>([newRow(1), newRow(2)]);
  const [nextKey, setNextKey] = useState(3);

  const totalDebit = rows.reduce((sum, row) => sum + number(row.debit), 0);
  const totalCredit = rows.reduce((sum, row) => sum + number(row.credit), 0);
  const difference = Math.round((totalDebit - totalCredit) * 100) / 100;
  const balanced = Math.abs(difference) < 0.005 && totalDebit > 0;

  const update = (key: number, patch: Partial<Row>) => setRows((current) => current.map((row) => (row.key === key ? { ...row, ...patch } : row)));

  return (
    <form action={formAction} className="space-y-4">
      {state.error ? (
        <div className="rounded-lg border border-rose-300 bg-rose-50 px-3 py-2 text-[0.78rem] font-bold text-rose-800">{state.error}</div>
      ) : null}

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Field label="Journal date" htmlFor="journalDate">
          <input id="journalDate" name="journalDate" type="date" defaultValue={today} className="input" required />
        </Field>
        <Field label="Description" htmlFor="description" className="lg:col-span-2">
          <input id="description" name="description" className="input" required placeholder="e.g. Depreciation for the period" />
        </Field>
        <Field label="Client (optional)" htmlFor="clientId">
          <select id="clientId" name="clientId" className="select" defaultValue="">
            <option value="">Firm books</option>
            {clients.map((client) => (
              <option key={client.id} value={client.id}>{client.code} · {client.name}</option>
            ))}
          </select>
        </Field>
      </div>

      <div className="overflow-x-auto rounded-xl border border-line bg-white">
        <table className="data-table">
          <thead>
            <tr>
              <th className="w-[36%]">Account</th>
              <th>Line description</th>
              <th className="w-[13%]">Debit</th>
              <th className="w-[13%]">Credit</th>
              <th className="w-10" />
            </tr>
          </thead>
          <tbody>
            {rows.map((row, index) => (
              <tr key={row.key}>
                <td>
                  <select
                    name={`account_${index}`}
                    className="select"
                    value={row.accountNo}
                    onChange={(event) => update(row.key, { accountNo: event.target.value })}
                  >
                    <option value="">Choose account…</option>
                    {accounts.map((account) => (
                      <option key={account.accountNo} value={account.accountNo}>
                        {account.accountNo} · {account.name}
                      </option>
                    ))}
                  </select>
                </td>
                <td>
                  <input
                    name={`lineDescription_${index}`}
                    className="input"
                    value={row.description}
                    onChange={(event) => update(row.key, { description: event.target.value })}
                    placeholder="Optional line note"
                  />
                </td>
                <td>
                  <input
                    name={`debit_${index}`}
                    type="number"
                    min="0"
                    step="0.01"
                    className="input text-right"
                    value={row.debit}
                    onChange={(event) => update(row.key, { debit: event.target.value, credit: event.target.value ? "" : row.credit })}
                    placeholder="0.00"
                  />
                </td>
                <td>
                  <input
                    name={`credit_${index}`}
                    type="number"
                    min="0"
                    step="0.01"
                    className="input text-right"
                    value={row.credit}
                    onChange={(event) => update(row.key, { credit: event.target.value, debit: event.target.value ? "" : row.debit })}
                    placeholder="0.00"
                  />
                </td>
                <td>
                  {rows.length > 2 ? (
                    <button
                      type="button"
                      onClick={() => setRows((current) => current.filter((item) => item.key !== row.key))}
                      className="rounded p-1.5 text-muted hover:bg-rose-50 hover:text-rose-600"
                      aria-label="Remove line"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  ) : null}
                </td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr className="bg-[#f7fafd]">
              <td className="font-extrabold text-navy" colSpan={2}>
                Totals
              </td>
              <td className="num font-extrabold text-navy">{totalDebit.toFixed(2)}</td>
              <td className="num font-extrabold text-navy">{totalCredit.toFixed(2)}</td>
              <td />
            </tr>
          </tfoot>
        </table>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-3">
        <button
          type="button"
          className="btn btn-ghost btn-sm"
          onClick={() => {
            setRows((current) => [...current, newRow(nextKey)]);
            setNextKey((key) => key + 1);
          }}
          disabled={rows.length >= 10}
        >
          <Plus className="h-3.5 w-3.5" /> Add line
        </button>
        <div className="flex items-center gap-3">
          <span className={`text-[0.74rem] font-bold ${balanced ? "text-emerald-600" : "text-rose-600"}`}>
            {balanced ? "Balanced — ready to post" : `Out of balance by GHS ${Math.abs(difference).toFixed(2)}`}
          </span>
          <Badge tone={balanced ? "green" : "amber"}>{balanced ? "Double-entry verified" : "Unbalanced"}</Badge>
          <SubmitButton pendingLabel="Posting…">Post journal</SubmitButton>
        </div>
      </div>
      <p className="text-[0.68rem] font-medium text-muted">
        The ledger rejects unbalanced entries server-side. Debits must equal credits before anything is written.
      </p>
    </form>
  );
}
