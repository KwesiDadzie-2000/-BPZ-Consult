import Link from "next/link";
import { desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { accounts, clients, journalLines, journals } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { money, prettyDate, today } from "@/lib/format";
import { Badge, Card, EmptyState, Flash, PageHeader, Panel, StatCard, TableWrap } from "@/components/ui";
import { JournalForm } from "./journal-form";

export const dynamic = "force-dynamic";
export const metadata = { title: "Journal entries — BPZ Consult" };

export default async function JournalsPage({
  searchParams,
}: {
  searchParams: Promise<{ ok?: string; error?: string; panel?: string }>;
}) {
  await requireUser();
  const params = await searchParams;

  const [journalRows, lineRows, accountRows, clientRows, totals] = await Promise.all([
    db
      .select({
        id: journals.id,
        docNo: journals.docNo,
        date: journals.journalDate,
        module: journals.module,
        description: journals.description,
        status: journals.status,
        clientId: journals.clientId,
        createdAt: journals.createdAt,
      })
      .from(journals)
      .orderBy(desc(journals.journalDate), desc(journals.id))
      .limit(60),
    db.select().from(journalLines).orderBy(journalLines.id),
    db.select().from(accounts).orderBy(accounts.accountNo),
    db.select({ id: clients.id, name: clients.name, code: clients.code }).from(clients).orderBy(clients.name),
    db
      .select({ debit: sql<number>`coalesce(sum(${journalLines.debit}),0)::float`, credit: sql<number>`coalesce(sum(${journalLines.credit}),0)::float`, count: sql<number>`count(*)::int` })
      .from(journalLines)
      .innerJoin(journals, eq(journals.id, journalLines.journalId))
      .where(eq(journals.status, "posted")),
  ]);

  const linesByJournal = new Map<number, typeof lineRows>();
  for (const line of lineRows) {
    const list = linesByJournal.get(line.journalId) ?? [];
    list.push(line);
    linesByJournal.set(line.journalId, list);
  }
  const clientById = new Map(clientRows.map((client) => [client.id, client]));
  const debitTotal = totals[0]?.debit ?? 0;
  const creditTotal = totals[0]?.credit ?? 0;
  const balanced = Math.abs(debitTotal - creditTotal) < 0.005;

  return (
    <div className="space-y-4">
      <PageHeader
        eyebrow="General ledger"
        title="Journal entries"
        description="Every module posts here. Manual entries are validated for double-entry before they touch the books."
        actions={<Link href="/reports?tab=tb" className="btn btn-ghost">View trial balance</Link>}
      />

      <Flash ok={params.ok} error={params.error} />

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Posted journals" value={String(journalRows.length)} sub="Most recent 60 shown" />
        <StatCard label="Ledger debits" value={money(debitTotal, { compact: true })} sub={`${totals[0]?.count ?? 0} lines`} />
        <StatCard label="Ledger credits" value={money(creditTotal, { compact: true })} sub="Must equal debits" tone="gold" />
        <StatCard label="Balance check" value={balanced ? "Balanced" : "Review"} sub={balanced ? "Trial balance agrees" : `Difference ${money(debitTotal - creditTotal)}`} tone={balanced ? "green" : "blue"} />
      </div>

      <Panel
        title="Post a manual journal"
        description="Use for depreciation, accruals, corrections and reclassifications."
        cta="New journal"
        defaultOpen={params.panel === "new"}
      >
        <JournalForm accounts={accountRows} clients={clientRows} today={today()} />
      </Panel>

      <Card padded={false}>
        <div className="flex items-center justify-between border-b border-line px-4 py-3.5">
          <div>
            <h2 className="text-[0.92rem] font-extrabold text-navy">Posting register</h2>
            <p className="text-[0.72rem] font-medium text-muted">Newest first · expand a row to inspect both sides of the entry</p>
          </div>
          <Badge tone={balanced ? "green" : "red"}>{balanced ? "Ledger balanced" : "Ledger differs"}</Badge>
        </div>

        {journalRows.length === 0 ? (
          <div className="p-4">
            <EmptyState title="No journals yet" message="Raise an invoice, capture an expense or post a manual journal." />
          </div>
        ) : (
          <TableWrap className="rounded-none border-0">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Document</th>
                  <th>Date</th>
                  <th>Module</th>
                  <th>Description</th>
                  <th>Client</th>
                  <th className="num">Debit</th>
                  <th className="num">Credit</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {journalRows.map((journal) => {
                  const lines = linesByJournal.get(journal.id) ?? [];
                  const debit = lines.reduce((sum, line) => sum + line.debit, 0);
                  const credit = lines.reduce((sum, line) => sum + line.credit, 0);
                  const client = journal.clientId ? clientById.get(journal.clientId) : null;
                  return (
                    <tr key={journal.id}>
                      <td className="whitespace-nowrap font-mono text-[0.72rem] font-bold text-navy">{journal.docNo}</td>
                      <td className="whitespace-nowrap text-[0.72rem] text-muted">{prettyDate(journal.date)}</td>
                      <td><Badge tone="slate">{journal.module}</Badge></td>
                      <td className="max-w-[300px]">
                        <details className="group">
                          <summary className="cursor-pointer list-none">
                            <span className="block truncate font-semibold text-ink">{journal.description}</span>
                            <span className="text-[0.65rem] font-bold text-sky-700 group-open:hidden">Show {lines.length} lines</span>
                          </summary>
                          <ul className="mt-2 space-y-1 rounded-lg border border-line bg-[#fafcff] p-2">
                            {lines.map((line) => (
                              <li key={line.id} className="flex items-start justify-between gap-2 text-[0.68rem]">
                                <span className="font-semibold text-navy">
                                  {line.accountNo} · {line.accountName}
                                  {line.description ? <span className="block font-medium text-muted">{line.description}</span> : null}
                                </span>
                                <span className="whitespace-nowrap font-bold tabular-nums">
                                  {line.debit > 0 ? `Dr ${money(line.debit)}` : `Cr ${money(line.credit)}`}
                                </span>
                              </li>
                            ))}
                          </ul>
                        </details>
                      </td>
                      <td className="max-w-[120px] truncate text-[0.72rem] font-semibold text-muted">{client ? client.name : "Firm books"}</td>
                      <td className="num font-bold">{money(debit)}</td>
                      <td className="num font-bold">{money(credit)}</td>
                      <td><Badge tone="green">{journal.status}</Badge></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </TableWrap>
        )}
      </Card>
      <p className="text-[0.7rem] font-medium text-muted">Today is {today()} · Ledger storage: PostgreSQL with immutable posted lines.</p>
    </div>
  );
}
