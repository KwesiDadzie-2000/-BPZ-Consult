# BPZ Consult — Practice & Accounting Workspace

A production-shaped rebuild of the BPZ Consult workspace from the supplied archive. The original build checked
credentials in the browser (localStorage) and kept sessions client-side, which is why sign-in failed and could be
bypassed. This version moves identity, the ledger and all master data into PostgreSQL via Drizzle ORM.

## Workspace credentials (provisioned on first run)

| Role | Username | Email | Password |
| --- | --- | --- | --- |
| Owner | `owner` | owner@bpzconsult.com | `BpzOwner2026!` |
| Manager | `ama` | ama@bpzconsult.com | `BpzAma2026!` |
| Accountant | `kofi` | kofi@bpzconsult.com | `BpzKofi2026!` |
| Auditor (read-only) | `auditor` | auditor@bpzconsult.com | `BpzAuditor2026!` |

Passwords are stored as scrypt hashes with per-user salts. Rotate any credential from **Settings → Change password**,
from **Team & access** (owner), or with the public **Forgot password?** flow (single-use link, 30-minute expiry).

## What was fixed

- Server-side credential verification (scrypt, 64-byte keys, timing-safe compare) instead of browser checks.
- Opaque 256-bit session tokens in an HttpOnly/SameSite cookie; tokens are stored only as SHA-256 hashes.
- Persisted sign-in lockout (5 failures → 5 minutes) that cannot be cleared by refreshing the browser.
- 8-hour sliding sessions with revocation per device and "sign out everywhere".
- Single-use password reset with session revocation; no credential material is ever returned to the client.
- Double-entry enforcement: invoices, receipts, expenses, supplier payments, bank movements, payroll and manual
  journals all post balanced ledger lines inside database transactions.
- Unique invoice/document numbers, server-side validation of amounts/dates/roles, read-only auditor boundary.
- Financial statements (P&L, balance sheet, trial balance) are derived live from posted journals.
- Ghana payroll: GRA PAYE bands plus SSNIT employee/employer contributions.

## Modules

Dashboard · Clients · Sales invoices · Expenses · Banking & cash · Journal entries · Chart of accounts ·
Payroll · Financial reports · Team & access · Settings (profile, password, sessions, audit trail).

## Local commands

```bash
npx drizzle-kit push   # apply schema
npm run build          # production build
npm start              # start on :3000
```

`GET /api/health` verifies the database connection. The workspace seeds itself idempotently on first page load.

## Troubleshooting the preview

- **You see the old yellow "Preview access: credentials are checked on this device" banner** — that is the original
  browser-only build, not this one. Do a hard refresh (Ctrl/Cmd+Shift+R) or open a fresh preview URL. The rebuilt
  workspace shows a split-screen sign-in page and prints `Secured build v2.1` at the bottom of the form and in the
  workspace footer.
- **"This page couldn't load"** — the app now ships friendly error boundaries. If the database is cold, the schema is
  provisioned automatically (`src/lib/bootstrap.ts`, advisory-locked and idempotent) and `/api/health` reports
  `{ ok: true, database: "ready", schema: "provisioned" }`.
- **Sign-in succeeds but you bounce back to the login screen** — the session cookie is now marked `Secure` only when
  the request really arrived over HTTPS, so HTTP previews keep their cookie.
- **Locked out** — five wrong passwords lock the account for five minutes; the recovery link clears it immediately.
