import assert from 'node:assert/strict';
import test from 'node:test';

import { validateJournalLines } from '../src/lib/journalValidation';
import { hashPassword, newSalt, verifyPassword } from '../src/lib/password';
import type { ACDOCALine } from '../src/types/accounting';

const line = (over: Partial<ACDOCALine>): ACDOCALine => ({
  id: over.id ?? `L-${Math.random()}`,
  docNo: over.docNo ?? 'JE-1',
  period: over.period ?? '2026-03',
  date: over.date ?? '2026-03-20',
  module: over.module ?? 'FI',
  docType: over.docType ?? 'JE',
  accountNo: over.accountNo ?? '100000',
  accountName: over.accountName ?? 'Cash at Bank',
  costCenter: over.costCenter ?? 'CC-ADM',
  debit: over.debit ?? 0,
  credit: over.credit ?? 0,
  currency: over.currency ?? 'GHS',
  description: over.description ?? 'test',
  createdBy: over.createdBy ?? 'demo',
  clientId: over.clientId ?? 2,
});

const ctx = {
  allowedClientIds: [1, 2, 3, 4],
  closedPeriodKeys: new Set(['2:2026-02']),
  coaAccountNos: new Set(['100000', '400000', '510000']),
};

test('server validation accepts a balanced, in-scope journal document', () => {
  const lines = [line({ id: 'a', debit: 1000 }), line({ id: 'b', accountNo: '400000', credit: 1000 })];
  assert.equal(validateJournalLines(lines, ctx), null);
});

test('server validation rejects cross-tenant postings', () => {
  const lines = [line({ id: 'a', clientId: 99, debit: 1000 }), line({ id: 'b', clientId: 99, accountNo: '400000', credit: 1000 })];
  assert.match(validateJournalLines(lines, ctx)!, /different client/);
});

test('server validation rejects posting into a closed period', () => {
  const lines = [line({ id: 'a', period: '2026-02', debit: 1000 }), line({ id: 'b', period: '2026-02', accountNo: '400000', credit: 1000 })];
  assert.match(validateJournalLines(lines, ctx)!, /closed and frozen/);
});

test('a period closed for one entity does not freeze another entity', () => {
  // 2026-02 is closed for client 2 only; the same period is open for client 3.
  const otherEntity = [line({ id: 'a', clientId: 3, period: '2026-02', debit: 1000 }), line({ id: 'b', clientId: 3, period: '2026-02', accountNo: '400000', credit: 1000 })];
  assert.equal(validateJournalLines(otherEntity, ctx), null);
});

test('server validation rejects unknown chart-of-accounts numbers', () => {
  const lines = [line({ id: 'a', accountNo: '999999', debit: 1000 }), line({ id: 'b', accountNo: '400000', credit: 1000 })];
  assert.match(validateJournalLines(lines, ctx)!, /does not exist in the chart of accounts/);
});

test('server validation rejects unbalanced and negative documents', () => {
  const unbalanced = [line({ id: 'a', debit: 1000 }), line({ id: 'b', accountNo: '400000', credit: 999 })];
  assert.match(validateJournalLines(unbalanced, ctx)!, /not balanced/);
  const negative = [line({ id: 'a', debit: -5 }), line({ id: 'b', accountNo: '400000', credit: -5 })];
  assert.match(validateJournalLines(negative, ctx)!, /Invalid amounts/);
  const zeroDoc = [line({ id: 'a', debit: 0 }), line({ id: 'b', accountNo: '400000', credit: 0 })];
  assert.match(validateJournalLines(zeroDoc, ctx)!, /not balanced/);
});

test('password hashing round-trips and rejects wrong passwords', async () => {
  const salt = newSalt();
  const hash = await hashPassword('BpzOwner2026!', salt);
  assert.equal(await verifyPassword('BpzOwner2026!', salt, hash), true);
  assert.equal(await verifyPassword('wrong-password', salt, hash), false);
  assert.notEqual(hash, 'BpzOwner2026!', 'passwords are never stored in plaintext');
});
