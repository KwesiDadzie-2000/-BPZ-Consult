import assert from 'node:assert/strict';
import test from 'node:test';

import { INITIAL_ACDOCA_LINES, INITIAL_CHART_OF_ACCOUNTS, INITIAL_CLIENTS } from '../src/data/accountingSeed';
import {
  aggregateTrialBalance,
  ageIntoBuckets,
  buildCashFlow,
  buildFxRevaluation,
  computeCit,
  matchStatementLines,
  parseStatementCsv,
  sectorCitRate,
} from '../src/utils/reports';
import type { ACDOCALine } from '../src/types/accounting';

const client2 = INITIAL_CLIENTS.find((c) => c.id === 2)!;
const lines2 = INITIAL_ACDOCA_LINES.filter((l) => l.clientId === client2.id);

test('trial balance aggregation balances for the seeded entity', () => {
  const tb = aggregateTrialBalance(lines2, INITIAL_CHART_OF_ACCOUNTS);
  const dr = tb.reduce((n, r) => n + r.dr, 0) / 100;
  const cr = tb.reduce((n, r) => n + r.cr, 0) / 100;
  assert.equal(dr, cr, 'aggregated trial balance balances');
});

test('IAS 7 cash flow reconciles to the cash ledger movement (residual zero)', () => {
  for (const [from, through] of [['2026-01-01', '2026-03-31'], ['2026-02-01', '2026-03-31'], ['2026-01-01', '2026-12-31']] as const) {
    const cf = buildCashFlow(lines2, INITIAL_CHART_OF_ACCOUNTS, from, through);
    assert.equal(cf.residual, 0, `residual must be zero for ${from}..${through}`);
    assert.equal(cf.cashMovement, cf.netChange, 'cash movement equals net change in cash');
    assert.equal(cf.closingCash - cf.openingCash, cf.netChange);
  }
  // Seeded activity: insurance prepayment acquisition and wire settlement are cash outflows.
  const cf = buildCashFlow(lines2, INITIAL_CHART_OF_ACCOUNTS, '2026-01-01', '2026-03-31');
  assert.ok(cf.closingCash < 0, 'net cash movement is negative for the seeded quarter');
  assert.ok(cf.profitBeforeTax > 0, 'the entity is profitable in the seeded quarter');
});

test('AR/AP aging buckets sum to the open total', () => {
  const buckets = ageIntoBuckets('2026-03-31', [
    { date: '2026-03-20', amount: 100 },   // 11 days -> current
    { date: '2026-02-20', amount: 200 },   // 39 days -> 31-60
    { date: '2026-01-15', amount: 300 },   // 75 days -> 61-90
    { date: '2025-11-01', amount: 400 },   // 151 days -> over 90
  ]);
  assert.equal(buckets.current, 100);
  assert.equal(buckets.days31to60, 200);
  assert.equal(buckets.days61to90, 300);
  assert.equal(buckets.over90, 400);
  assert.equal(buckets.total, 1000);
  assert.equal(buckets.overdueCount, 3);
});

test('sector CIT rates match the Ghanaian sector reference', () => {
  assert.equal(sectorCitRate('Mining & Mineral Extraction').rate, 35);
  assert.equal(sectorCitRate('Professional Services / Advisory').rate, 25);
  assert.equal(sectorCitRate('Commercial Agriculture & Export').rate, 1);
  assert.equal(sectorCitRate('Cross-Border Supply Chain & IT').rate, 25); // standard fallback
});

test('CIT working paper computes gross and net payable after WHT credits', () => {
  const cit = computeCit(1000000, 25, 50000);
  assert.deepEqual(cit, { taxableProfit: 1000000, citRatePct: 25, grossCit: 250000, whtCredits: 50000, netPayable: 200000 });
  const loss = computeCit(-500, 25, 0);
  assert.equal(loss.grossCit, 0, 'no CIT on a loss-making period');
});

test('IAS 21 FX revaluation values FCY monetary items at the closing rate', () => {
  const fcyLines: ACDOCALine[] = [
    { id: 'F1', docNo: 'FX-1', period: '2026-03', date: '2026-03-05', module: 'FI', docType: 'PAY', accountNo: '101000', accountName: 'Bank Foreign Currency USD/EUR', debit: 10000, credit: 0, currency: 'USD', description: 'USD receipt', createdBy: 'demo', clientId: 2 },
    { id: 'F2', docNo: 'FX-2', period: '2026-03', date: '2026-03-12', module: 'FI', docType: 'PAY', accountNo: '101000', accountName: 'Bank Foreign Currency USD/EUR', debit: 0, credit: 2000, currency: 'USD', description: 'USD payment', createdBy: 'demo', clientId: 2 },
  ];
  const rows = buildFxRevaluation(fcyLines, INITIAL_CHART_OF_ACCOUNTS, 'USD', 12, 12.5);
  assert.equal(rows.length, 1);
  assert.equal(rows[0].fcyBalance, 8000);
  assert.equal(rows[0].revaluedGhs, 100000);
  assert.equal(rows[0].gainLoss, 4000, '8000 USD x (12.5 - 12) = 4000 GHS unrealised gain');
});

test('bank statement CSV parses and auto-matches posted journal lines', () => {
  const csv = ['Date,Description,Debit,Credit', '2026-03-11,Wire settlement,0,80000', '2026-03-12,Unknown item,500,0'].join('\n');
  const stmt = parseStatementCsv(csv);
  assert.equal(stmt.length, 2);
  const journal = lines2.filter((l) => l.accountNo === '100000');
  const results = matchStatementLines(stmt, journal, '100000');
  assert.equal(results[0].matched, true, 'the ₵80,000 wire matches PAY-2026-042 within the value-date window');
  assert.equal(results[0].matchedDocNo, 'PAY-2026-042');
  assert.equal(results[1].matched, false, 'the unmatched ₵500 item stays unmatched');
});
