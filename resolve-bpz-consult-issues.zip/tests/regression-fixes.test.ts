import test from 'node:test';
import assert from 'node:assert/strict';
import { getTableConfig, type PgTable } from 'drizzle-orm/pg-core';
import * as schema from '../src/db/schema';
import { SCHEMA_DDL } from '../src/db/ddl';
import { nextDocNo, nextIntId, uniqueId, docSuffix } from '../src/utils/ids';

const INT32_MAX = 2_147_483_647;

test('BUG FIX: new client / bank / employee ids fit a PostgreSQL integer column', () => {
  // The original used Date.now() (~1.7e12), which overflows `integer` and made
  // every state sync containing a new client, bank account or employee fail.
  assert.ok(Date.now() > INT32_MAX, 'precondition: Date.now() really overflows int32');
  const existing = [{ id: 1 }, { id: 2 }, { id: 3 }];
  for (let i = 0; i < 2000; i += 1) {
    const id = nextIntId(existing);
    assert.ok(Number.isInteger(id) && id > 0 && id <= INT32_MAX, `id ${id} must fit int32`);
    assert.ok(!existing.some((row) => row.id === id), 'id must not clash with existing rows');
  }
});

test('BUG FIX: journal-line ids are unique even within the same millisecond', () => {
  // "Post all due" prepayments generated `JL-PRE-${Date.now()}-1` for every line
  // in one loop → duplicate primary keys → the whole server sync rolled back.
  const ids = new Set<string>();
  for (let i = 0; i < 20000; i += 1) ids.add(uniqueId('JL-PRE'));
  assert.equal(ids.size, 20000);
  const suffixes = new Set<string>();
  for (let i = 0; i < 5000; i += 1) suffixes.add(docSuffix());
  assert.equal(suffixes.size, 5000, 'document suffixes must not repeat');
});

test('BUG FIX: invoice / PO numbers are sequential and never repeat', () => {
  // Previously `INV-2026-${random 1000–9999}` — duplicates were rejected by the
  // server as "already posted with different content".
  assert.equal(nextDocNo('INV-2026', []), 'INV-2026-0001');
  assert.equal(nextDocNo('INV-2026', ['INV-2026-0001', 'INV-2026-0007', 'INV-2025-0099', null]), 'INV-2026-0008');
  const issued: string[] = [];
  for (let i = 0; i < 300; i += 1) issued.push(nextDocNo('PO-2026', issued));
  assert.equal(new Set(issued).size, 300);
  assert.equal(nextDocNo('CNT-2026', ['CNT-2026-009'], 3), 'CNT-2026-010');
});

test('BUG FIX: self-provisioning DDL creates every table in the schema', () => {
  // Root cause of "Login failed.": a fresh database had no tables at all.
  const tables = (Object.values(schema) as unknown[])
    .filter((value) => typeof value === 'object' && value !== null && Symbol.for('drizzle:IsDrizzleTable') in value)
    .map((table) => getTableConfig(table as PgTable).name);
  assert.ok(tables.length >= 18, `expected the full schema, found ${tables.length} tables`);
  for (const name of tables) {
    assert.ok(
      SCHEMA_DDL.some((statement) => statement.startsWith(`CREATE TABLE IF NOT EXISTS "${name}"`)),
      `DDL is missing table "${name}" — regenerate src/db/ddl.ts`
    );
  }
  for (const statement of SCHEMA_DDL) {
    assert.match(statement, /IF NOT EXISTS/, 'every statement must be idempotent');
  }
});

test('BUG FIX: firm-level partner/manager accounts get firm-wide scope; entity users stay confined', async () => {
  const { hasFirmWideScope } = await import('../src/utils/access');
  // Original: only `owner` was firm-wide → manager_ama / checker_kofi saw an empty workspace.
  assert.equal(hasFirmWideScope({ role: 'owner', clientId: null }), true);
  assert.equal(hasFirmWideScope({ role: 'partner', clientId: null }), true, 'manager_ama');
  assert.equal(hasFirmWideScope({ role: 'manager', clientId: undefined }), true, 'checker_kofi');
  assert.equal(hasFirmWideScope({ role: 'accountant', clientId: 2 }), false, 'demo stays on its entity');
  assert.equal(hasFirmWideScope({ role: 'accountant', clientId: null }), false, 'accountants are never firm-wide');
  assert.equal(hasFirmWideScope({ role: 'manager', clientId: 3 }), false, 'entity-bound managers stay confined');
});
