import type { ACDOCALine, AccountMaster } from '../types/accounting';

const round2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;

/**
 * Builds the immutable counter-reversal document for a posted document.
 * Reversals post to the CURRENT period (never the frozen original period),
 * mirror every line (Dr ↔ Cr), reference the original document number and are
 * flagged as reversal lines. A document may only be reversed once — the caller
 * must confirm no `REV-<docNo>` exists yet and mark the original isReversed.
 */
export function buildReversalLines(
  original: ACDOCALine[],
  opts: { username: string; canCheck: boolean; period: string; date: string }
): ACDOCALine[] {
  if (!original.length) return [];
  const docNo = original[0].docNo;
  // Line ids must be globally unique: a date-based id collided whenever two
  // documents were reversed on the same day, which silently rolled the first
  // reversal back out of the ledger.
  const stamp = `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
  return original.map((orig, i) => ({
    id: `JL-REV-${stamp}-${i}`,
    docNo: `REV-${docNo}`,
    period: opts.period,
    date: opts.date,
    module: orig.module,
    docType: 'REV',
    accountNo: orig.accountNo,
    accountName: orig.accountName,
    costCenter: orig.costCenter,
    debit: orig.credit,
    credit: orig.debit,
    currency: orig.currency,
    description: `Reversal of ${docNo}: ${orig.description}`,
    createdBy: opts.username,
    // A reversal is a posting in its own right: it needs an independent checker
    // when the poster carries checker authority, but it is NOT itself "reversed".
    checkedBy: opts.canCheck ? opts.username : undefined,
    clientId: orig.clientId,
    reference: docNo,
  }));
}

/** Reasons a reversal can be refused — surfaced to the user verbatim. */
export type ReversalBlock =
  | { ok: true }
  | { ok: false; reason: string };

/**
 * Pre-flight check for a document reversal. Keeps the UI honest: every refusal
 * names the exact control that blocked it instead of a generic failure.
 */
export function checkReversal(
  all: ACDOCALine[],
  docNo: string,
  clientId: number,
  opts: { currentPeriod: string; closedPeriods: string[] }
): ReversalBlock {
  const original = all.filter((l) => l.clientId === clientId && l.docNo === docNo);
  if (!original.length) return { ok: false, reason: `document ${docNo} does not exist in this entity's ledger` };
  if (original[0].docType === 'REV') return { ok: false, reason: `${docNo} is itself a reversal — post a fresh adjusting entry instead` };
  if (original.some((l) => l.isReversed)) return { ok: false, reason: `${docNo} has already been reversed` };
  if (all.some((l) => l.clientId === clientId && l.docNo === `REV-${docNo}`)) {
    return { ok: false, reason: `a reversal document REV-${docNo} already exists for this entity` };
  }
  if (opts.closedPeriods.includes(opts.currentPeriod)) {
    return { ok: false, reason: `the current period ${opts.currentPeriod} is closed for this entity — reopen it in Month-End Close` };
  }
  const currencies = new Set(original.map((l) => l.currency));
  if (currencies.size > 1) return { ok: false, reason: `${docNo} mixes currencies (${[...currencies].join(', ')}) and cannot be auto-reversed` };
  return { ok: true };
}

export interface YearEndCloseResult {
  lines: ACDOCALine[];
  /** Profit (positive) or loss (negative) transferred to retained earnings. */
  net: number;
  /** P/L account codes with non-zero year balances. */
  accountsClosed: string[];
}

/**
 * Year-end close: zero every Income/Expense account's fiscal-year balance into
 * Retained Earnings (310000). One line per account with a non-zero balance plus
 * the retained-earnings offset — the document always balances by construction.
 * Returns null when there is nothing to close (no P/L activity or net = 0).
 */
export function buildYearEndCloseEntries(
  yearLines: ACDOCALine[],
  accounts: AccountMaster[],
  opts: { year: number; period: string; date: string; currency: string; username: string; canCheck: boolean; clientId: number }
): YearEndCloseResult | null {
  const balances = new Map<string, number>(); // positive = debit balance, negative = credit
  for (const l of yearLines) {
    balances.set(l.accountNo, (balances.get(l.accountNo) ?? 0) + l.debit - l.credit);
  }
  const typeOf = (code: string) => accounts.find((a) => a.accountNo === code)?.type;
  const pl = [...balances.entries()]
    .filter(([code, bal]) => Math.abs(bal) >= 0.005 && (typeOf(code) === 'Income' || typeOf(code) === 'Expense'))
    .map(([code, bal]) => ({ code, bal, name: accounts.find((a) => a.accountNo === code)?.name || 'P/L account' }));

  if (!pl.length) return null;
  // Retained-earnings offset: income accounts carry credit balances (negative bal)
  // and must be debited; expense accounts carry debit balances (positive bal) and
  // must be credited. The RE line absorbs the remainder so Dr = Cr exactly.
  const reOffset = round2(pl.reduce((s, p) => s + p.bal, 0));
  if (Math.abs(reOffset) < 0.005) return null;

  const base = {
    docNo: `YE-CLOSE-${opts.year}`,
    period: opts.period,
    date: opts.date,
    module: 'FI' as const,
    docType: 'JE' as const,
    costCenter: 'CC-ADM' as const,
    currency: opts.currency,
    createdBy: opts.username,
    checkedBy: opts.canCheck ? opts.username : undefined,
    clientId: opts.clientId,
    reference: `Fiscal year ${opts.year} close`,
  };

  const lines: ACDOCALine[] = pl.map((p, i) => ({
    ...base,
    id: `JL-YE-${opts.year}-${i}`,
    accountNo: p.code,
    accountName: p.name,
    debit: p.bal < 0 ? round2(-p.bal) : 0,
    credit: p.bal > 0 ? round2(p.bal) : 0,
    description: `Year-end close ${opts.year}: clear ${p.name}`,
  }));
  lines.push({
    ...base,
    id: `JL-YE-${opts.year}-RE`,
    accountNo: '310000',
    accountName: 'Retained Earnings',
    debit: reOffset > 0 ? round2(reOffset) : 0,
    credit: reOffset < 0 ? round2(-reOffset) : 0,
    description: `Year-end close ${opts.year}: transfer ${reOffset >= 0 ? 'profit' : 'loss'} to retained earnings`,
  });
  return { lines, net: round2(-reOffset), accountsClosed: pl.map((p) => p.code) };
}
