import type { BankAccount } from '../types/accounting';

export type PaymentMethod = 'bank_transfer' | 'cash' | 'mobile_money' | 'cheque';

/**
 * Treasury GL for a bank/cash record. Bank accounts and cash-on-hand accounts are
 * kept as strictly separate GL accounts so opening balances reconcile for each.
 */
export const treasuryGl = (acc: BankAccount) => acc.glAccount || (acc.kind === 'cash' ? '102000' : '100000');

/**
 * Resolve which treasury record actually funds a disbursement or receives a receipt:
 * cash payments draw on a cash float, mobile money on the mobile money clearing
 * record, bank transfers and cheques on the selected bank account.
 */
export const fundingAccountFor = (method: PaymentMethod, bank: BankAccount, allAccounts: BankAccount[]): BankAccount => {
  if (method === 'mobile_money') {
    return allAccounts.find((b) => b.glAccount === '104000') || (bank.kind === 'cash' ? bank : allAccounts.find((b) => b.kind === 'cash') || bank);
  }
  if (method === 'cash') {
    return bank.kind === 'cash' ? bank : allAccounts.find((b) => b.kind === 'cash') || bank;
  }
  return bank;
};

export const paymentAccountFor = (method: PaymentMethod, funding: BankAccount) => {
  const no = treasuryGl(funding);
  const name = no === '104000'
    ? 'Mobile Money Clearing Account'
    : funding.kind === 'cash'
      ? funding.name
      : method === 'cheque'
        ? `Cheques Issued (${funding.bankName})`
        : `Cash at Bank (${funding.bankName})`;
  return { no, name, id: funding.id };
};
