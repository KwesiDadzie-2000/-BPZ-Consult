import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "BPZ Consult ERP",
  description: "BPZ Consult — multi-entity accounting, tax, payroll and IFRS reporting workspace.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-[#f0f6fc] text-[#0a253e] antialiased">{children}</body>
    </html>
  );
}
