"use client";

import dynamic from "next/dynamic";

// The BPZ Consult ERP workspace is a browser-persisted (localStorage) application.
// It is rendered entirely on the client to keep the system exactly as designed.
const ErpApp = dynamic(() => import("@/App").then((mod) => mod.App), {
  ssr: false,
  loading: () => (
    <div className="min-h-screen bg-[#f0f6fc] text-[#0a253e] flex items-center justify-center font-sans">
      <div className="text-xs font-bold uppercase tracking-widest text-[#355875]">Loading BPZ Consult ERP…</div>
    </div>
  ),
});

export default function Page() {
  return <ErpApp />;
}
