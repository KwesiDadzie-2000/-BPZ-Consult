import { ensureDatabaseReady } from "@/db/bootstrap";
import { db } from "@/db";
import {
  approvalRequests,
  auditLog,
  bankAccounts,
  businessPartners,
  chartAccounts,
  closedPeriods,
  clients,
  companyProfiles,
  disclosureNotes,
  employees,
  journalLines,
  payrollRecords,
  prepaymentRecords,
  prepaymentSchedules,
  purchaseOrders,
  salesInvoices,
} from "@/db/schema";
import { getSessionUser, hasFirmWideScope } from "@/lib/auth";
import { validateJournalLines } from "@/lib/journalValidation";
import { eq, inArray } from "drizzle-orm";
import type {
  ACDOCALine,
  AccountMaster,
  ApprovalRequest,
  BankAccount,
  BusinessPartner,
  ClientEntity,
  DisclosureNote,
  EmployeeProfile,
  MonthlyPayrollRecord,
  PrepaymentRecord,
  PrepaymentScheduleLine,
  PurchaseOrder,
  SalesInvoice,
} from "@/types/accounting";
import type { CompanyProfile } from "@/utils/persistentStorage";

export const dynamic = "force-dynamic";

interface StatePayload {
  clients?: ClientEntity[];
  journalLines?: ACDOCALine[];
  bankAccounts?: BankAccount[];
  purchaseOrders?: PurchaseOrder[];
  salesInvoices?: SalesInvoice[];
  employees?: EmployeeProfile[];
  businessPartners?: BusinessPartner[];
  payrollRecords?: MonthlyPayrollRecord[];
  prepaymentRecords?: PrepaymentRecord[];
  prepaymentSchedules?: PrepaymentScheduleLine[];
  approvalRequests?: ApprovalRequest[];
  companyProfiles?: Record<number, CompanyProfile>;
  chartOfAccounts?: AccountMaster[];
  disclosureNotes?: DisclosureNote[];
  closedPeriods?: { clientId: number; period: string }[];
}

/**
 * Full-state sync. The server is authoritative: journal lines are validated
 * (tenant, open periods, COA existence, double entry) and the whole write is one
 * transaction. Firm-level masters (clients, COA, disclosures) are owner-writable
 * only; every operational row is tenant-filtered.
 */
export async function PUT(req: Request) {
  await ensureDatabaseReady();
  try {
    return await handlePut(req);
  } catch (e) {
    console.error("state sync error", e);
    return Response.json({ ok: false, error: e instanceof Error ? e.message : "State sync failed." }, { status: 500 });
  }
}

async function handlePut(req: Request) {
  const user = await getSessionUser(req);
  if (!user) return Response.json({ ok: false, error: "Unauthorized" }, { status: 401 });

  let body: StatePayload;
  try {
    body = await req.json();
  } catch {
    return Response.json({ ok: false, error: "Invalid payload." }, { status: 400 });
  }

  // Full-state sync contract: partial payloads are rejected so a sync can never
  // silently wipe datasets the caller did not include.
  const coreFields: (keyof StatePayload)[] = [
    "journalLines", "bankAccounts", "purchaseOrders", "salesInvoices", "employees",
    "businessPartners", "payrollRecords", "prepaymentRecords", "prepaymentSchedules",
    "approvalRequests", "closedPeriods", "companyProfiles",
  ];
  if (coreFields.some((f) => body[f] === undefined)) {
    return Response.json({ ok: false, error: "Partial state sync rejected — send the full workspace state." }, { status: 400 });
  }

  const isOwner = user.role === "owner";
  const firmWide = hasFirmWideScope(user);
  const myClientId = user.clientId ?? null;

  // Tenant filter: non-owners may only touch their own entity (or untagged legacy rows).
  const tenantOk = (clientId: number | undefined | null): boolean =>
    firmWide || clientId === myClientId || clientId === undefined || clientId === null;

  const lines = body.journalLines ?? [];
  const banks = body.bankAccounts ?? [];
  const pos = body.purchaseOrders ?? [];
  const invoices = body.salesInvoices ?? [];
  const emps = body.employees ?? [];
  const partners = body.businessPartners ?? [];
  const payroll = body.payrollRecords ?? [];
  const prepayments = body.prepaymentRecords ?? [];
  const prepaidSchedules = body.prepaymentSchedules ?? [];
  const approvals = body.approvalRequests ?? [];
  const closed = body.closedPeriods ?? [];
  const profiles = body.companyProfiles ?? {};

  if (!firmWide) {
    const rows: (number | undefined | null)[] = [
      ...lines.map((l) => l.clientId),
      ...banks.map((b) => b.clientId),
      ...pos.map((p) => p.clientId),
      ...invoices.map((i) => i.clientId),
      ...emps.map((e) => e.clientId),
      ...partners.map((p) => p.clientId),
      ...payroll.map((r) => r.clientId),
      ...prepayments.map((p) => p.clientId),
      ...prepaidSchedules.map((s) => s.clientId),
      ...approvals.map((a) => a.clientId),
      ...closed.map((c) => c.clientId),
    ];
    if (rows.some((id) => !tenantOk(id))) {
      return Response.json({ ok: false, error: "Cross-tenant write rejected." }, { status: 403 });
    }
    if (Object.keys(profiles).some((id) => Number(id) !== myClientId)) {
      return Response.json({ ok: false, error: "Cross-tenant profile write rejected." }, { status: 403 });
    }
  }

  // Journal validation (tenant, periods, COA, double entry).
  const [allClients, allCoa, allClosed, allApprovals] = await Promise.all([
    db.select().from(clients),
    db.select().from(chartAccounts),
    db.select().from(closedPeriods),
    db.select().from(approvalRequests),
  ]);
  const allowedClientIds = firmWide ? allClients.map((c) => c.id) : myClientId === null ? [] : [myClientId];
  // Periods are frozen per entity — key by client so one entity's close never blocks another.
  const closedKeys = new Set(
    allClosed.filter((c) => allowedClientIds.includes(c.clientId)).map((c) => `${c.clientId}:${c.period}`)
  );
  // COA scope: firm master plus the writable entities' custom accounts.
  const coaNos = new Set(allCoa.filter((a) => a.clientId === null || allowedClientIds.includes(a.clientId)).map((a) => a.accountNo));
  // Duplicate document check against the server copy: documents already posted
  // are re-sent unchanged by the full-state sync; a conflict (same document
  // number, different lines) is rejected.
  const existingDocs = new Set((await db.select().from(journalLines)).map((l) => `${l.clientId}:${l.docNo}`));
  const docs = new Map<string, ACDOCALine[]>();
  for (const l of lines) {
    const key = `${l.clientId}:${l.docNo}`;
    if (!docs.has(key)) docs.set(key, []);
    docs.get(key)!.push(l);
  }
  for (const key of docs.keys()) {
    if (!existingDocs.has(key)) continue;
    const existing = (await db.select().from(journalLines).where(eq(journalLines.docNo, key.split(":")[1]))).filter((l) => l.clientId === Number(key.split(":")[0]));
    const same = existing.length === (docs.get(key)?.length ?? 0) && existing.every((e) => docs.get(key)!.some((n) => n.id === e.id));
    if (!same) return Response.json({ ok: false, error: `Document ${key.split(":")[1]} already posted with different content.` }, { status: 409 });
  }

  // Journal validation applies to NEW documents only — re-sent documents are
  // already in the books, so closing one of their periods afterwards must not
  // block the workspace sync (which would make the period impossible to reopen).
  const freshKeys = new Set([...docs.keys()].filter((key) => !existingDocs.has(key)));
  const freshLines = lines.filter((l) => freshKeys.has(`${l.clientId}:${l.docNo}`));
  // An empty journal list is valid for the full-state sync (nothing to validate) —
  // "no lines" is only an error for single-document posting.
  const journalError = freshLines.length
    ? validateJournalLines(freshLines, { allowedClientIds, closedPeriodKeys: closedKeys, coaAccountNos: coaNos })
    : null;
  if (journalError) return Response.json({ ok: false, error: journalError }, { status: 409 });

  await db.transaction(async (tx) => {
    // Operational tables: tenant-scoped replace. The owner syncs the whole
    // workspace, so their replace clears the entire table first — legacy rows
    // outside the current client list must never survive to cause key collisions.
    const writableIds = firmWide ? allClients.map((c) => c.id) : myClientId === null ? [] : [myClientId];
    const replace = async (table: any, rows: any[], mapRow: (r: any) => Record<string, unknown>) => {
      if (isOwner) {
        await tx.delete(table);
      } else if (writableIds.length) {
        await tx.delete(table).where(inArray(table.clientId, writableIds));
      }
      if (rows.length) await tx.insert(table).values(rows.map(mapRow));
    };

    await replace(journalLines, lines, (l) => ({
      id: l.id, docNo: l.docNo, period: l.period, date: l.date, module: l.module, docType: l.docType,
      accountNo: l.accountNo, accountName: l.accountName, costCenter: l.costCenter ?? null, debit: l.debit,
      credit: l.credit, currency: l.currency, description: l.description, createdBy: l.createdBy,
      checkedBy: l.checkedBy ?? null, isReversed: l.isReversed ?? false, reference: l.reference ?? null, clientId: l.clientId,
    }));
    await replace(bankAccounts, banks, (b) => ({
      id: b.id, clientId: b.clientId ?? 0, code: b.code, name: b.name, bankName: b.bankName, accountNo: b.accountNo,
      currency: b.currency, balance: b.balance, kind: b.kind ?? null, glAccount: b.glAccount ?? null,
    }));
    await replace(purchaseOrders, pos, (p) => ({
      id: p.id, clientId: p.clientId ?? 0, poNo: p.poNo, vendorName: p.vendorName, itemType: p.itemType,
      itemDescription: p.itemDescription, qty: p.qty, unitPrice: p.unitPrice, vatRecoverable: p.vatRecoverable,
      totalAmount: p.totalAmount, paidAmount: p.paidAmount ?? 0, status: p.status, date: p.date,
      currency: p.currency ?? null, vatTreatment: p.vatTreatment ?? null, netAmount: p.netAmount ?? null,
      quotationRef: p.quotationRef ?? null, glAccount: p.glAccount, glAccountName: p.glAccountName,
      costCenter: p.costCenter, costCenterName: p.costCenterName,
    }));
    await replace(salesInvoices, invoices, (i) => ({
      id: i.id, clientId: i.clientId ?? 0, invNo: i.invNo, customerName: i.customerName, revenueStream: i.revenueStream,
      netRevenue: i.netRevenue, vatOutput: i.vatOutput, cstAmount: i.cstAmount ?? null,
      tourismLevyAmount: i.tourismLevyAmount ?? null, vatWithheldByCustomer: i.vatWithheldByCustomer ?? null,
      totalReceivable: i.totalReceivable, paidAmount: i.paidAmount, status: i.status, date: i.date,
    }));
    await replace(employees, emps, (e) => ({
      id: e.id, clientId: e.clientId ?? null, bpNo: e.bpNo, name: e.name, role: e.role, department: e.department,
      costCenter: e.costCenter ?? null, jurisdiction: e.jurisdiction, basicSalary: e.basicSalary, allowances: e.allowances, ssnitNumber: e.ssnitNumber,
      tin: e.tin, status: e.status, isResident: e.isResident ?? true, exemptTier1: e.exemptTier1 ?? false,
      exemptTier2: e.exemptTier2 ?? false, ssnitExempt: e.ssnitExempt ?? false,
      ssnitExemptionReason: e.ssnitExemptionReason ?? null, taxRelief: e.taxRelief ?? 0, reliefType: e.reliefType ?? null,
      deductions: e.deductions ?? null,
    }));
    await replace(businessPartners, partners, (p) => ({
      id: p.id, clientId: p.clientId ?? null, code: p.code, name: p.name, type: p.type, tin: p.tin, email: p.email,
      phone: p.phone, address: p.address, currency: p.currency, isVatWithholdingAgent: p.isVatWithholdingAgent,
      vatWithholdingRate: p.vatWithholdingRate ?? null, isCstApplicable: p.isCstApplicable,
      isTourismLevyApplicable: p.isTourismLevyApplicable, isVatRegistered: p.isVatRegistered ?? null,
    }));
    await replace(payrollRecords, payroll, (r) => ({ id: r.id, clientId: r.clientId ?? 0, record: r }));
    await replace(prepaymentRecords, prepayments, (p) => ({ id: p.id, clientId: p.clientId ?? 0, record: p }));
    await replace(prepaymentSchedules, prepaidSchedules, (s) => ({ id: s.id, prepaymentId: s.prepaymentId, clientId: s.clientId ?? 0, line: s }));
    await replace(approvalRequests, approvals, (a) => ({
      id: a.id, clientId: a.clientId, clientCode: a.clientCode, clientName: a.clientName, docNo: a.docNo,
      docType: a.docType, amount: a.amount, requestedBy: a.requestedBy, requestedAt: a.requestedAt,
      description: a.description, reasonForApproval: a.reasonForApproval, status: a.status,
      reviewedBy: a.reviewedBy ?? null, reviewedAt: a.reviewedAt ?? null, rejectionReason: a.rejectionReason ?? null,
      payload: a.payload ?? null,
    }));
    await replace(closedPeriods, closed.map((c) => ({ ...c, closedAt: new Date().toISOString(), closedBy: user.username })), (c) => ({
      clientId: c.clientId, period: c.period, closedAt: c.closedAt, closedBy: c.closedBy,
    }));

    // Profiles: owner writes all; non-owners only their own entity's profile.
    const profileRows = Object.values(profiles).filter((p) => firmWide || p.clientId === myClientId);
    for (const p of profileRows) {
      await tx.insert(companyProfiles).values({
        clientId: p.clientId, legalName: p.legalName, tradingName: p.tradingName, tin: p.tin, vatRegNo: p.vatRegNo,
        address: p.address, phone: p.phone, email: p.email, website: p.website, fiscalYearStart: p.fiscalYearStart,
        bankPaymentDetails: p.bankPaymentDetails,
      }).onConflictDoUpdate({
        target: companyProfiles.clientId,
        set: {
          legalName: p.legalName, tradingName: p.tradingName, tin: p.tin, vatRegNo: p.vatRegNo, address: p.address,
          phone: p.phone, email: p.email, website: p.website, fiscalYearStart: p.fiscalYearStart,
          bankPaymentDetails: p.bankPaymentDetails,
        },
      });
    }

    // Firm-level masters: owner-only.
    if (isOwner) {
      if (body.clients) {
        for (const c of body.clients) {
          await tx.insert(clients).values({
            id: c.id, code: c.code, name: c.name, sector: c.sector, currency: c.currency, jurisdiction: c.jurisdiction,
            regNumber: c.regNumber, isParent: c.isParent ?? false, assignedServices: c.assignedServices ?? null,
            adminUsername: c.adminUsername ?? null, adminEmail: c.adminEmail ?? null, loginUrl: c.loginUrl ?? null,
          }).onConflictDoUpdate({
            target: clients.id,
            set: {
              code: c.code, name: c.name, sector: c.sector, currency: c.currency, jurisdiction: c.jurisdiction,
              regNumber: c.regNumber, isParent: c.isParent ?? false, assignedServices: c.assignedServices ?? null,
              adminUsername: c.adminUsername ?? null, adminEmail: c.adminEmail ?? null, loginUrl: c.loginUrl ?? null,
            },
          });
        }
      }
      if (body.disclosureNotes) {
        await tx.delete(disclosureNotes);
        if (body.disclosureNotes.length) {
          await tx.insert(disclosureNotes).values(
            body.disclosureNotes.map((n) => ({
              key: n.key, noteNumber: n.noteNumber, title: n.title, standardRef: n.standardRef, applicable: n.applicable,
              notApplicableReason: n.notApplicableReason ?? null, body: n.body, tables: n.tables ?? null,
              editableOverride: n.editableOverride ?? null,
            }))
          );
        }
      }
    }

    // Chart of accounts: the owner maintains the whole chart (firm master plus every
    // entity's customs); non-owners maintain only their own entity's custom accounts.
    if (body.chartOfAccounts) {
      if (isOwner) {
        await tx.delete(chartAccounts);
        if (body.chartOfAccounts.length) {
          await tx.insert(chartAccounts).values(
            body.chartOfAccounts.map((a) => ({
              accountNo: a.accountNo, name: a.name, type: a.type, category: a.category,
              active: a.active, isCustom: a.isCustom ?? false, clientId: a.clientId ?? null,
            }))
          );
        }
      } else if (myClientId !== null) {
        await tx.delete(chartAccounts).where(eq(chartAccounts.clientId, myClientId));
        const own = body.chartOfAccounts.filter((a) => a.clientId === myClientId);
        if (own.length) {
          await tx.insert(chartAccounts).values(
            own.map((a) => ({
              accountNo: a.accountNo, name: a.name, type: a.type, category: a.category,
              active: a.active, isCustom: a.isCustom ?? false, clientId: myClientId,
            }))
          );
        }
      }
    }

    // Audit trail: one entry per newly posted journal document.
    const now = new Date().toISOString();
    // Period freezes and reopens are audit events — the ledger can change hands
    // but the control history must be reviewable.
    const prevClosed = new Set(allClosed.filter((c) => allowedClientIds.includes(c.clientId)).map((c) => `${c.clientId}:${c.period}`));
    const nextClosed = new Set(closed.map((c) => `${c.clientId}:${c.period}`));
    for (const key of nextClosed) {
      if (prevClosed.has(key)) continue;
      const [cid, p] = key.split(":");
      await tx.insert(auditLog).values({ id: crypto.randomUUID(), timestamp: now, userId: user.username, username: user.username, action: "CLOSE_PERIOD", target: `${cid}:${p}`, details: `Period ${p} frozen for client ${cid}`, clientId: Number(cid) });
    }
    for (const key of prevClosed) {
      if (nextClosed.has(key)) continue;
      const [cid, p] = key.split(":");
      await tx.insert(auditLog).values({ id: crypto.randomUUID(), timestamp: now, userId: user.username, username: user.username, action: "REOPEN_PERIOD", target: `${cid}:${p}`, details: `Period ${p} reopened for client ${cid}`, clientId: Number(cid) });
    }
    // Approval resolutions (pending → approved/rejected) are audit events too.
    const prevApprovalStatus = new Map(allApprovals.filter((a) => allowedClientIds.includes(a.clientId)).map((a) => [a.id, a.status]));
    for (const a of approvals) {
      const prev = prevApprovalStatus.get(a.id);
      if (prev && prev !== a.status) {
        await tx.insert(auditLog).values({ id: crypto.randomUUID(), timestamp: now, userId: user.username, username: user.username, action: `APPROVAL_${a.status.toUpperCase()}`, target: a.docNo, details: `${a.clientCode} request by ${a.requestedBy} ${a.status}${a.rejectionReason ? ` — ${a.rejectionReason}` : ""}`, clientId: a.clientId });
      }
    }
    for (const key of freshKeys) {
      const docLines = docs.get(key)!;
      const dr = docLines.reduce((n, l) => n + Math.round(l.debit * 100), 0) / 100;
      await tx.insert(auditLog).values({
        id: crypto.randomUUID(),
        timestamp: now,
        userId: user.username,
        username: user.username,
        action: "POST_JOURNAL",
        target: key.split(":")[1],
        details: `${docLines.length} line(s), debits ${dr.toFixed(2)}`,
        clientId: Number(key.split(":")[0]),
      });
    }
  });

  return Response.json({ ok: true });
}
