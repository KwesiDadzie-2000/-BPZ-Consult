export type Role = 'owner' | 'partner' | 'manager' | 'accountant' | 'auditor';

export interface Workspace {
  id: number;
  code: string;
  name: string;
  sector: string;
  currency: string;
  jurisdiction: string;
  regNumber: string;
  isParent?: boolean;
}

export interface UserSession {
  username: string;
  name: string;
  role: Role;
  makerLimit: number; // e.g., 25000 GHS maker posting limit
  canCheck: boolean; // checker sign-off authority
  email: string;
}

export interface JournalLine {
  id: string;
  docNo: string;
  docType: 'INV' | 'PO' | 'PAY' | 'JE' | 'DEP' | 'IFRS16' | 'REV';
  period: string;
  date: string;
  accountNo: string;
  accountName: string;
  costCenter?: string;
  debit: number;
  credit: number;
  currency: string;
  description: string;
  createdBy: string;
  checkedBy?: string;
  isReversed?: boolean;
  reversalOf?: string;
  clientId: number;
}

export interface NoteTable {
  headers: string[];
  rows: (string | number)[][];
}

export interface DisclosureNote {
  key: string;
  noteNumber: number;
  title: string;
  standardRef: string;
  applicable: boolean;
  notApplicableReason?: string;
  body: string;
  tables?: NoteTable[];
  editableOverride?: boolean;
}

export interface RfpGapItem {
  id: number;
  title: string;
  category: 'hard_blocker' | 'serious_weakness';
  whyFatalToBigFour: string;
  originalShortcoming: string;
  resolutionImplemented: string;
  complianceRef: string;
  status: 'RESOLVED & VERIFIED' | 'CRITICAL ATTENTION';
  demoDeskId: string;
}

export interface GroupMember {
  clientId: number;
  clientCode: string;
  clientName: string;
  ownershipPct: number;
  method: 'Full Consolidation (IFRS 10)' | 'Equity Method (IAS 28)';
  nciShare: number;
  goodwill: number;
  currency: string;
}

export interface IntercompanyTxn {
  id: string;
  fromEntity: string;
  toEntity: string;
  nature: 'Management Fee' | 'Intercompany Loan' | 'Supply of Inventory' | 'Service Re-charge';
  amount: number;
  currency: string;
  eliminated: boolean;
  journalRef: string;
}

export interface SsoProvider {
  id: string;
  name: string;
  protocol: 'saml' | 'oidc' | 'scim';
  enabled: boolean;
  issuer: string;
  clientId: string;
  clientSecretHint: string;
  metadataUrl: string;
  allowedDomains: string[];
  defaultRole: Role;
  lastSync?: string;
}

export interface SocControl {
  controlId: string;
  tscDomain: 'Security (CC)' | 'Availability (A)' | 'Confidentiality (C)' | 'Processing Integrity (PI)';
  description: string;
  status: 'Automated Pass' | 'Audited';
  evidence: string;
  lastTestTimestamp: string;
}

export interface BackupSnapshot {
  id: string;
  timestamp: string;
  sizeMb: number;
  rpoMinutes: number;
  rtoMinutes: number;
  region: string;
  checksum: string;
  status: 'Verified Healthy';
}

export interface ApiKeyItem {
  id: string;
  name: string;
  prefix: string;
  role: string;
  scope: string[];
  createdAt: string;
  lastUsed: string;
  rateLimitPerMin: number;
}

export interface WebhookSubscriber {
  id: string;
  targetUrl: string;
  events: string[];
  status: 'Active (200 OK)' | 'Degraded';
  signingSecret: string;
  lastDispatched: string;
  deliverySuccessPct: number;
}
