import { db } from "@/db";
import { sessions, users } from "@/db/schema";
import { eq } from "drizzle-orm";
import type { UserAccount } from "@/types/accounting";

/**
 * Working sessions last 8 hours and slide forward on every authenticated
 * request once less than 30 minutes remain — a user posting journals or payroll
 * during a long working day must not be cut off mid-task by an expired session.
 */
export const SESSION_TTL_MS = 8 * 60 * 60 * 1000;
const SLIDE_THRESHOLD_MS = 30 * 60 * 1000;

/** Strips secrets — user records returned to the browser never carry password material. */
export function sanitizeUser(row: typeof users.$inferSelect): UserAccount {
  return {
    username: row.username,
    name: row.name,
    role: row.role as UserAccount["role"],
    makerLimit: row.makerLimit,
    canCheck: row.canCheck,
    email: row.email,
    clientId: row.clientId ?? undefined,
    status: (row.status as UserAccount["status"]) ?? "active",
    restrictionReason: row.restrictionReason ?? undefined,
    permissions: (row.permissions as UserAccount["permissions"]) ?? undefined,
  };
}

/** Validates the Bearer token and returns the session user, or null. */
export async function getSessionUser(req: Request): Promise<UserAccount | null> {
  const header = req.headers.get("authorization") || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) return null;
  const found = await db.select().from(sessions).where(eq(sessions.token, token)).limit(1);
  const session = found[0];
  if (!session || session.expiresAt < Date.now()) {
    if (session) await db.delete(sessions).where(eq(sessions.token, token));
    return null;
  }
  // Sliding renewal: extend an active session so continuous work never loses it.
  if (session.expiresAt < Date.now() + SLIDE_THRESHOLD_MS) {
    await db
      .update(sessions)
      .set({ expiresAt: Date.now() + SESSION_TTL_MS })
      .where(eq(sessions.token, token));
  }
  const userRows = await db.select().from(users).where(eq(users.id, session.userId)).limit(1);
  const user = userRows[0];
  if (!user || user.status === "restricted" || user.status === "suspended") return null;
  return sanitizeUser(user);
}

export async function createSession(userId: string): Promise<string> {
  // 256-bit cryptographically random session token (UUIDv4 carries only 122
  // bits and is not specified as a CSPRNG output in every runtime).
  const token = Array.from(crypto.getRandomValues(new Uint8Array(32)))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
  await db.insert(sessions).values({
    token,
    userId,
    expiresAt: Date.now() + SESSION_TTL_MS,
  });
  return token;
}

export async function destroySession(token: string): Promise<void> {
  await db.delete(sessions).where(eq(sessions.token, token));
}

/** Owner-only guard. Returns the user or null (route handlers respond 403). */
export async function requireOwner(req: Request): Promise<UserAccount | null> {
  const user = await getSessionUser(req);
  if (!user || user.role !== "owner") return null;
  return user;
}

export { hasFirmWideScope } from "@/utils/access";
