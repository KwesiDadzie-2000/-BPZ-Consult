import {
  pgTable,
  text,
  integer,
  bigint,
  boolean,
  doublePrecision,
  jsonb,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

/**
 * BPZ Consult ERP — production schema.
 * Money is stored as double-precision and validated in minor units (cents) at the
 * API boundary; every table is tenant-scoped by clientId where applicable.
 */

export const users = pgTable("users", {
  id: text("id").primaryKey(),
  username: text("username").notNull(),
  email: text("email").notNull(),
  name: text("name").notNull(),
  role: text("role").notNull(), // owner | partner | manager | accountant | auditor
  makerLimit: doublePrecision("maker_limit").notNull().default(0),
  canCheck: boolean("can_check").notNull().default(false),
  clientId: integer("client_id"),
  passwordHash: text("password_hash"),
  passwordSalt: text("password_salt"),
  status: text("status").notNull().default("active"),
  restrictionReason: text("restriction_reason"),
  permissions: jsonb("permissions"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  uniqueIndex("users_username_idx").on(t.username),
  uniqueIndex("users_email_idx").on(t.email),
]);

export const sessions = pgTable("sessions", {
  token: text("token").primaryKey(),
  userId: text("user_id").notNull(),
  expiresAt: bigint("expires_at", { mode: "number" }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const clients = pgTable("clients", {
  id: integer("id").primaryKey(),
  code: text("code").notNull(),
  name: text("name").notNull(),
  sector: text("sector").notNull(),
  currency: text("currency").notNull(),
  jurisdiction: text("jurisdiction").notNull(),
  regNumber: text("reg_number").notNull(),
  isParent: boolean("is_parent").notNull().default(false),
  assignedServices: jsonb("assigned_services"),
  adminUsername: text("admin_username"),
  adminEmail: text("admin_email"),
  loginUrl: text("login_url"),
});

export const journalLines = pgTable("journal_lines", {
  id: text("id").primaryKey(),
  docNo: text("doc_no").notNull(),
  period: text("period").notNull(),
  date: text("date").notNull(),
  module: text("module").notNull(),
  docType: text("doc_type").notNull(),
  accountNo: text("account_no").notNull(),
  accountName: text("account_name").notNull(),
  costCenter: text("cost_center"),
  debit: doublePrecision("debit").notNull().default(0),
  credit: doublePrecision("credit").notNull().default(0),
  currency: text("currency").notNull(),
  description: text("description").notNull(),
  createdBy: text("created_by").notNull(),
  checkedBy: text("checked_by"),
  isReversed: boolean("is_reversed").notNull().default(false),
  reference: text("reference"),
  clientId: integer("client_id").notNull(),
});

export const bankAccounts = pgTable("bank_accounts", {
  id: integer("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  code: text("code").notNull(),
  name: text("name").notNull(),
  bankName: text("bank_name").notNull(),
  accountNo: text("account_no").notNull(),
  currency: text("currency").notNull(),
  balance: doublePrecision("balance").notNull().default(0),
  kind: text("kind"), // 'bank' | 'cash'
  glAccount: text("gl_account"),
});

export const purchaseOrders = pgTable("purchase_orders", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  poNo: text("po_no").notNull(),
  vendorName: text("vendor_name").notNull(),
  itemType: text("item_type").notNull(),
  itemDescription: text("item_description").notNull(),
  qty: doublePrecision("qty").notNull(),
  unitPrice: doublePrecision("unit_price").notNull(),
  vatRecoverable: doublePrecision("vat_recoverable").notNull().default(0),
  totalAmount: doublePrecision("total_amount").notNull(),
  paidAmount: doublePrecision("paid_amount").notNull().default(0),
  status: text("status").notNull(),
  date: text("date").notNull(),
  currency: text("currency"),
  vatTreatment: text("vat_treatment"),
  netAmount: doublePrecision("net_amount"),
  quotationRef: text("quotation_ref"),
  glAccount: text("gl_account").notNull(),
  glAccountName: text("gl_account_name").notNull(),
  costCenter: text("cost_center").notNull(),
  costCenterName: text("cost_center_name").notNull(),
});

export const salesInvoices = pgTable("sales_invoices", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  invNo: text("inv_no").notNull(),
  customerName: text("customer_name").notNull(),
  revenueStream: text("revenue_stream").notNull(),
  netRevenue: doublePrecision("net_revenue").notNull(),
  vatOutput: doublePrecision("vat_output").notNull().default(0),
  cstAmount: doublePrecision("cst_amount"),
  tourismLevyAmount: doublePrecision("tourism_levy_amount"),
  vatWithheldByCustomer: doublePrecision("vat_withheld_by_customer"),
  totalReceivable: doublePrecision("total_receivable").notNull(),
  paidAmount: doublePrecision("paid_amount").notNull().default(0),
  status: text("status").notNull(),
  date: text("date").notNull(),
});

export const employees = pgTable("employees", {
  id: integer("id").primaryKey(),
  clientId: integer("client_id"),
  bpNo: text("bp_no").notNull(),
  name: text("name").notNull(),
  role: text("role").notNull(),
  department: text("department").notNull(),
  costCenter: text("cost_center"),
  jurisdiction: text("jurisdiction").notNull(),
  basicSalary: doublePrecision("basic_salary").notNull(),
  allowances: doublePrecision("allowances").notNull().default(0),
  ssnitNumber: text("ssnit_number").notNull(),
  tin: text("tin").notNull(),
  status: text("status").notNull(),
  isResident: boolean("is_resident").notNull().default(true),
  exemptTier1: boolean("exempt_tier1").notNull().default(false),
  exemptTier2: boolean("exempt_tier2").notNull().default(false),
  ssnitExempt: boolean("ssnit_exempt").notNull().default(false),
  ssnitExemptionReason: text("ssnit_exemption_reason"),
  taxRelief: doublePrecision("tax_relief").notNull().default(0),
  reliefType: text("relief_type"),
  deductions: jsonb("deductions"),
});

export const companyProfiles = pgTable("company_profiles", {
  clientId: integer("client_id").primaryKey(),
  legalName: text("legal_name").notNull(),
  tradingName: text("trading_name").notNull(),
  tin: text("tin").notNull(),
  vatRegNo: text("vat_reg_no").notNull(),
  address: text("address").notNull(),
  phone: text("phone").notNull(),
  email: text("email").notNull(),
  website: text("website").notNull(),
  fiscalYearStart: text("fiscal_year_start").notNull(),
  bankPaymentDetails: text("bank_payment_details").notNull(),
});

export const chartAccounts = pgTable("chart_accounts", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  accountNo: text("account_no").notNull(),
  name: text("name").notNull(),
  type: text("type").notNull(),
  category: text("category").notNull(),
  active: boolean("active").notNull().default(true),
  isCustom: boolean("is_custom").notNull().default(false),
  clientId: integer("client_id"), // null = firm master chart shared by all entities
// Unique per owning entity — the firm master chart and a client's own
// custom accounts may legitimately share an account number.
}, (t) => [uniqueIndex("chart_accounts_scope_idx").on(t.accountNo, t.clientId)]);

export const businessPartners = pgTable("business_partners", {
  id: text("id").primaryKey(),
  clientId: integer("client_id"),
  code: text("code").notNull(),
  name: text("name").notNull(),
  type: text("type").notNull(),
  tin: text("tin").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  address: text("address").notNull(),
  currency: text("currency").notNull(),
  isVatWithholdingAgent: boolean("is_vat_withholding_agent").notNull().default(false),
  vatWithholdingRate: doublePrecision("vat_withholding_rate"),
  isCstApplicable: boolean("is_cst_applicable").notNull().default(false),
  isTourismLevyApplicable: boolean("is_tourism_levy_applicable").notNull().default(false),
  isVatRegistered: boolean("is_vat_registered"),
});

export const payrollRecords = pgTable("payroll_records", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  record: jsonb("record").notNull(),
});

export const prepaymentRecords = pgTable("prepayment_records", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  record: jsonb("record").notNull(),
});

export const prepaymentSchedules = pgTable("prepayment_schedules", {
  id: text("id").primaryKey(),
  prepaymentId: text("prepayment_id").notNull(),
  clientId: integer("client_id").notNull(),
  line: jsonb("line").notNull(),
});

export const approvalRequests = pgTable("approval_requests", {
  id: text("id").primaryKey(),
  clientId: integer("client_id").notNull(),
  clientCode: text("client_code").notNull(),
  clientName: text("client_name").notNull(),
  docNo: text("doc_no").notNull(),
  docType: text("doc_type").notNull(),
  amount: doublePrecision("amount").notNull(),
  requestedBy: text("requested_by").notNull(),
  requestedAt: text("requested_at").notNull(),
  description: text("description").notNull(),
  reasonForApproval: text("reason_for_approval").notNull(),
    status: text("status").notNull(),
    reviewedBy: text("reviewed_by"),
    reviewedAt: text("reviewed_at"),
    rejectionReason: text("rejection_reason"),
    // Proposed journal lines awaiting sign-off; posted exactly once on approval.
    payload: jsonb("payload"),
  });

export const disclosureNotes = pgTable("disclosure_notes", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  key: text("key").notNull(),
  noteNumber: integer("note_number").notNull(),
  title: text("title").notNull(),
  standardRef: text("standard_ref").notNull(),
  applicable: boolean("applicable").notNull(),
  notApplicableReason: text("not_applicable_reason"),
  body: text("body").notNull(),
  tables: jsonb("tables"),
  editableOverride: boolean("editable_override"),
});

export const closedPeriods = pgTable("closed_periods", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  clientId: integer("client_id").notNull(),
  period: text("period").notNull(), // e.g. "2026-03"
  closedAt: text("closed_at").notNull(),
  closedBy: text("closed_by").notNull(),
}, (t) => [uniqueIndex("closed_periods_client_period_idx").on(t.clientId, t.period)]);

export const auditLog = pgTable("audit_log", {
  id: text("id").primaryKey(),
  timestamp: text("timestamp").notNull(),
  userId: text("user_id").notNull(),
  username: text("username").notNull(),
  action: text("action").notNull(),
  target: text("target").notNull(),
  details: text("details").notNull(),
  clientId: integer("client_id"),
});
