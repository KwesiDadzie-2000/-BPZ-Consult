import { useState } from 'react';
import { Radio, Key, Webhook, HardDrive, AlertTriangle, Send, FileUp } from 'lucide-react';

const PLAN = [
  { id: 'ws', title: 'Real-time journal push', detail: 'WebSocket or Server-Sent Events with idempotency keys, ordered delivery, and replay from a sequence number when clients reconnect.' },
  { id: 'api', title: 'Versioned REST API', detail: 'OpenAPI 3.1 contract, scoped bearer tokens, per-key rate limits, idempotent write endpoints, and 7-year immutable audit log.' },
  { id: 'hooks', title: 'HMAC-signed webhooks', detail: 'Per-subscriber rotation, replay window, exponential backoff, dead-letter queue, and cryptographic signature verification.' },
  { id: 'object', title: 'Object storage for attachments', detail: 'S3-compatible bucket with server-side encryption, immutability lock, malware scanning, and database stores only the object key and metadata.' },
];

export const IntegrationsDesk: React.FC = () => {
  const [tab, setTab] = useState<'plan' | 'ws' | 'api' | 'hooks' | 'object'>('plan');
  const [demoEvent, setDemoEvent] = useState<string | null>(null);

  const tabs: { id: typeof tab; label: string; Icon: React.ComponentType<{ className?: string }> }[] = [
    { id: 'plan', label: 'Implementation plan', Icon: AlertTriangle },
    { id: 'ws', label: 'Real-time push', Icon: Radio },
    { id: 'api', label: 'Public REST API', Icon: Key },
    { id: 'hooks', label: 'HMAC webhooks', Icon: Webhook },
    { id: 'object', label: 'Object storage', Icon: HardDrive },
  ];

  const appendDemoEvent = (text: string) => {
    setDemoEvent(`[Local sandbox ${new Date().toISOString()}] ${text}`);
  };

  return (
    <div className="space-y-6 text-[#0a253e]">
      <div className="rounded-xl border border-amber-400 bg-amber-50 p-4 text-sm text-amber-950 flex items-start gap-2">
        <AlertTriangle className="h-5 w-5 mt-0.5 text-amber-700 shrink-0" />
        <div>
          <strong>Demo only.</strong> No backend integration is currently running. The features below
          outline what must be implemented server-side. In-browser events, API responses, webhooks and
          uploads are all simulated locally.
        </div>
      </div>

      <div className="flex flex-wrap gap-1 bg-white p-1.5 rounded-xl border border-sky-200 shadow-xs">
        {tabs.map(t => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`flex items-center gap-1.5 rounded px-3 py-2 text-xs font-bold transition ${tab === t.id ? 'bg-[#082f4f] text-white shadow-xs' : 'text-[#355875] hover:bg-sky-50'}`}
          >
            <t.Icon className="h-3.5 w-3.5" />
            <span>{t.label}</span>
          </button>
        ))}
      </div>

      {tab === 'plan' && (
        <div className="rounded-xl border border-sky-200 bg-white p-5 shadow-xs space-y-3">
          <h3 className="text-sm font-bold uppercase tracking-wider text-[#082f4f]">Implementation roadmap (server-side)</h3>
          <ul className="space-y-2 text-xs">
            {PLAN.map(p => (
              <li key={p.id} className="rounded-lg border border-sky-200 bg-sky-50/50 p-3">
                <strong className="text-[#082f4f]">{p.title}</strong>
                <p className="text-[#2d4f6d] mt-0.5">{p.detail}</p>
              </li>
            ))}
          </ul>
        </div>
      )}

      {tab === 'ws' && (
        <div className="rounded-xl border border-sky-200 bg-white p-5 shadow-xs space-y-3">
          <h3 className="text-sm font-bold uppercase tracking-wider text-[#082f4f]">Real-time journal push</h3>
          <p className="text-[11px] text-[#2d4f6d]">The delivery target — once the server is built — is sub-second, ordered push with replay from a sequence number.</p>
          <button onClick={() => appendDemoEvent('Local event simulated (no server delivery).')} className="rounded bg-[#082f4f] text-white text-xs font-bold px-4 py-2 hover:bg-[#0c3f68] flex items-center gap-1.5"><Send className="h-3.5 w-3.5" /> Simulate event (local only)</button>
          {demoEvent && <pre className="rounded bg-sky-50 border border-sky-200 p-3 text-[11px] font-mono text-[#082f4f] overflow-x-auto">{demoEvent}</pre>}
        </div>
      )}

      {tab === 'api' && (
        <div className="rounded-xl border border-sky-200 bg-white p-5 shadow-xs space-y-3">
          <h3 className="text-sm font-bold uppercase tracking-wider text-[#082f4f]">Public REST API</h3>
          <p className="text-[11px] text-[#2d4f6d]">A live API would be documented via OpenAPI 3.1, with scoped bearer tokens and idempotent writes.</p>
          <div className="rounded bg-slate-50 border border-slate-200 p-3 text-[11px] font-mono text-slate-700">
            GET /v1/tenants/{'{tenantId}'}/ledger?period=YYYY-MM<br />
            Authorization: Bearer &lt;scoped-token&gt;<br />
            X-Idempotency-Key: required for write endpoints
          </div>
          <p className="text-[10.5px] text-[#355875]">Browser-side storage of API keys is not used. Keys are issued and revoked by the server, and secrets never appear in client memory.</p>
        </div>
      )}

      {tab === 'hooks' && (
        <div className="rounded-xl border border-sky-200 bg-white p-5 shadow-xs space-y-3">
          <h3 className="text-sm font-bold uppercase tracking-wider text-[#082f4f]">HMAC-signed webhooks</h3>
          <p className="text-[11px] text-[#2d4f6d]">Subscribers receive an HMAC-SHA256 signed payload with timestamp and replay window. The server records every dispatch and retry.</p>
          <ul className="text-[11px] text-[#2d4f6d] list-disc pl-5 space-y-1">
            <li>Per-subscriber signing secret rotation, automated.</li>
            <li>Idempotency key sent in the <code>X-BPZ-Idempotency-Key</code> header.</li>
            <li>Exponential backoff with dead-letter queue on persistent failure.</li>
            <li>Signed timestamp with 5-minute replay window to prevent replay attacks.</li>
          </ul>
        </div>
      )}

      {tab === 'object' && (
        <div className="rounded-xl border border-sky-200 bg-white p-5 shadow-xs space-y-3">
          <h3 className="text-sm font-bold uppercase tracking-wider text-[#082f4f]">Object storage for attachments</h3>
          <p className="text-[11px] text-[#2d4f6d]">Receipts and source documents should be stored in an S3-compatible bucket with server-side encryption and immutability lock. The database only stores the key and metadata.</p>
          <button onClick={() => appendDemoEvent('Object upload simulation (local file selection).')} className="rounded bg-[#082f4f] text-white text-xs font-bold px-4 py-2 hover:bg-[#0c3f68] flex items-center gap-1.5"><FileUp className="h-3.5 w-3.5" /> Simulate upload (local)</button>
          {demoEvent && <pre className="rounded bg-sky-50 border border-sky-200 p-3 text-[11px] font-mono text-[#082f4f] overflow-x-auto">{demoEvent}</pre>}
        </div>
      )}
    </div>
  );
};
