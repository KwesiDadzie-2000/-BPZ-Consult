import React from 'react';
import { ClientEntity, UserAccount } from '../types/accounting';
import { Building2, Wifi, LogOut, Bell } from 'lucide-react';
import { hasFirmWideScope } from '../utils/access';

interface AccountingHeaderProps {
  currentClient: ClientEntity;
  clients: ClientEntity[];
  onSelectClient: (client: ClientEntity) => void;
  currentUser: UserAccount;
  onSignOut: () => void;
  isBalanced: boolean;
  totalLines: number;
  totalDocs: number;
  activeSection: string;
  pendingApprovalsCount?: number;
  onOpenApprovals?: () => void;
}

export const AccountingHeader: React.FC<AccountingHeaderProps> = ({
  currentClient,
  clients,
  onSelectClient,
  currentUser,
  onSignOut,
  isBalanced,
  totalLines,
  totalDocs,
  pendingApprovalsCount = 0,
  onOpenApprovals,
}) => {
  const isOwner = currentUser.role === 'owner';
  const canSwitchEntity = hasFirmWideScope(currentUser);

  return (
    <header className="sticky top-0 z-30 border-b border-sky-200/90 bg-white/95 backdrop-blur-md px-4 py-2.5 shadow-xs text-[#0a253e]">
      <div className="flex flex-wrap items-center justify-between gap-3">
        {/* Brand */}
        <div className="flex items-center gap-2.5">
          <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-[#f5b719] font-black text-[#082f4f] text-sm shadow-[0_0_16px_-4px_rgba(245,183,25,0.7)]">
            BPZ
          </span>
          <div>
            <span className="block font-extrabold text-sm tracking-wide text-[#082f4f]">
              BPZ CONSULT
            </span>
            <span className="block text-[11px] font-bold uppercase tracking-wider text-[#855b00]">
              {currentClient.name}
            </span>
          </div>
        </div>

        {/* Right: Sync · Balance · Workspace · Sign Out */}
        <div className="flex flex-wrap items-center gap-2.5 text-xs">
          <div className="hidden sm:flex items-center gap-1.5 rounded-md border border-sky-200 bg-sky-50/70 px-2.5 py-1 text-[#2d4f6d]">
            <Wifi className="h-3 w-3 text-emerald-600 animate-pulse" />
            <span className="font-mono text-[11px] font-bold text-emerald-800">Server sync</span>
          </div>

          <div className="flex items-center gap-1.5 rounded-md border border-sky-200 bg-sky-50/70 px-2.5 py-1">
            <span className={`h-2 w-2 rounded-full ${isBalanced ? 'bg-emerald-600 pulse-dot' : 'bg-rose-600'}`} />
            <span className="font-mono text-[11px] font-bold text-[#0a253e]">
              {isBalanced ? 'Balanced' : 'Out of Balance'}
            </span>
            <span className="text-sky-300">|</span>
            <span className="font-mono text-[11px] text-[#2d4f6d]">
              {totalDocs} docs · {totalLines} lines
            </span>
          </div>

          {/* Pending Approvals Bell Alert */}
          {onOpenApprovals && (
            <button
              onClick={onOpenApprovals}
              className={`flex items-center gap-1.5 rounded-md px-2.5 py-1 text-xs font-bold transition shadow-xs ${
                pendingApprovalsCount > 0
                  ? 'border border-amber-400 bg-amber-50 text-[#855b00] hover:bg-amber-100'
                  : 'border border-sky-200 bg-white text-[#355875] hover:bg-sky-50'
              }`}
              title="Checker Approvals Queue"
            >
              <Bell className={`h-3.5 w-3.5 ${pendingApprovalsCount > 0 ? 'text-[#855b00] animate-bounce' : 'text-slate-400'}`} />
              <span>{pendingApprovalsCount > 0 ? `${pendingApprovalsCount} Approvals` : 'Approvals'}</span>
            </button>
          )}

          {canSwitchEntity ? (
            <div className="flex items-center gap-1 rounded-md border border-sky-300 bg-white px-2 py-1 shadow-xs">
              <Building2 className="h-3.5 w-3.5 text-[#855b00] shrink-0" />
              <select
                value={currentClient.id}
                onChange={(e) => {
                  const found = clients.find((c) => c.id === Number(e.target.value));
                  if (found) onSelectClient(found);
                }}
                className="bg-transparent font-bold text-[#082f4f] outline-none text-xs cursor-pointer"
              >
                {clients.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.code} · {c.name}
                  </option>
                ))}
              </select>
            </div>
          ) : (
            <div className="hidden md:flex items-center gap-1 rounded-md border border-sky-300 bg-white px-2 py-1 shadow-xs">
              <Building2 className="h-3.5 w-3.5 text-[#855b00] shrink-0" />
              <span className="font-bold text-[#082f4f] text-xs">
                {currentClient.code} · {currentClient.name}
              </span>
            </div>
          )}

          <button
            onClick={onSignOut}
            className="flex items-center gap-1.5 rounded-md bg-[#b42318] px-3 py-1.5 text-xs font-bold text-white hover:bg-rose-800 transition shadow-xs"
          >
            <span className="uppercase">{currentUser.role}</span>
            <span className="opacity-60">·</span>
            <span>Sign Out</span>
            <LogOut className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>
    </header>
  );
};
