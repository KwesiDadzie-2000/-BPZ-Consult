import type { ACDOCALine } from '../types/accounting';
import { statutoryPayableRows, type StatutoryPayableRow } from '../utils/payables';
import { Card, formatGHS, numCls, rowCls, thCls } from './ui';
import { Landmark, ArrowRight, BellRing } from 'lucide-react';

interface Props {
  lines: ACDOCALine[];
  clientId: number;
  currency: string;
  /** Expenses desk: navigate to the Payment Desk. Payment desk: open the remittance modal. */
  onAction?: (row: StatutoryPayableRow) => void;
  actionLabel?: string;
  disabled?: boolean;
  /** Hide net salaries (205000) when a dedicated payroll-release control is shown. */
  excludeSalaries?: boolean;
}

/**
 * Live statutory payable register. PAYE, SSNIT Tier 1 (13.5%) and Tier 2 (5%)
 * appear here the instant payroll is posted — balances are read from the ledger,
 * and remittance is executed only at the Payment Desk.
 */
export const StatutoryPayablesCard = ({ lines, clientId, currency, onAction, actionLabel = 'Remit at Payment Desk', disabled = false, excludeSalaries = false }: Props) => {
  const rows = statutoryPayableRows(lines, clientId).filter((r) => !excludeSalaries || r.accountNo !== '205000');
  const outstanding = rows.filter((r) => r.balance > 0.009);
  const totalDue = outstanding.reduce((s, r) => s + r.balance, 0);
  const payrollDue = outstanding.filter((r) => r.payroll && r.accountNo !== '205000').reduce((s, r) => s + r.balance, 0);

  return (
    <Card
      title="Statutory & payroll payables"
      sub={`Live ledger balances · ${outstanding.length} obligation(s) due · total ${currency} ${formatGHS(totalDue)}`}
      action={payrollDue > 0.009 ? (
        <span className="inline-flex items-center gap-1.5 rounded-full border border-amber-300 bg-amber-50 px-3 py-1 text-[11px] font-bold text-[#855b00]">
          <BellRing className="h-3.5 w-3.5" /> Payroll statutory due: {formatGHS(payrollDue)}
        </span>
      ) : undefined}
    >
      <p className="mb-3 rounded-lg border border-sky-200 bg-sky-50 p-2.5 text-[11px] leading-relaxed text-[#2d4f6d]">
        <strong className="text-[#082f4f]">PAYE, SSNIT Tier 1 (13.5%) and Tier 2 (5%) are registered as payables immediately when payroll is posted.</strong>{' '}
        Remittances and salary release are effected only at the Payment Desk (Dr liability · Cr bank/cash), with maker-checker approval above the operator limit.
      </p>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[760px] text-xs">
          <thead>
            <tr className="border-b border-sky-200 bg-sky-50/70">
              <th className={thCls}>Obligation</th>
              <th className={thCls}>GL</th>
              <th className={thCls}>Remit to</th>
              <th className={thCls}>Statutory due</th>
              <th className={thCls + ' text-right'}>Balance ({currency})</th>
              {onAction && <th className={thCls + ' text-center'}>Action</th>}
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => {
              const due = r.balance > 0.009;
              return (
                <tr key={r.accountNo} className={`${rowCls} ${due ? '' : 'opacity-55'} transition hover:bg-sky-50/60`}>
                  <td className="px-3 py-2">
                    <span className="flex items-center gap-1.5 font-bold text-[#082f4f]">
                      <Landmark className={`h-3.5 w-3.5 shrink-0 ${due ? 'text-[#855b00]' : 'text-slate-400'}`} />
                      {r.label}
                    </span>
                    <span className="block pl-5 text-[10px] text-[#355875]">{r.source}</span>
                  </td>
                  <td className="px-3 py-2 font-mono font-bold text-[#855b00]">{r.accountNo}</td>
                  <td className="px-3 py-2 text-[#2d4f6d]">{r.authority}</td>
                  <td className="px-3 py-2 text-[#2d4f6d]">{r.due}</td>
                  <td className={`${numCls} ${due ? 'font-bold text-rose-700' : 'text-[#355875]'}`}>{formatGHS(r.balance)}</td>
                  {onAction && (
                    <td className="px-3 py-2 text-center">
                      {r.accountNo === '205000' && excludeSalaries ? null : (
                        <button
                          onClick={() => onAction(r)}
                          disabled={!due || disabled}
                          className="inline-flex items-center gap-1 rounded bg-[#082f4f] px-2.5 py-1 text-[11px] font-bold text-white transition hover:bg-[#0c3f68] disabled:cursor-not-allowed disabled:opacity-30"
                        >
                          {actionLabel} <ArrowRight className="h-3 w-3" />
                        </button>
                      )}
                    </td>
                  )}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </Card>
  );
};
