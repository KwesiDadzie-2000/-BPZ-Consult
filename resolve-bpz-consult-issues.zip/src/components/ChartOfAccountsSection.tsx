import React, { useState } from 'react';
import { ClientEntity, AccountMaster, ACDOCALine } from '../types/accounting';
import { Card, PageHeader, formatGHS, thCls, numCls, rowCls } from './ui';
import { Plus, Search, FileSpreadsheet } from 'lucide-react';

interface ChartOfAccountsSectionProps {
  currentClient: ClientEntity;
  accounts: AccountMaster[];
  lines: ACDOCALine[];
  onAddAccount: (acc: AccountMaster) => void;
}

export const ChartOfAccountsSection: React.FC<ChartOfAccountsSectionProps> = ({
  currentClient,
  accounts,
  lines,
  onAddAccount,
}) => {
  const [filterType, setFilterType] = useState<string>('ALL');
  const [search, setSearch] = useState('');
  const [showModal, setShowModal] = useState(false);

  // New account form
  const [accNo, setAccNo] = useState('');
  const [accName, setAccName] = useState('');
  const [accType, setAccType] = useState<'Asset' | 'Liability' | 'Equity' | 'Income' | 'Expense'>('Asset');
  const [accCategory, setAccCategory] = useState('Current Assets');

  const clientLines = lines.filter((l) => l.clientId === currentClient.id);

  // Calculate live balances per account from Universal Journal
  const balances: Record<string, number> = {};
  clientLines.forEach((l) => {
    if (!balances[l.accountNo]) balances[l.accountNo] = 0;
    // Assets & Expenses: Dr is +, Cr is -
    // Liabilities, Equity, Income: Cr is +, Dr is -
    const isDrNormal = l.accountNo.startsWith('1') || l.accountNo.startsWith('5') || l.accountNo.startsWith('6') || l.accountNo.startsWith('7');
    if (isDrNormal) {
      balances[l.accountNo] += (l.debit - l.credit);
    } else {
      balances[l.accountNo] += (l.credit - l.debit);
    }
  });

  const filtered = accounts.filter((a) => {
    const matchType = filterType === 'ALL' || a.type === filterType;
    const matchSearch =
      a.accountNo.includes(search) ||
      a.name.toLowerCase().includes(search.toLowerCase()) ||
      a.category.toLowerCase().includes(search.toLowerCase());
    return matchType && matchSearch;
  });

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!accNo || !accName) return;
    const newAcc: AccountMaster = {
      accountNo: accNo.trim(),
      name: accName.trim(),
      type: accType,
      category: accCategory,
      active: true,
      isCustom: true,
    };
    onAddAccount(newAcc);
    setShowModal(false);
    setAccNo('');
    setAccName('');
  };

  const handleExportCsv = () => {
    let csv = `AccountNo,AccountName,Classification,Category,ActiveStatus,CurrentBalance\n`;
    accounts.forEach((a) => {
      const bal = balances[a.accountNo] || 0;
      csv += `"${a.accountNo}","${a.name}","${a.type}","${a.category}","${a.active ? 'Active' : 'Inactive'}",${bal}\n`;
    });
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${currentClient.code}_Chart_of_Accounts.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      <PageHeader
        kicker={`COA · General Ledger Master · ${currentClient.code}`}
        title="Chart of Accounts Master"
        desc="Standard IFRS chart of accounts with real-time balances from the Universal Journal. Add customized nominal accounts tailored to your legal business operations."
      >
        <div className="flex gap-2">
          <button
            onClick={handleExportCsv}
            className="flex items-center gap-1.5 rounded-lg border border-sky-300 bg-white px-3.5 py-2 text-xs font-bold text-[#082f4f] hover:bg-sky-50 transition shadow-xs"
          >
            <FileSpreadsheet className="h-4 w-4 text-emerald-700" />
            <span>Export COA (CSV)</span>
          </button>
          <button
            onClick={() => setShowModal(true)}
            className="flex items-center gap-1.5 rounded-lg bg-[#082f4f] px-3.5 py-2 text-xs font-bold text-white hover:bg-[#0c3f68] transition shadow-xs"
          >
            <Plus className="h-4 w-4" />
            <span>Add GL Account</span>
          </button>
        </div>
      </PageHeader>

      {/* Filter and Search Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 text-xs bg-white p-3 rounded-xl border border-sky-200 shadow-xs">
        <div className="flex flex-wrap items-center gap-1">
          {['ALL', 'Asset', 'Liability', 'Equity', 'Income', 'Expense'].map((t) => (
            <button
              key={t}
              onClick={() => setFilterType(t)}
              className={`px-3 py-1.5 rounded-lg font-bold transition ${
                filterType === t
                  ? 'bg-[#082f4f] text-white shadow-xs'
                  : 'bg-sky-50 text-[#355875] hover:bg-sky-100'
              }`}
            >
              {t === 'ALL' ? 'All Accounts' : t}
            </button>
          ))}
        </div>

        <div className="relative">
          <Search className="absolute left-2.5 top-2 h-3.5 w-3.5 text-sky-400" />
          <input
            type="text"
            placeholder="Search account no or name..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-56 sm:w-64 rounded-lg border border-sky-300 bg-white pl-8 pr-3 py-1.5 text-xs text-[#082f4f] outline-none focus:border-[#082f4f]"
          />
        </div>
      </div>

      {/* Accounts Master Table */}
      <Card title={`Nominal Ledger Accounts (${filtered.length} Accounts)`} sub="Mapped to financial statements and universal journals">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[760px] text-xs">
            <thead>
              <tr className="border-b border-sky-200 bg-sky-50/70">
                <th className={thCls}>Account No</th>
                <th className={thCls}>GL Account Name</th>
                <th className={thCls}>Classification</th>
                <th className={thCls}>Category Group</th>
                <th className={thCls + " text-right"}>Live Ledger Balance (₵)</th>
                <th className={thCls}>Status</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((a) => {
                const bal = balances[a.accountNo] || 0;
                return (
                  <tr key={a.accountNo} className={rowCls}>
                    <td className="px-3 py-2 font-mono font-bold text-[#855b00]">{a.accountNo}</td>
                    <td className="px-3 py-2 font-bold text-[#082f4f]">
                      {a.name}
                      {a.isCustom && (
                        <span className="ml-1.5 rounded bg-amber-100 text-[#855b00] px-1.5 py-0.2 text-[9.5px] font-mono">
                          Custom
                        </span>
                      )}
                    </td>
                    <td className="px-3 py-2">
                      <span className={`rounded px-2 py-0.5 text-[10.5px] font-bold ${
                        a.type === 'Asset' ? 'bg-sky-100 text-[#006f98]' :
                        a.type === 'Liability' ? 'bg-amber-100 text-[#855b00]' :
                        a.type === 'Equity' ? 'bg-purple-100 text-[#6d3fb3]' :
                        a.type === 'Income' ? 'bg-emerald-100 text-[#087a55]' :
                        'bg-rose-100 text-[#b42318]'
                      }`}>
                        {a.type}
                      </span>
                    </td>
                    <td className="px-3 py-2 text-[#355875]">{a.category}</td>
                    <td className={numCls + " font-mono font-bold text-[#082f4f]"}>
                      {bal !== 0 ? formatGHS(Math.abs(bal)) : '0.00'}
                      {bal < 0 && ' (Cr)'}
                    </td>
                    <td className="px-3 py-2">
                      <span className={`rounded px-2 py-0.5 text-[10.5px] font-bold ${a.active ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-600'}`}>
                        {a.active ? 'Active' : 'Inactive'}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>

      {/* New GL Account Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <form onSubmit={handleCreate} className="w-full max-w-md rounded-xl border border-sky-300 bg-white p-6 shadow-xl space-y-4 text-xs">
            <h3 className="text-base font-bold text-[#082f4f] border-b border-sky-100 pb-2">Create New GL Account</h3>
            <div className="space-y-3">
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Account Number</label>
                <input
                  type="text"
                  placeholder="e.g. 502000, 650000"
                  value={accNo}
                  onChange={(e) => setAccNo(e.target.value)}
                  className="w-full rounded border border-sky-300 px-3 py-2 outline-none font-mono font-bold text-[#082f4f]"
                  required
                />
              </div>

              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Account Title / Description</label>
                <input
                  type="text"
                  placeholder="e.g. Machinery Maintenance Expenses"
                  value={accName}
                  onChange={(e) => setAccName(e.target.value)}
                  className="w-full rounded border border-sky-300 px-3 py-2 outline-none font-bold text-[#082f4f]"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Account Type</label>
                  <select
                    value={accType}
                    onChange={(e) => {
                      const t = e.target.value as any;
                      setAccType(t);
                      if (t === 'Asset') setAccCategory('Current Assets');
                      if (t === 'Liability') setAccCategory('Current Liabilities');
                      if (t === 'Equity') setAccCategory('Capital & Reserves');
                      if (t === 'Income') setAccCategory('Revenue');
                      if (t === 'Expense') setAccCategory('Operating Expenses');
                    }}
                    className="w-full rounded border border-sky-300 px-2 py-2 outline-none font-bold text-[#082f4f]"
                  >
                    <option value="Asset">Asset</option>
                    <option value="Liability">Liability</option>
                    <option value="Equity">Equity</option>
                    <option value="Income">Income</option>
                    <option value="Expense">Expense</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Subcategory</label>
                  <input
                    type="text"
                    value={accCategory}
                    onChange={(e) => setAccCategory(e.target.value)}
                    className="w-full rounded border border-sky-300 px-3 py-2 outline-none text-[#082f4f]"
                    required
                  />
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-sky-100">
              <button type="button" onClick={() => setShowModal(false)} className="rounded px-3 py-1.5 font-semibold text-[#2d4f6d]">Cancel</button>
              <button type="submit" className="rounded bg-[#082f4f] px-4 py-1.5 font-bold text-white">Save Account</button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
