import React from 'react';
import { ClientEntity, ACDOCALine } from '../types/accounting';
import { Card, Stat, ModuleTag, PageHeader, formatGHS, thCls, numCls, rowCls } from './ui';
import { ArrowUpRight, ShoppingCart, Tag, Users, Truck, Layers, Calculator } from 'lucide-react';

interface AccountingDashboardProps {
  currentClient: ClientEntity;
  lines: ACDOCALine[];
  onNavigate: (section: string) => void;
}

export const AccountingDashboard: React.FC<AccountingDashboardProps> = ({
  currentClient,
  lines,
  onNavigate,
}) => {
  const clientLines = lines.filter((l) => l.clientId === currentClient.id);

  // Compute key accounting balances
  const totalDebits = clientLines.reduce((s, l) => s + l.debit, 0);
  const totalCredits = clientLines.reduce((s, l) => s + l.credit, 0);
  const isBalanced = Math.abs(totalDebits - totalCredits) < 0.01;

  const cashBank = clientLines
    .filter((l) => l.accountNo.startsWith('10'))
    .reduce((s, l) => s + l.debit - l.credit, 0);

  // Bank accounts (100000/101000) are reported separately from cash on hand
  // (102000 petty cash safe, 103000 office till, 104000 mobile money clearing).
  const bankBalance = clientLines
    .filter((l) => l.accountNo === '100000' || l.accountNo === '101000')
    .reduce((s, l) => s + l.debit - l.credit, 0);
  const cashOnHand = clientLines
    .filter((l) => l.accountNo === '102000' || l.accountNo === '103000' || l.accountNo === '104000')
    .reduce((s, l) => s + l.debit - l.credit, 0);

  const receivables = clientLines
    .filter((l) => l.accountNo === '110000')
    .reduce((s, l) => s + l.debit - l.credit, 0);

  const payables = clientLines
    .filter((l) => l.accountNo === '200000' || l.accountNo === '201000')
    .reduce((s, l) => s + l.credit - l.debit, 0);

  const revenue = clientLines
    .filter((l) => l.accountNo.startsWith('4'))
    .reduce((s, l) => s + l.credit - l.debit, 0);

  const expenses = clientLines
    .filter((l) => l.accountNo.startsWith('5') || l.accountNo.startsWith('6') || l.accountNo.startsWith('7'))
    .reduce((s, l) => s + l.debit - l.credit, 0);

  const netIncome = revenue - expenses;

  return (
    <div className="space-y-6">
      <PageHeader
        kicker={`Command Center · ${currentClient.code}`}
        title={currentClient.name}
        desc={`Balances from ${currentClient.code}'s own posted journal — this workspace shows only this entity's information.`}
      >
        <div className="flex gap-2">
          <button
            onClick={() => onNavigate('manual_journal')}
            className="rounded-lg bg-[#082f4f] px-3.5 py-2 text-xs font-bold text-white hover:bg-[#0c3f68] transition shadow-xs"
          >
            Post Journal Entry
          </button>
          <button
            onClick={() => onNavigate('financial_reports')}
            className="rounded-lg border border-sky-300 bg-white px-3.5 py-2 text-xs font-bold text-[#082f4f] hover:bg-sky-50 transition"
          >
            Financial Reports
          </button>
        </div>
      </PageHeader>

      {/* Key Financial Indicators */}
      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        <Stat label="Cash & Bank" value={`₵${formatGHS(cashBank)}`} sub={`Bank ₵${formatGHS(bankBalance)} · Cash on hand ₵${formatGHS(cashOnHand)}`} />
        <Stat label="Accounts Receivable" value={`₵${formatGHS(receivables)}`} sub="Customer open balances" />
        <Stat label="Accounts Payable" value={`₵${formatGHS(payables)}`} sub="Supplier open balances" />
        <Stat label="Revenue (all journal periods)" value={`₵${formatGHS(revenue)}`} tone="text-emerald-700" sub="All sales & contract income" />
        <Stat label="Operating Expenses" value={`₵${formatGHS(expenses)}`} tone="text-rose-700" sub="All expense accounts" />
        <Stat label="Net Income" value={`₵${formatGHS(netIncome)}`} tone="text-emerald-700" sub="Revenue − expenses" />
        <Stat label="VAT Ledger Position" value={`₵${formatGHS(clientLines.filter(l => l.accountNo === '220000' || l.accountNo === '125000').reduce((n, l) => n + l.credit - l.debit, 0))}`} tone="text-[#006f98]" sub="Unverified account position" />
        <Stat label="Universal Journal" value={isBalanced ? "Balanced (0.00)" : "Out of Balance"} tone={isBalanced ? "text-emerald-700" : "text-rose-700"} sub={`${clientLines.length} active journal lines`} />
      </div>

      {/* Operations Quick Launchers & Sector Focus */}
      <div className="grid gap-4 xl:grid-cols-2">
        <Card title="Operational Accounting Desks" sub="Live posting cycles feeding the Universal Journal">
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={() => onNavigate('procurement')}
              className="flex items-start gap-3 rounded-lg border border-sky-200 bg-sky-50/50 p-3 text-left hover:bg-sky-100/60 transition"
            >
              <div className="rounded-md bg-[#006f98] p-2 text-white">
                <ShoppingCart className="h-4 w-4" />
              </div>
              <div>
                <div className="text-xs font-bold text-[#082f4f]">Procurement (MM)</div>
                <div className="text-[11px] text-[#2d4f6d]">PO, goods receipt, 20% input VAT</div>
              </div>
            </button>

            <button
              onClick={() => onNavigate('sales')}
              className="flex items-start gap-3 rounded-lg border border-sky-200 bg-sky-50/50 p-3 text-left hover:bg-sky-100/60 transition"
            >
              <div className="rounded-md bg-[#087a55] p-2 text-white">
                <Tag className="h-4 w-4" />
              </div>
              <div>
                <div className="text-xs font-bold text-[#082f4f]">Sales & Invoicing (SD)</div>
                <div className="text-[11px] text-[#2d4f6d]">IFRS 15 billing, output VAT</div>
              </div>
            </button>

            <button
              onClick={() => onNavigate('payroll')}
              className="flex items-start gap-3 rounded-lg border border-sky-200 bg-sky-50/50 p-3 text-left hover:bg-sky-100/60 transition"
            >
              <div className="rounded-md bg-[#6d3fb3] p-2 text-white">
                <Users className="h-4 w-4" />
              </div>
              <div>
                <div className="text-xs font-bold text-[#082f4f]">Payroll Desk (HR)</div>
                <div className="text-[11px] text-[#2d4f6d]">PAYE bands, SSNIT Tier 1 &amp; 2</div>
              </div>
            </button>

            <button
              onClick={() => onNavigate('assets')}
              className="flex items-start gap-3 rounded-lg border border-sky-200 bg-sky-50/50 p-3 text-left hover:bg-sky-100/60 transition"
            >
              <div className="rounded-md bg-[#8a5d00] p-2 text-white">
                <Truck className="h-4 w-4" />
              </div>
              <div>
                <div className="text-xs font-bold text-[#082f4f]">Fixed Assets (AA)</div>
                <div className="text-[11px] text-[#2d4f6d]">IAS 16 schedule &amp; depreciation</div>
              </div>
            </button>

            <button
              onClick={() => onNavigate('standards_desk')}
              className="flex items-start gap-3 rounded-lg border border-sky-200 bg-sky-50/50 p-3 text-left hover:bg-sky-100/60 transition"
            >
              <div className="rounded-md bg-[#006f98] p-2 text-white">
                <Layers className="h-4 w-4" />
              </div>
              <div>
                <div className="text-xs font-bold text-[#082f4f]">IFRS / IAS Standards Desk</div>
                <div className="text-[11px] text-[#2d4f6d]">Contracts (IFRS 15), Leases (IFRS 16), Impairments</div>
              </div>
            </button>

            <button
              onClick={() => onNavigate('loans_desk')}
              className="flex items-start gap-3 rounded-lg border border-sky-200 bg-sky-50/50 p-3 text-left hover:bg-sky-100/60 transition"
            >
              <div className="rounded-md bg-[#855b00] p-2 text-white">
                <Calculator className="h-4 w-4" />
              </div>
              <div>
                <div className="text-xs font-bold text-[#082f4f]">Loan Amortisation Desk</div>
                <div className="text-[11px] text-[#2d4f6d]">Borrowings, annuity debt schedules &amp; interest</div>
              </div>
            </button>
          </div>
        </Card>

        <Card title={`Sector Profile — ${currentClient.sector}`} sub="Statutory & tax framework">
          <div className="space-y-2.5 text-xs leading-relaxed text-[#2d4f6d]">
            <ul className="space-y-1.5 pl-4 list-disc text-[11.5px]">
              <li>CIT 25% (mining 35% under Act 729).</li>
              <li>VAT Act 2025 (Act 1151): 15% VAT + 2.5% NHIL + 2.5% GETFund on one base — full input credit, no cascading.</li>
              <li>WHT auto-tracked at Payment Desk.</li>
            </ul>
          </div>
        </Card>
      </div>

      {/* Recent Universal Journal Activity */}
      <Card
        title="Recent Journal Activity (ACDOCA)"
        sub="Latest ledger postings in this workspace"
        action={
          <button
            onClick={() => onNavigate('universal_journal')}
            className="flex items-center gap-1 text-xs font-bold text-[#006f98] hover:underline"
          >
            <span>Open Universal Journal</span>
            <ArrowUpRight className="h-3.5 w-3.5" />
          </button>
        }
      >
        <div className="overflow-x-auto">
          <table className="w-full min-w-[700px] text-xs">
            <thead>
              <tr className="border-b border-sky-200 bg-sky-50/60">
                <th className={thCls}>Doc No</th>
                <th className={thCls}>Period</th>
                <th className={thCls}>Module</th>
                <th className={thCls}>Account</th>
                <th className={thCls}>Description</th>
                <th className={thCls + " text-right"}>Debit (₵)</th>
                <th className={thCls + " text-right"}>Credit (₵)</th>
              </tr>
            </thead>
            <tbody>
              {clientLines.slice(0, 7).map((line) => (
                <tr key={line.id} className={rowCls}>
                  <td className="px-3 py-2 font-mono font-bold text-[#855b00]">{line.docNo}</td>
                  <td className="px-3 py-2 font-mono text-[#2d4f6d]">{line.period}</td>
                  <td className="px-3 py-2"><ModuleTag m={line.module} /></td>
                  <td className="px-3 py-2">
                    <span className="font-mono font-bold text-[#0a253e]">{line.accountNo}</span>
                    <div className="text-[11px] text-[#355875] truncate max-w-[140px]">{line.accountName}</div>
                  </td>
                  <td className="px-3 py-2 text-[#2d4f6d] truncate max-w-[200px]">{line.description}</td>
                  <td className={numCls + " font-bold text-[#8a5d00]"}>
                    {line.debit > 0 ? formatGHS(line.debit) : '—'}
                  </td>
                  <td className={numCls + " font-bold text-[#087a55]"}>
                    {line.credit > 0 ? formatGHS(line.credit) : '—'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
};
