import React, { useState } from 'react';
import { ClientEntity, AccountMaster, ACDOCALine, UserAccount } from '../types/accounting';
import { SEED_OPENING_ENTRIES } from '../data/accountingSeed';
import { Card, PageHeader, formatGHS, thCls, rowCls } from './ui';
import { CheckCircle, Save, Lock, AlertTriangle } from 'lucide-react';
import { uniqueId } from '../utils/ids';

const OPENING_DRAFT_KEY = (clientId: number) => `bpz_opening_draft_${clientId}`;

/**
 * Each entity owns its own opening trial balance — never pooled. Resolution order:
 * 1. Opening lines already posted to this entity's journal (source of truth, locked).
 * 2. This entity's unposted draft schedule.
 * 3. The seeded per-entity opening defaults.
 */
/** Strictly this entity's opening cut-over document — never another entity's. */
const openingLinesFor = (clientId: number, lines: ACDOCALine[]) =>
  lines.filter((l) => l.clientId === clientId && l.docNo.startsWith('DOC-OPEN-BAL'));

const loadOpeningEntries = (clientId: number, lines: ACDOCALine[]): Record<string, { dr: number; cr: number }> => {
  const posted = openingLinesFor(clientId, lines);
  if (posted.length) {
    const entries: Record<string, { dr: number; cr: number }> = {};
    for (const l of posted) {
      const prev = entries[l.accountNo] || { dr: 0, cr: 0 };
      entries[l.accountNo] = { dr: prev.dr + l.debit, cr: prev.cr + l.credit };
    }
    return entries;
  }
  try {
    const raw = localStorage.getItem(OPENING_DRAFT_KEY(clientId));
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed === 'object') return parsed;
    }
  } catch { /* ignore corrupt draft */ }
  return SEED_OPENING_ENTRIES[clientId] || {};
};

interface OpeningBalanceSectionProps {
  currentClient: ClientEntity;
  currentUser: UserAccount;
  accounts: AccountMaster[];
  lines: ACDOCALine[];
  /** Fiscal periods already closed (frozen) for this entity. */
  closedPeriods?: string[];
  onAddJournalLines: (newLines: ACDOCALine[]) => boolean;
  onClearOpeningBalance?: () => void;
}

export const OpeningBalanceSection: React.FC<OpeningBalanceSectionProps> = ({
  currentClient,
  currentUser,
  accounts,
  lines,
  closedPeriods = [],
  onAddJournalLines,
}) => {
  const [cutOverDate, setCutOverDate] = useState('2026-01-01');
  // Per-entity opening schedule: loaded from this entity's posted lines, its draft,
  // or its seeded defaults. Cash and bank are separate GL accounts, so their opening
  // balances are captured as separate entries: bank operating account vs cash on hand.
  const [openingEntries, setOpeningEntries] = useState<Record<string, { dr: number; cr: number }>>(
    () => loadOpeningEntries(currentClient.id, lines)
  );

  const persistDraft = (entries: Record<string, { dr: number; cr: number }>) => {
    try { localStorage.setItem(OPENING_DRAFT_KEY(currentClient.id), JSON.stringify(entries)); } catch { /* ignore */ }
  };

  const [postSuccess, setPostSuccess] = useState<string | null>(null);
  const [postError, setPostError] = useState<string | null>(null);

  // Check if opening balance already posted for this entity
  const existingOpeningLines = openingLinesFor(currentClient.id, lines);
  const alreadyPosted = existingOpeningLines.length > 0;

  // Calculate total Dr & Cr
  let totalDr = 0;
  let totalCr = 0;
  Object.values(openingEntries).forEach((v) => {
    totalDr += v.dr || 0;
    totalCr += v.cr || 0;
  });

  const difference = totalDr - totalCr;
  const isBalanced = Math.abs(difference) < 0.01 && (totalDr > 0);

  const period = cutOverDate.slice(0, 7);
  const periodFrozen = closedPeriods.includes(period);

  const handleDrChange = (accNo: string, val: number) => {
    if (alreadyPosted) return;
    const next = {
      ...openingEntries,
      [accNo]: { ...openingEntries[accNo], dr: val, cr: 0 },
    };
    setOpeningEntries(next);
    persistDraft(next);
  };

  const handleCrChange = (accNo: string, val: number) => {
    if (alreadyPosted) return;
    const next = {
      ...openingEntries,
      [accNo]: { ...openingEntries[accNo], cr: val, dr: 0 },
    };
    setOpeningEntries(next);
    persistDraft(next);
  };

  const handlePostOpeningBalances = () => {
    if (alreadyPosted || !isBalanced) return;

    // Diagnostic-first: name the exact statutory blocker before attempting.
    if (periodFrozen) {
      setPostError(
        `Opening balances for ${currentClient.code} were not posted: the period ${period} is closed (frozen) for this entity. Open the period in Month-End Close, or set the cut-over date to an open period, then post again.`
      );
      return;
    }

    const docNo = `DOC-OPEN-BAL-${currentClient.code}`;

    const generatedLines: ACDOCALine[] = [];

    Object.entries(openingEntries).forEach(([accNo, val], idx) => {
      if (val.dr > 0 || val.cr > 0) {
        const accMeta = accounts.find((a) => a.accountNo === accNo);
        generatedLines.push({
          id: `${uniqueId('JL-OPEN')}-${idx}`,
          docNo,
          period,
          date: cutOverDate,
          module: 'FI',
          docType: 'JE',
          accountNo: accNo,
          accountName: accMeta?.name || 'Nominal Ledger Account',
          costCenter: 'CC-ADM',
          debit: val.dr,
          credit: val.cr,
          currency: currentClient.currency,
          description: `Opening cut-over balance as of ${cutOverDate}`,
          createdBy: currentUser.username,
          checkedBy: currentUser.canCheck ? currentUser.username : undefined,
          clientId: currentClient.id,
        });
      }
    });

    const posted = onAddJournalLines(generatedLines);
    if (!posted) {
      const reason = lines.some((l) => l.clientId === currentClient.id && l.docNo.startsWith('DOC-OPEN-BAL'))
        ? `document ${docNo} is already in the Universal Journal for this entity`
        : periodFrozen
          ? `the period ${period} is frozen`
          : 'the debits and credits do not agree (Dr = Cr is required)';
      setPostError(`Opening balances for ${currentClient.code} were not posted: ${reason}.`);
      setTimeout(() => setPostError(null), 8000);
      return;
    }
    // Posted lines become this entity's source of truth — clear the draft schedule.
    try { localStorage.removeItem(OPENING_DRAFT_KEY(currentClient.id)); } catch { /* ignore */ }
    setPostSuccess(`Opening trial balance successfully posted to ACDOCA! Total debits & credits: ₵${formatGHS(totalDr)}.`);
    setTimeout(() => setPostSuccess(null), 5000);
  };

  return (
    <div className="space-y-6">
      <PageHeader
        kicker={`SETUP · ONBOARDING WIZARD · ${currentClient.code}`}
        title="Opening Trial Balance Setup"
        desc={`Migrate and initialize real cut-over balances for ${currentClient.name}. Each entity owns its own opening trial balance — schedules are captured, stored and posted per entity, never pooled. The system verifies Dr = Cr equality before posting to the Universal Journal.`}
      />

      <div className="rounded-xl border border-sky-200 bg-white p-3 text-[11.5px] font-semibold text-[#2d4f6d] shadow-xs">
        Entity in scope: <strong className="font-mono text-[#082f4f]">{currentClient.code}</strong> · {currentClient.name} ·
        functional currency <strong className="font-mono">{currentClient.currency}</strong>. This schedule, its draft and its
        posted cut-over document belong to this entity alone — no other client&rsquo;s opening balances are read, shown or written here.
        {!alreadyPosted && (
          <button
            onClick={() => {
              const seeded = SEED_OPENING_ENTRIES[currentClient.id] || {};
              setOpeningEntries(seeded);
              persistDraft(seeded);
            }}
            className="ml-2 rounded border border-sky-300 bg-sky-50 px-2 py-0.5 text-[10.5px] font-bold text-[#082f4f] hover:bg-sky-100"
          >
            Reset this entity&rsquo;s schedule
          </button>
        )}
      </div>

      {postSuccess && (
        <div className="rounded-xl border border-emerald-300 bg-emerald-50 p-4 text-xs font-bold text-emerald-900 flex items-center gap-2 shadow-xs">
          <CheckCircle className="h-4 w-4 text-emerald-700 shrink-0" />
          <span>{postSuccess}</span>
        </div>
      )}

      {postError && (
        <div role="alert" className="rounded-xl border border-rose-300 bg-rose-50 p-4 text-xs font-bold text-rose-900 shadow-xs flex items-start gap-2">
          <AlertTriangle className="h-4 w-4 text-rose-700 shrink-0 mt-0.5" />
          <span>{postError}</span>
        </div>
      )}

      {alreadyPosted && (
        <div className="rounded-xl border border-sky-300 bg-sky-50 p-4 text-xs text-[#082f4f] flex items-center justify-between shadow-xs">
          <div>
            <strong>Opening Balances Already Posted:</strong> {existingOpeningLines.length} journal lines are active in
            this entity&rsquo;s Universal Journal. The posted schedule below is locked and remains the source of truth —
            to correct it, post an adjusting journal entry instead.
          </div>
          <span className="flex items-center gap-1.5 font-mono font-bold text-emerald-800 bg-emerald-100 border border-emerald-300 px-2.5 py-1 rounded">
            <Lock className="h-3 w-3" />
            Verified In Books
          </span>
        </div>
      )}

      {/* Control Summary Strip */}
      <div className="rounded-xl border border-sky-200 bg-white p-4 shadow-xs flex flex-wrap items-center justify-between gap-4 text-xs">
        <div className="flex items-center gap-3">
          <div>
            <label className="block text-[11px] font-bold text-[#355875] mb-1">Financial Cut-Over Date</label>
            <input
              type="date"
              value={cutOverDate}
              onChange={(e) => setCutOverDate(e.target.value)}
              disabled={alreadyPosted}
              className="rounded border border-sky-300 px-3 py-1.5 font-bold text-[#082f4f] outline-none disabled:opacity-50"
            />
          </div>
          {periodFrozen && !alreadyPosted && (
            <span className="flex items-center gap-1.5 rounded-md bg-rose-50 border border-rose-300 px-2.5 py-1.5 text-[10.5px] font-bold text-rose-800">
              <AlertTriangle className="h-3.5 w-3.5" />
              Period {period} is closed — change the date or reopen it in Month-End Close
            </span>
          )}
        </div>

        <div className="flex items-center gap-6 font-mono text-xs">
          <div>
            <span className="text-[#355875] block text-[10px]">Total Debits:</span>
            <strong className="text-emerald-800 font-black text-sm">₵{formatGHS(totalDr)}</strong>
          </div>
          <div>
            <span className="text-[#355875] block text-[10px]">Total Credits:</span>
            <strong className="text-sky-800 font-black text-sm">₵{formatGHS(totalCr)}</strong>
          </div>
          <div>
            <span className="text-[#355875] block text-[10px]">Difference:</span>
            <strong className={`font-black text-sm ${isBalanced ? 'text-emerald-700' : 'text-rose-700'}`}>
              ₵{formatGHS(Math.abs(difference))}
            </strong>
          </div>
          {alreadyPosted ? (
            <span className="flex items-center gap-1.5 rounded-lg bg-emerald-100 border border-emerald-300 px-4 py-2 text-xs font-bold text-emerald-800">
              <CheckCircle className="h-4 w-4" />
              <span>In Books (locked)</span>
            </span>
          ) : (
            <button
              onClick={handlePostOpeningBalances}
              disabled={!isBalanced || periodFrozen}
              className={`flex items-center gap-1.5 rounded-lg px-4 py-2 text-xs font-bold transition shadow-xs ${
                isBalanced && !periodFrozen
                  ? 'bg-[#082f4f] text-white hover:bg-[#0c3f68]'
                  : 'bg-slate-300 text-slate-500 cursor-not-allowed'
              }`}
              title={!isBalanced ? 'Debits and credits must agree (Dr = Cr)' : periodFrozen ? 'Period is closed for this entity' : 'Post the opening trial balance'}
            >
              <Save className="h-4 w-4" />
              <span>Post Opening Balances</span>
            </button>
          )}
        </div>
      </div>

      {/* Opening Balances Entry Table */}
      <Card
        title="Opening Balance Sheet Schedule"
        sub={alreadyPosted ? 'Posted cut-over balances (read-only) — correct via adjusting journal entries' : 'Enter balance sheet figures as at financial cut-over date'}
      >
        <div className="overflow-x-auto">
          <table className="w-full min-w-[760px] text-xs">
            <thead>
              <tr className="border-b border-sky-200 bg-sky-50/70">
                <th className={thCls}>Account No</th>
                <th className={thCls}>GL Description</th>
                <th className={thCls}>Classification</th>
                <th className={thCls + " text-right"}>Debit (Dr) ₵</th>
                <th className={thCls + " text-right"}>Credit (Cr) ₵</th>
              </tr>
            </thead>
            <tbody>
              {accounts.filter((a) => a.type === 'Asset' || a.type === 'Liability' || a.type === 'Equity').map((acc) => {
                const entry = openingEntries[acc.accountNo] || { dr: 0, cr: 0 };
                return (
                  <tr key={acc.accountNo} className={rowCls}>
                    <td className="px-3 py-2 font-mono font-bold text-[#855b00]">{acc.accountNo}</td>
                    <td className="px-3 py-2 font-bold text-[#082f4f]">{acc.name}</td>
                    <td className="px-3 py-2 text-[#355875]">{acc.type}</td>
                    <td className="px-3 py-1 text-right">
                      <input
                        type="number"
                        step="0.01"
                        placeholder="0.00"
                        value={entry.dr || ''}
                        onChange={(e) => handleDrChange(acc.accountNo, Number(e.target.value))}
                        disabled={alreadyPosted}
                        className="w-36 text-right rounded border border-sky-200 bg-white px-2 py-1 font-mono text-xs font-bold text-[#082f4f] outline-none focus:border-[#082f4f] disabled:bg-slate-50 disabled:text-slate-500"
                      />
                    </td>
                    <td className="px-3 py-1 text-right">
                      <input
                        type="number"
                        step="0.01"
                        placeholder="0.00"
                        value={entry.cr || ''}
                        onChange={(e) => handleCrChange(acc.accountNo, Number(e.target.value))}
                        disabled={alreadyPosted}
                        className="w-36 text-right rounded border border-sky-200 bg-white px-2 py-1 font-mono text-xs font-bold text-[#082f4f] outline-none focus:border-[#082f4f] disabled:bg-slate-50 disabled:text-slate-500"
                      />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
};
