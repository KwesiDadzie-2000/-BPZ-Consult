import { useEffect, useState } from 'react';
import type { UserAccount } from '../types/accounting';
import { apiFetch, clearSessionStore, getCachedSessionUser, getSessionToken, setSession } from '../utils/session';
import { Lock, User, ShieldAlert } from 'lucide-react';

const MAX_FAILED_ATTEMPTS = 5;

interface LoginScreenProps {
  onLogin: (user: UserAccount) => void;
  /** Explains why the user was returned to sign-in (e.g. an expired session). */
  notice?: string | null;
}

const ATTEMPTS_KEY = 'bpz_failed_logins_v1';

export const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin, notice }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [failedAttempts, setFailedAttempts] = useState<number>(() => {
    try { return Number(sessionStorage.getItem(ATTEMPTS_KEY) || '0') || 0; } catch { return 0; }
  });

  // If a valid, unexpired session exists, resume it on mount.
  useEffect(() => {
    // Resume a valid server session on mount.
    const token = getSessionToken();
    if (token) {
      apiFetch('/api/auth/session')
        .then((r) => (r.ok ? r.json() : null))
        .then((b) => {
          if (b?.ok && b.user) onLogin(b.user);
          else clearSessionStore();
        })
        .catch(() => {});
    }
  }, [onLogin]);

  const recordFailure = () => {
    const next = failedAttempts + 1;
    setFailedAttempts(next);
    try { sessionStorage.setItem(ATTEMPTS_KEY, String(next)); } catch { /* ignore */ }
    if (next >= MAX_FAILED_ATTEMPTS) {
      const until = Date.now() + 5 * 60 * 1000;
      try { sessionStorage.setItem('bpz_login_lockout_until', String(until)); } catch { /* ignore */ }
    }
  };

  const isLockedOut = () => {
    try {
      const until = Number(sessionStorage.getItem('bpz_login_lockout_until') || '0');
      return until > Date.now();
    } catch { return false; }
  };

  const tryLogin = async (uInput: string, pInput: string) => {
    if (isLockedOut()) {
      setError('Too many failed attempts. Wait 5 minutes before trying again.');
      return;
    }
    setError(null);
    try {
      const res = await apiFetch('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ usernameOrEmail: uInput.trim(), password: pInput }),
      });
      const body = await res.json().catch(() => null);
      if (!res.ok || !body?.ok) {
        // Only a genuine credential rejection counts toward the lockout. Server
        // or database errors (5xx/503) previously counted too, so an outage
        // locked correct passwords out for 5 minutes.
        if (res.status === 401) recordFailure();
        setError(
          body?.error ||
            (res.status >= 500
              ? 'The sign-in service is temporarily unavailable. Please try again in a moment.'
              : 'Invalid username, email, or password.')
        );
        return;
      }
      const found = body.user as UserAccount;
      try { sessionStorage.setItem(ATTEMPTS_KEY, '0'); sessionStorage.removeItem('bpz_login_lockout_until'); } catch { /* ignore */ }
      setFailedAttempts(0);
      setSession(body.token, found);
      onLogin(found);
    } catch {
      setError('Could not reach the sign-in service. Try again.');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    void tryLogin(username, password);
  };

  return (
    <div className="min-h-screen bg-[#f0f6fc] flex items-center justify-center p-4">
      <div className="w-full max-w-sm">
        <div className="flex flex-col items-center mb-6">
          <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-[#f5b719] font-black text-[#082f4f] text-lg shadow-md">
            BPZ
          </span>
          <h1 className="mt-3 text-xl font-black text-[#082f4f]">BPZ Consult</h1>
          <p className="text-xs text-[#355875] font-semibold mt-0.5">Sign in to your workspace</p>
        </div>

        <div className="rounded-2xl border border-sky-200 bg-white p-6 shadow-sm space-y-4">
          <div className="rounded-lg border border-amber-300 bg-amber-50 px-3 py-2 text-[11px] font-bold text-amber-900 flex items-start gap-2">
            <ShieldAlert className="h-4 w-4 mt-0.5 text-amber-700 shrink-0" />
            <span>Secure sign-in: credentials are verified on the server (scrypt-hashed, per-user salt). Enable MFA before client rollout.</span>
          </div>

          {notice && !error && (
            <div className="rounded-lg border border-sky-300 bg-sky-50 px-3 py-2 text-[11px] font-bold text-[#0a4a6e]">{notice}</div>
          )}

          {error && (
            <div className="rounded-lg border border-rose-300 bg-rose-50 px-3 py-2 text-xs font-bold text-rose-800">{error}</div>
          )}

          <form onSubmit={handleSubmit} className="space-y-3">
            <div>
              <label className="block text-[11px] font-bold text-[#355875] uppercase tracking-wider mb-1">Username or email</label>
              <div className="relative">
                <User className="absolute left-2.5 top-2 h-4 w-4 text-sky-400" />
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Username or email"
                  className="w-full rounded-lg border border-sky-300 bg-white pl-8 pr-3 py-2 text-sm font-semibold text-[#082f4f] outline-none focus:border-[#082f4f]"
                  required
                  autoComplete="username"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-[#355875] uppercase tracking-wider mb-1">Password</label>
              <div className="relative">
                <Lock className="absolute left-2.5 top-2 h-4 w-4 text-sky-400" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter passcode"
                  className="w-full rounded-lg border border-sky-300 bg-white pl-8 pr-3 py-2 text-sm font-semibold text-[#082f4f] outline-none focus:border-[#082f4f]"
                  required
                  autoComplete="current-password"
                />
              </div>
            </div>

            <button type="submit" className="w-full rounded-lg bg-[#082f4f] py-2.5 text-sm font-bold text-white hover:bg-[#0c3f68] transition">
              Sign In
            </button>
          </form>

          <p className="text-[10.5px] text-[#355875] text-center">
            Sessions stay active for 8 hours and renew automatically while you work. After 5 failed attempts, login is locked for 5 minutes.
          </p>
        </div>
      </div>
    </div>
  );
};

export const clearSession = () => {
  // Revoke the server session, then clear the local store.
  apiFetch('/api/auth/logout', { method: 'POST' }).catch(() => {});
  clearSessionStore();
};
