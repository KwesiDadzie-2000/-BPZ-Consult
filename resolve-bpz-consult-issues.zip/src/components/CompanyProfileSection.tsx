import React, { useState } from 'react';
import { ClientEntity } from '../types/accounting';
import { CompanyProfile, persistentStorage } from '../utils/persistentStorage';
import { Card, PageHeader } from './ui';
import { Download, Upload, Check, FileSpreadsheet, Save } from 'lucide-react';

interface CompanyProfileSectionProps {
  currentClient: ClientEntity;
  isOwner: boolean;
  clients: ClientEntity[];
  onUpdateClientName: (newName: string) => void;
  onRefreshAllData: () => void;
}

const FISCAL_YEAR_MONTHS = [
  { value: 'January', label: 'January (Calendar Year)' },
  { value: 'April', label: 'April (UK/Tax standard)' },
  { value: 'July', label: 'July (Mid-year)' },
  { value: 'October', label: 'October (US Federal)' },
];

export const CompanyProfileSection: React.FC<CompanyProfileSectionProps> = ({
  currentClient,
  isOwner,
  clients,
  onUpdateClientName,
  onRefreshAllData,
}) => {
  const allProfiles = persistentStorage.getCompanyProfiles();

  // Default profile is built once (lazy initializer) — never re-rolled on re-renders.
  const [profile, setProfile] = useState<CompanyProfile>(() => allProfiles[currentClient.id] || {
    clientId: currentClient.id,
    legalName: currentClient.name,
    tradingName: currentClient.name,
    tin: 'P00' + Math.floor(1000000 + Math.random() * 9000000),
    vatRegNo: 'VAT-GH-' + Math.floor(100000 + Math.random() * 900000),
    address: 'Commercial District, Accra, Ghana',
    phone: '+233 30 200 0000',
    email: 'finance@' + currentClient.code.toLowerCase() + '.com',
    website: 'www.' + currentClient.code.toLowerCase() + '.com',
    fiscalYearStart: 'January',
    bankPaymentDetails: 'Ecobank Ghana · Operating A/C: 144100298102',
  });
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [backupMsg, setBackupMsg] = useState<string | null>(null);
  const [restoreError, setRestoreError] = useState<string | null>(null);
  const [groupFyMonth, setGroupFyMonth] = useState('January');
  const [groupFyMsg, setGroupFyMsg] = useState<string | null>(null);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isOwner) return;
    const updated = { ...allProfiles, [currentClient.id]: profile };
    persistentStorage.saveCompanyProfiles(updated);
    onUpdateClientName(profile.legalName);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  // Owner control: set the fiscal year start for ALL entities in one action.
  const handleApplyFiscalYearToAll = () => {
    const updated = persistentStorage.setFiscalYearStartForAll(groupFyMonth, clients.map((c) => c.id));
    if (updated[currentClient.id]) setProfile(updated[currentClient.id]);
    setGroupFyMsg(`Fiscal year start set to ${groupFyMonth} for all ${clients.length} entities. Each entity's reports now measure from its own fiscal year start.`);
    setTimeout(() => setGroupFyMsg(null), 6000);
  };

  // Download complete books backup
  const handleDownloadBackup = () => {
    const jsonStr = persistentStorage.exportFullBackup();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${currentClient.code}_Real_Books_Backup_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setBackupMsg(`Complete backup file downloaded (${currentClient.code}).`);
    setTimeout(() => setBackupMsg(null), 4000);
  };

  // Restore backup
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const ok = persistentStorage.restoreFullBackup(text);
        if (ok) {
          setBackupMsg('Books successfully restored from backup file!');
          onRefreshAllData();
          setTimeout(() => setBackupMsg(null), 5000);
        } else {
          setRestoreError('Invalid backup file format.');
        }
      } catch (err) {
        setRestoreError('Failed to parse JSON backup file.');
      }
    };
    reader.readAsText(file);
  };

  // Export Universal Journal to CSV / Excel
  const handleExportJournalCsv = () => {
    const lines = persistentStorage.getJournalLines().filter((l) => l.clientId === currentClient.id);
    let csv = `DocNo,Date,Period,Module,DocType,AccountNo,AccountName,Debit,Credit,Currency,Description,Maker,Checker\n`;
    lines.forEach((l) => {
      csv += `"${l.docNo}","${l.date}","${l.period}","${l.module}","${l.docType}","${l.accountNo}","${l.accountName}",${l.debit},${l.credit},"${l.currency}","${(l.description || '').replace(/"/g, '""')}","${l.createdBy}","${l.checkedBy || ''}"\n`;
    });
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${currentClient.code}_General_Ledger_ACDOCA.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div className="space-y-6">
      <PageHeader
        kicker={`COMPANY SETUP & DATA MANAGEMENT · ${currentClient.code}`}
        title="Company Profile & Real Books Management"
        desc="Configure your legal entity details, tax identification numbers (TIN/VAT), bank payment details for customer invoices, and manage secure data backups."
      />

      {saveSuccess && (
        <div className="rounded-lg border border-emerald-300 bg-emerald-50 p-3 text-xs font-bold text-emerald-900 flex items-center gap-2">
          <Check className="h-4 w-4 text-emerald-700 shrink-0" />
          <span>Company profile saved! All generated tax invoices and reports will use these legal details.</span>
        </div>
      )}

      {backupMsg && (
        <div className="rounded-lg border border-sky-300 bg-sky-50 p-3 text-xs font-bold text-[#082f4f] flex items-center gap-2">
          <Check className="h-4 w-4 text-[#006f98] shrink-0" />
          <span>{backupMsg}</span>
        </div>
      )}

      {restoreError && (
        <div className="rounded-lg border border-rose-300 bg-rose-50 p-3 text-xs font-bold text-rose-800">
          {restoreError}
        </div>
      )}

      {/* Main Grid */}
      <div className="grid gap-6 lg:grid-cols-12">
        {/* Left: Company Legal & Tax Details */}
        <div className="lg:col-span-8">
          <Card title="Legal Company Profile & Statutory Tax Identifiers" sub={isOwner ? "Used on all official tax invoices and financial statements" : "Read-only for non-owner users — the Firm Owner controls legal entity details"}>
            {!isOwner && (
              <div className="mb-3 rounded-lg border border-amber-300 bg-amber-50 p-2.5 text-[11px] font-bold text-amber-900">
                Only the Firm Owner can edit legal entity details, tax identifiers and bank settlement instructions.
              </div>
            )}
            <form onSubmit={handleSaveProfile} className="space-y-4 text-xs">
              <fieldset disabled={!isOwner} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-[#082f4f] mb-1">Legal Entity Registered Name</label>
                  <input
                    type="text"
                    value={profile.legalName}
                    onChange={(e) => setProfile({ ...profile, legalName: e.target.value })}
                    className="w-full rounded border border-sky-300 px-3 py-2 outline-none font-semibold text-[#082f4f]"
                    required
                  />
                </div>
                <div>
                  <label className="block font-bold text-[#082f4f] mb-1">Trading Name (DBA)</label>
                  <input
                    type="text"
                    value={profile.tradingName}
                    onChange={(e) => setProfile({ ...profile, tradingName: e.target.value })}
                    className="w-full rounded border border-sky-300 px-3 py-2 outline-none font-semibold text-[#082f4f]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-[#082f4f] mb-1">Tax Identification Number (TIN)</label>
                  <input
                    type="text"
                    value={profile.tin}
                    onChange={(e) => setProfile({ ...profile, tin: e.target.value })}
                    placeholder="e.g. C001928381"
                    className="w-full rounded border border-sky-300 px-3 py-2 outline-none font-mono text-[#082f4f]"
                    required
                  />
                </div>
                <div>
                  <label className="block font-bold text-[#082f4f] mb-1">VAT Registration Number</label>
                  <input
                    type="text"
                    value={profile.vatRegNo}
                    onChange={(e) => setProfile({ ...profile, vatRegNo: e.target.value })}
                    placeholder="e.g. VAT-GH-991203"
                    className="w-full rounded border border-sky-300 px-3 py-2 outline-none font-mono text-[#082f4f]"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-[#082f4f] mb-1">Physical Business / Registered Office Address</label>
                <input
                  type="text"
                  value={profile.address}
                  onChange={(e) => setProfile({ ...profile, address: e.target.value })}
                  className="w-full rounded border border-sky-300 px-3 py-2 outline-none text-[#082f4f]"
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold text-[#082f4f] mb-1">Business Phone</label>
                  <input
                    type="text"
                    value={profile.phone}
                    onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
                    className="w-full rounded border border-sky-300 px-3 py-2 outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-[#082f4f] mb-1">Finance Email</label>
                  <input
                    type="email"
                    value={profile.email}
                    onChange={(e) => setProfile({ ...profile, email: e.target.value })}
                    className="w-full rounded border border-sky-300 px-3 py-2 outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-[#082f4f] mb-1">Fiscal Year Starts</label>
                  <select
                    value={profile.fiscalYearStart}
                    onChange={(e) => setProfile({ ...profile, fiscalYearStart: e.target.value })}
                    className="w-full rounded border border-sky-300 px-2 py-2 outline-none"
                  >
                    <option value="January">January (Calendar Year)</option>
                    <option value="April">April (UK/Tax standard)</option>
                    <option value="July">July (Mid-year)</option>
                    <option value="October">October (US Federal)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-[#082f4f] mb-1">
                  Bank Settlement Instructions (Printed on Sales Invoices)
                </label>
                <textarea
                  rows={2}
                  value={profile.bankPaymentDetails}
                  onChange={(e) => setProfile({ ...profile, bankPaymentDetails: e.target.value })}
                  placeholder="Bank name, account number, branch, SWIFT code for customer wires"
                  className="w-full rounded border border-sky-300 px-3 py-2 outline-none font-mono text-[11px]"
                />
              </div>

              <div className="flex justify-end pt-2 border-t border-sky-100">
                <button
                  type="submit"
                  className="flex items-center gap-2 rounded-lg bg-[#082f4f] px-5 py-2.5 text-xs font-bold text-white hover:bg-[#0c3f68] transition shadow-xs"
                >
                  <Save className="h-4 w-4" />
                  <span>Save Company Legal Profile</span>
                </button>
              </div>
              </fieldset>
            </form>
          </Card>
        </div>

        {/* Right: Data Safety, Backup & Exports */}
        <div className="lg:col-span-4 space-y-4">
          <Card title="Local demo export" sub="Not a production backup system">
            <div className="space-y-3 text-xs">
              <p className="text-[#2d4f6d] leading-relaxed">
                Data exists only in this browser and can be changed or lost. Export is for test data only; there is no automatic backup or shared database.
              </p>

              {isOwner && <button
                onClick={handleDownloadBackup}
                className="w-full flex items-center justify-center gap-2 rounded-lg bg-[#006f98] py-2.5 text-xs font-bold text-white hover:bg-[#085a7a] transition shadow-xs"
              >
                <Download className="h-4 w-4" />
                <span>Export local demo data (.json)</span>
              </button>}

              {isOwner && <label className="w-full flex items-center justify-center gap-2 rounded-lg border border-sky-300 bg-sky-50 py-2.5 text-xs font-bold text-[#082f4f] hover:bg-sky-100 transition cursor-pointer shadow-xs">
                <Upload className="h-4 w-4 text-[#006f98]" />
                <span>Restore from Backup File</span>
                <input type="file" accept=".json" onChange={handleFileUpload} className="hidden" />
              </label>}

              <button
                onClick={handleExportJournalCsv}
                className="w-full flex items-center justify-center gap-2 rounded-lg border border-sky-300 bg-white py-2.5 text-xs font-bold text-[#082f4f] hover:bg-sky-50 transition shadow-xs"
              >
                <FileSpreadsheet className="h-4 w-4 text-emerald-700" />
                <span>Export General Ledger (CSV)</span>
              </button>
            </div>
          </Card>

          {isOwner && (
            <Card title="Group fiscal year (all entities)" sub="Owner control · applies to every entity's books">
              <div className="space-y-3 text-xs">
                <p className="text-[#2d4f6d] leading-relaxed">
                  Set the fiscal year start month once and apply it to every entity in the group. Financial reports for each entity then measure from its own fiscal year start.
                </p>
                <div className="flex items-end gap-2">
                  <label className="flex-1 font-bold text-[#355875]">Fiscal year starts
                    <select
                      value={groupFyMonth}
                      onChange={(e) => setGroupFyMonth(e.target.value)}
                      className="mt-1 w-full rounded border border-sky-300 px-2 py-2 outline-none font-bold text-[#082f4f]"
                    >
                      {FISCAL_YEAR_MONTHS.map((m) => (
                        <option key={m.value} value={m.value}>{m.label}</option>
                      ))}
                    </select>
                  </label>
                  <button
                    onClick={handleApplyFiscalYearToAll}
                    className="rounded-lg bg-[#082f4f] px-4 py-2 text-xs font-bold text-white hover:bg-[#0c3f68] transition shadow-xs whitespace-nowrap"
                  >
                    Apply to all entities
                  </button>
                </div>
                {groupFyMsg && (
                  <div className="rounded-lg border border-emerald-300 bg-emerald-50 p-2.5 text-[11px] font-bold text-emerald-900 flex items-center gap-2">
                    <Check className="h-3.5 w-3.5 text-emerald-700 shrink-0" />
                    <span>{groupFyMsg}</span>
                  </div>
                )}
                <div className="overflow-x-auto rounded-lg border border-sky-200">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="border-b border-sky-200 bg-sky-50/70">
                        <th className="px-2.5 py-1.5 text-left font-bold uppercase tracking-wider text-[#2d4f6d]">Entity</th>
                        <th className="px-2.5 py-1.5 text-left font-bold uppercase tracking-wider text-[#2d4f6d]">Fiscal year starts</th>
                      </tr>
                    </thead>
                    <tbody>
                      {clients.map((c) => (
                        <tr key={c.id} className="border-b border-sky-100">
                          <td className="px-2.5 py-1.5 font-bold text-[#082f4f]">{c.code} · {c.name}</td>
                          <td className="px-2.5 py-1.5 font-mono text-[#355875]">{allProfiles[c.id]?.fiscalYearStart || 'January'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </Card>
          )}

          <Card title="Production onboarding" sub="Backend required">
            <div className="space-y-3 text-xs">
              <p className="text-[#2d4f6d] leading-relaxed">
                Do not clear sample journals and enter real balances here. Deploy server authentication, tenant-isolated storage, and tested backups first.
              </p>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};
