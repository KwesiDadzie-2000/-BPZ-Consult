import { useState } from 'react';
import type { PayeBand, TaxComponent } from '../types/accounting';
import { taxConfigStore, type TaxSettings } from '../utils/taxConfig';
import { Card, PageHeader, thCls, rowCls } from './ui';
import { Plus, RotateCcw, Save, ShieldAlert, Trash2 } from 'lucide-react';
import { uniqueId } from '../utils/ids';

export const TaxSettingsDesk = () => {
  const [settings, setSettings] = useState<TaxSettings>(() => taxConfigStore.get());
  const [notice, setNotice] = useState<string | null>(null);

  const save = () => {
    const bands = [...settings.payeBands].sort((a, b) => a.from - b.from);
    if (!bands.length) {
      setNotice('At least one PAYE band is required.');
      return;
    }
    if (bands[0].from !== 0) {
      setNotice('The first PAYE band must start at 0.');
      return;
    }
    for (let i = 0; i < bands.length; i += 1) {
      const b = bands[i];
      if (b.from < 0 || b.rate < 0 || b.rate > 100 || (b.to !== null && b.to <= b.from)) {
        setNotice(`Invalid PAYE band: ${b.name}`);
        return;
      }
      if (i > 0 && bands[i - 1].to !== b.from) {
        setNotice(`PAYE bands must be contiguous: ${bands[i - 1].name} must end at ${b.from}.`);
        return;
      }
    }
    const components = settings.components;
    if (components.some(c => c.rate < 0 || c.rate > 100 || !c.code.trim() || !c.name.trim())) {
      setNotice('Every tax component needs a code, name and rate from 0% to 100%.');
      return;
    }
    const componentKeys = components.map(c => `${c.code.toUpperCase()}|${c.effectiveFrom}`);
    if (new Set(componentKeys).size !== componentKeys.length) {
      setNotice('Tax component codes must be unique for the same effective date.');
      return;
    }
    taxConfigStore.save({ ...settings, payeBands: bands });
    setSettings(taxConfigStore.get());
    setNotice('Tax settings saved. New calculations use the new effective-dated settings.');
  };

  const updateBand = (id: string, patch: Partial<PayeBand>) => setSettings(s => ({ ...s, payeBands: s.payeBands.map(b => b.id === id ? { ...b, ...patch } : b) }));
  const updateComponent = (id: string, patch: Partial<TaxComponent>) => setSettings(s => ({ ...s, components: s.components.map(c => c.id === id ? { ...c, ...patch } : c) }));

  const addBand = () => {
    const sorted = [...settings.payeBands].sort((a, b) => a.from - b.from);
    const last = sorted[sorted.length - 1];
    const from = last?.to ?? last?.from ?? 0;
    setSettings(s => ({
      ...s,
      payeBands: [...s.payeBands, {
        id: `${uniqueId('paye')}`,
        name: `New band from ${from}`,
        from,
        to: null,
        rate: 0,
        effectiveFrom: s.effectiveFrom,
        isActive: true,
      }],
    }));
  };

  const addComponent = () => {
    setSettings(s => ({
      ...s,
      components: [...s.components, {
        id: `${uniqueId('tax')}`,
        code: 'NEW_TAX',
        name: 'New tax or levy',
        rate: 0,
        type: 'special_levy',
        appliesTo: 'both',
        isActive: false,
        effectiveFrom: s.effectiveFrom,
      }],
    }));
  };

  const deleteBand = (id: string) => setSettings(s => ({ ...s, payeBands: s.payeBands.filter(b => b.id !== id) }));
  const deleteComponent = (id: string) => setSettings(s => ({ ...s, components: s.components.filter(c => c.id !== id) }));

  return <div className="space-y-6">
    <PageHeader kicker="OWNER · EFFECTIVE-DATED TAX SETTINGS" title="Tax Rates & Levy Configuration" desc="Owner-controlled settings for future statutory changes. Confirm each change with current GRA or sector regulator guidance before making it effective." />
    <div className="rounded-xl border border-amber-400 bg-amber-50 p-4 text-sm text-amber-950 flex items-start gap-2"><ShieldAlert className="h-5 w-5 mt-0.5 text-amber-700 shrink-0" /><div><strong>Change control:</strong> Rates affect payroll and billing calculations. Record the official source and effective date outside this browser until the server audit log is live.</div></div>
    {notice && <div className={`rounded-lg border p-3 text-xs font-bold ${notice.startsWith('Invalid') || notice.includes('must') || notice.includes('needs') ? 'border-rose-300 bg-rose-50 text-rose-900' : 'border-emerald-300 bg-emerald-50 text-emerald-900'}`}>{notice}</div>}

    <Card title="Configuration version" sub="Use a new effective date when a statutory change takes effect; do not overwrite history needed for prior periods.">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
        <label className="font-bold text-[#355875]">Jurisdiction
          <input value={settings.jurisdiction} onChange={(e) => setSettings(s => ({ ...s, jurisdiction: e.target.value.toUpperCase() }))} className="mt-1 w-full rounded border border-sky-300 p-2 font-mono" />
        </label>
        <label className="font-bold text-[#355875]">Configuration effective from
          <input type="date" value={settings.effectiveFrom} onChange={(e) => setSettings(s => ({ ...s, effectiveFrom: e.target.value }))} className="mt-1 w-full rounded border border-sky-300 p-2" />
        </label>
        <div className="rounded bg-sky-50 border border-sky-200 p-3">
          <span className="block text-[10px] uppercase font-bold text-[#355875]">Last saved</span>
          <strong className="font-mono text-[#082f4f]">{settings.updatedAt}</strong>
        </div>
      </div>
    </Card>

    <Card title="Resident PAYE monthly bands" sub="GRA 2026 bands effective 1 September 2026. Edit only with approved statutory notice." action={<button type="button" onClick={addBand} className="rounded bg-[#082f4f] px-3 py-1.5 text-xs font-bold text-white flex items-center gap-1.5"><Plus className="h-3.5 w-3.5" /> Add band</button>}>
      <div className="overflow-x-auto"><table className="w-full min-w-[820px] text-xs"><thead><tr className="border-b border-sky-200 bg-sky-50/70"><th className={thCls}>Name</th><th className={thCls + ' text-right'}>From</th><th className={thCls + ' text-right'}>To</th><th className={thCls + ' text-right'}>Rate %</th><th className={thCls}>Effective from</th><th className={thCls}>Active</th><th className={thCls}>Remove</th></tr></thead><tbody>{settings.payeBands.map(b => <tr key={b.id} className={rowCls}><td className="p-2"><input value={b.name} onChange={e => updateBand(b.id, { name: e.target.value })} className="w-full border border-sky-200 rounded p-1" /></td><td className="p-2"><input type="number" value={b.from} onChange={e => updateBand(b.id, { from: Number(e.target.value) })} className="w-24 border border-sky-200 rounded p-1 font-mono text-right" /></td><td className="p-2"><input type="number" value={b.to ?? ''} placeholder="No cap" onChange={e => updateBand(b.id, { to: e.target.value === '' ? null : Number(e.target.value) })} className="w-24 border border-sky-200 rounded p-1 font-mono text-right" /></td><td className="p-2"><input type="number" step="0.01" value={b.rate} onChange={e => updateBand(b.id, { rate: Number(e.target.value) })} className="w-20 border border-sky-200 rounded p-1 font-mono text-right" /></td><td className="p-2"><input type="date" value={b.effectiveFrom} onChange={e => updateBand(b.id, { effectiveFrom: e.target.value })} className="border border-sky-200 rounded p-1" /></td><td className="p-2"><input type="checkbox" checked={b.isActive} onChange={e => updateBand(b.id, { isActive: e.target.checked })} /></td><td className="p-2"><button type="button" onClick={() => deleteBand(b.id)} className="rounded border border-rose-200 bg-rose-50 px-2 py-1 text-rose-700"><Trash2 className="h-3.5 w-3.5" /></button></td></tr>)}</tbody></table></div>
    </Card>

    <Card title="Indirect taxes, income WHT and sector levies" sub="CST must only be charged by notified Class 1 electronic communications service providers. VAT withholding applies only to appointed agents." action={<button type="button" onClick={addComponent} className="rounded bg-[#082f4f] px-3 py-1.5 text-xs font-bold text-white flex items-center gap-1.5"><Plus className="h-3.5 w-3.5" /> Add tax / levy</button>}>
      <div className="overflow-x-auto"><table className="w-full min-w-[920px] text-xs"><thead><tr className="border-b border-sky-200 bg-sky-50/70"><th className={thCls}>Code</th><th className={thCls}>Tax / levy</th><th className={thCls + ' text-right'}>Rate %</th><th className={thCls}>Applies to</th><th className={thCls}>Effective from</th><th className={thCls}>Active</th><th className={thCls}>Remove</th></tr></thead><tbody>{settings.components.map(c => <tr key={c.id} className={rowCls}><td className="p-2"><input value={c.code} onChange={e => updateComponent(c.id, { code: e.target.value.toUpperCase().replace(/\s+/g, '_') })} className="w-32 border border-sky-200 rounded p-1 font-mono text-[#855b00]" /></td><td className="p-2"><input value={c.name} onChange={e => updateComponent(c.id, { name: e.target.value })} className="w-full border border-sky-200 rounded p-1" /></td><td className="p-2"><input type="number" step="0.01" value={c.rate} onChange={e => updateComponent(c.id, { rate: Number(e.target.value) })} className="w-20 border border-sky-200 rounded p-1 font-mono text-right" /></td><td className="p-2"><select value={c.appliesTo} onChange={e => updateComponent(c.id, { appliesTo: e.target.value as TaxComponent['appliesTo'] })} className="border border-sky-200 rounded p-1"><option value="sales">Sales</option><option value="purchase">Purchase</option><option value="both">Both</option></select></td><td className="p-2"><input type="date" value={c.effectiveFrom} onChange={e => updateComponent(c.id, { effectiveFrom: e.target.value })} className="border border-sky-200 rounded p-1" /></td><td className="p-2"><input type="checkbox" checked={c.isActive} onChange={e => updateComponent(c.id, { isActive: e.target.checked })} /></td><td className="p-2"><button type="button" onClick={() => deleteComponent(c.id)} className="rounded border border-rose-200 bg-rose-50 px-2 py-1 text-rose-700"><Trash2 className="h-3.5 w-3.5" /></button></td></tr>)}</tbody></table></div>
    </Card>

    <div className="flex gap-2"><button onClick={save} className="rounded bg-[#082f4f] text-white px-4 py-2 text-xs font-bold flex gap-1.5 items-center"><Save className="h-3.5 w-3.5" /> Save tax settings</button><button onClick={() => { taxConfigStore.reset(); setSettings(taxConfigStore.get()); setNotice('Default Ghana configuration restored.'); }} className="rounded border border-sky-300 bg-white text-[#082f4f] px-4 py-2 text-xs font-bold flex gap-1.5 items-center"><RotateCcw className="h-3.5 w-3.5" /> Restore defaults</button></div>
  </div>;
};
