import React, { useState } from 'react';
import { ClientEntity, ACDOCALine, UserAccount } from '../types/accounting';
import { Card, PageHeader, formatGHS, thCls, numCls, rowCls } from './ui';
import { Plus, CheckCircle } from 'lucide-react';
import { nextDocNo, uniqueId } from '../utils/ids';

interface LoansAmortisationDeskProps {
  currentClient: ClientEntity;
  currentUser: UserAccount;
  onAddJournalLines: (lines: ACDOCALine[]) => void;
}

export type FacilityType = 'amortising' | 'interest_only' | 'bullet';

export interface LoanFacility {
  id: string;
  code: string;
  facilityName: string;
  lender: string;
  principal: number;
  annualRatePct: number;
  termMonths: number;
  frequency: 'monthly' | 'quarterly';
  facilityType: FacilityType;
  arrangementFee: number;
  startDate: string;
  status: 'Active';
}

export interface AmortisationRow {
  periodNum: number;
  date: string;
  openingBalance: number;
  interestExpense: number;
  principalPayment: number;
  totalPayment: number;
  closingBalance: number;
}

export const LoansAmortisationDesk: React.FC<LoansAmortisationDeskProps> = ({
  currentClient,
  currentUser,
  onAddJournalLines,
}) => {
  const [facilities, setFacilities] = useState<LoanFacility[]>([
    {
      id: 'LN-01',
      code: 'LN-ECOBANK-TAILINGS',
      facilityName: 'Tailings Dam Syndicated Expansion Facility',
      lender: 'Ecobank Ghana Ltd',
      principal: 1200000,
      annualRatePct: 21.5,
      termMonths: 60,
      frequency: 'monthly',
      facilityType: 'amortising',
      arrangementFee: 24000,
      startDate: '2026-01-01',
      status: 'Active',
    },
    {
      id: 'LN-02',
      code: 'LN-STANBIC-FLEET',
      facilityName: 'Komatsu Heavy Haulage Equipment Finance',
      lender: 'Stanbic Bank Ghana',
      principal: 350000,
      annualRatePct: 18.0,
      termMonths: 36,
      frequency: 'monthly',
      facilityType: 'amortising',
      arrangementFee: 7000,
      startDate: '2026-02-01',
      status: 'Active',
    },
  ]);

  const [selectedFacilityId, setSelectedFacilityId] = useState<string>(facilities[0]?.id || 'LN-01');
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);

  // New facility form
  const [showNewModal, setShowNewModal] = useState(false);
  const [fName, setFName] = useState('Working Capital Overdraft Line');
  const [fLender, setFLender] = useState('Absa Bank Ghana');
  const [fPrincipal, setFPrincipal] = useState(500000);
  const [fRate, setFRate] = useState(22.0);
  const [fTerm, setFTerm] = useState(24);
  const [fType, setFType] = useState<FacilityType>('amortising');

  const selectedFacility = facilities.find((f) => f.id === selectedFacilityId) || facilities[0];

  // Mathematical Amortisation Schedule Generator
  const generateSchedule = (loan: LoanFacility): AmortisationRow[] => {
    const rows: AmortisationRow[] = [];
    const monthlyRate = loan.annualRatePct / 100 / 12;
    const n = loan.termMonths;
    let balance = loan.principal;

    // Annuity constant instalment: P * i / (1 - (1+i)^-n)
    const factor = Math.pow(1 + monthlyRate, n);
    const monthlyAnnuity =
      loan.facilityType === 'amortising'
        ? (loan.principal * monthlyRate * factor) / (factor - 1)
        : loan.principal * monthlyRate;

    for (let i = 1; i <= Math.min(24, n); i++) {
      const interest = balance * monthlyRate;
      let principalPmt = 0;
      let totalPmt = 0;

      if (loan.facilityType === 'amortising') {
        principalPmt = Math.min(balance, monthlyAnnuity - interest);
        totalPmt = monthlyAnnuity;
      } else if (loan.facilityType === 'interest_only') {
        principalPmt = i === n ? balance : 0;
        totalPmt = interest + principalPmt;
      } else {
        // Bullet
        principalPmt = i === n ? balance : 0;
        totalPmt = i === n ? balance + interest : 0;
      }

      const closing = Math.max(0, balance - principalPmt);

      rows.push({
        periodNum: i,
        date: `2026-${String((i % 12) + 1).padStart(2, '0')}-28`,
        openingBalance: balance,
        interestExpense: interest,
        principalPayment: principalPmt,
        totalPayment: totalPmt,
        closingBalance: closing,
      });

      balance = closing;
      if (balance <= 0.01) break;
    }

    return rows;
  };

  const scheduleRows = selectedFacility ? generateSchedule(selectedFacility) : [];

  // Post Monthly Debt Service to Universal Journal
  const handlePostMonthlyDebtService = (row: AmortisationRow) => {
    const today = new Date().toISOString().split('T')[0];
    const lines: ACDOCALine[] = [
      // 1. Debit Finance Costs (700000)
      {
        id: uniqueId('JL-LOAN'),
        docNo: `LOAN-PMT-${selectedFacility.code}-M${row.periodNum}`,
        period: new Date().toISOString().slice(0, 7),
        date: today,
        module: 'FI',
        docType: 'PAY',
        accountNo: '700000',
        accountName: 'Finance Costs & Loan Interest (P&L)',
        costCenter: 'CC-ADM',
        debit: row.interestExpense,
        credit: 0,
        currency: currentClient.currency,
        description: `Loan interest expense: ${selectedFacility.facilityName} (M${row.periodNum})`,
        createdBy: currentUser.username,
        checkedBy: currentUser.canCheck ? currentUser.username : undefined,
        clientId: currentClient.id,
      },
      // 2. Debit Commercial Borrowings (250000) for Principal
      {
        id: uniqueId('JL-LOAN'),
        docNo: `LOAN-PMT-${selectedFacility.code}-M${row.periodNum}`,
        period: new Date().toISOString().slice(0, 7),
        date: today,
        module: 'FI',
        docType: 'PAY',
        accountNo: '250000',
        accountName: 'Commercial Loans Payable (Ecobank / Stanbic)',
        costCenter: 'CC-ADM',
        debit: row.principalPayment,
        credit: 0,
        currency: currentClient.currency,
        description: `Loan principal repayment on ${selectedFacility.code}`,
        createdBy: currentUser.username,
        checkedBy: currentUser.canCheck ? currentUser.username : undefined,
        clientId: currentClient.id,
      },
      // 3. Credit Bank Cash (100000)
      {
        id: uniqueId('JL-LOAN'),
        docNo: `LOAN-PMT-${selectedFacility.code}-M${row.periodNum}`,
        period: new Date().toISOString().slice(0, 7),
        date: today,
        module: 'FI',
        docType: 'PAY',
        accountNo: '100000',
        accountName: 'Cash at Bank (Ecobank Ghana Operating)',
        costCenter: 'CC-ADM',
        debit: 0,
        credit: row.totalPayment,
        currency: currentClient.currency,
        description: `Disbursement of monthly debt service instalment`,
        createdBy: currentUser.username,
        checkedBy: currentUser.canCheck ? currentUser.username : undefined,
        clientId: currentClient.id,
      },
    ];

    onAddJournalLines(lines);
    setActionSuccess(
      `Loan Instalment M${row.periodNum} Posted to ACDOCA! Total ₵${formatGHS(row.totalPayment)} (Principal: ₵${formatGHS(row.principalPayment)}, Interest: ₵${formatGHS(row.interestExpense)}).`
    );
    setTimeout(() => setActionSuccess(null), 5000);
  };

  const handleCreateFacility = (e: React.FormEvent) => {
    e.preventDefault();
    const newF: LoanFacility = {
      id: `LN-0${facilities.length + 1}`,
      code: nextDocNo(`LN-${fLender.substring(0, 3).toUpperCase()}`, facilities.map((f) => f.code), 3),
      facilityName: fName,
      lender: fLender,
      principal: fPrincipal,
      annualRatePct: fRate,
      termMonths: fTerm,
      frequency: 'monthly',
      facilityType: fType,
      arrangementFee: fPrincipal * 0.015,
      startDate: new Date().toISOString().split('T')[0],
      status: 'Active',
    };
    setFacilities([...facilities, newF]);
    setSelectedFacilityId(newF.id);
    setShowNewModal(false);
    setActionSuccess(`Registered new borrowing facility ${newF.code}. Amortisation schedule computed.`);
    setTimeout(() => setActionSuccess(null), 4000);
  };

  return (
    <div className="space-y-6">
      <PageHeader
        kicker={`FIN · BORROWINGS & LOAN AMORTISATION · ${currentClient.code}`}
        title="Loan Facilities & Amortisation Schedules (IAS 23 & IFRS 9)"
        desc="Borrowing facilities with full amortisation schedules (annuity, interest-only, bullet)."
      >
        <button
          onClick={() => setShowNewModal(true)}
          className="flex items-center gap-1.5 rounded-lg bg-[#082f4f] px-3.5 py-2 text-xs font-bold text-white hover:bg-[#0c3f68] transition shadow-xs"
        >
          <Plus className="h-4 w-4" />
          <span>New Borrowing Facility</span>
        </button>
      </PageHeader>

      {actionSuccess && (
        <div className="rounded-xl border border-emerald-300 bg-emerald-50 p-4 text-xs font-bold text-emerald-900 flex items-center gap-2 shadow-xs">
          <CheckCircle className="h-4 w-4 text-emerald-700 shrink-0" />
          <span>{actionSuccess}</span>
        </div>
      )}

      {/* Facility Selector Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {facilities.map((f) => {
          const isSelected = f.id === selectedFacilityId;
          return (
            <div
              key={f.id}
              onClick={() => setSelectedFacilityId(f.id)}
              className={`cursor-pointer rounded-xl border p-4 transition shadow-xs ${
                isSelected
                  ? 'border-[#082f4f] bg-sky-50 ring-1 ring-[#082f4f]'
                  : 'border-sky-200 bg-white hover:bg-sky-50/50'
              }`}
            >
              <div className="flex items-center justify-between text-xs font-mono text-[#355875]">
                <span className="font-bold text-[#855b00]">{f.code}</span>
                <span className="rounded bg-sky-100 px-1.5 py-0.5 text-[10px] text-[#006f98] font-bold">
                  {f.facilityType.toUpperCase()}
                </span>
              </div>
              <h4 className="text-sm font-bold text-[#082f4f] mt-1">{f.facilityName}</h4>
              <div className="text-xs text-[#2d4f6d]">{f.lender} · {f.termMonths} Months</div>
              <div className="mt-3 flex items-center justify-between border-t border-sky-200 pt-2 text-xs font-mono">
                <span className="text-[#355875]">Principal:</span>
                <span className="font-bold text-[#082f4f]">₵{formatGHS(f.principal)}</span>
              </div>
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-[#355875]">Rate:</span>
                <span className="font-bold text-[#855b00]">{f.annualRatePct}% p.a.</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Active Schedule Table */}
      {selectedFacility && (
        <Card
          title={`Amortisation Schedule — ${selectedFacility.facilityName}`}
          sub={`Principal: ₵${formatGHS(selectedFacility.principal)} · Annual Rate: ${selectedFacility.annualRatePct}% · Method: ${selectedFacility.facilityType}`}
        >
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-sky-200 bg-sky-50/70">
                  <th className={thCls + " text-center"}>Period</th>
                  <th className={thCls}>Payment Date</th>
                  <th className={thCls + " text-right"}>Opening Principal (₵)</th>
                  <th className={thCls + " text-right"}>Interest Charge (₵)</th>
                  <th className={thCls + " text-right"}>Principal Repaid (₵)</th>
                  <th className={thCls + " text-right"}>Total Instalment (₵)</th>
                  <th className={thCls + " text-right"}>Closing Principal (₵)</th>
                  <th className={thCls + " text-center"}>Accounting Action</th>
                </tr>
              </thead>
              <tbody>
                {scheduleRows.map((r) => (
                  <tr key={r.periodNum} className={rowCls}>
                    <td className="px-3 py-2 text-center font-mono font-bold text-[#855b00]">
                      M{r.periodNum}
                    </td>
                    <td className="px-3 py-2 font-mono text-[#355875]">{r.date}</td>
                    <td className={numCls}>{formatGHS(r.openingBalance)}</td>
                    <td className={numCls + " text-rose-700 font-bold"}>₵{formatGHS(r.interestExpense)}</td>
                    <td className={numCls + " text-[#006f98] font-bold"}>₵{formatGHS(r.principalPayment)}</td>
                    <td className={numCls + " font-black text-[#082f4f]"}>₵{formatGHS(r.totalPayment)}</td>
                    <td className={numCls + " font-bold text-emerald-800"}>₵{formatGHS(r.closingBalance)}</td>
                    <td className="px-3 py-2 text-center">
                      <button
                        onClick={() => handlePostMonthlyDebtService(r)}
                        className="rounded bg-[#082f4f] px-2.5 py-1 text-[11px] font-bold text-white hover:bg-[#0c3f68] transition"
                      >
                        Post Debt Service
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      {/* New Facility Modal */}
      {showNewModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <form onSubmit={handleCreateFacility} className="w-full max-w-lg rounded-xl border border-sky-300 bg-white p-6 shadow-xl space-y-4">
            <h3 className="text-base font-bold text-[#082f4f] border-b border-sky-100 pb-2">Register Borrowing Facility</h3>
            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-[#0a253e] mb-1">Facility Name / Purpose</label>
                <input
                  type="text"
                  value={fName}
                  onChange={(e) => setFName(e.target.value)}
                  className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none"
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Lending Financial Institution</label>
                  <input
                    type="text"
                    value={fLender}
                    onChange={(e) => setFLender(e.target.value)}
                    className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Facility Type</label>
                  <select
                    value={fType}
                    onChange={(e) => setFType(e.target.value as any)}
                    className="w-full rounded border border-sky-300 px-2 py-1.5 outline-none"
                  >
                    <option value="amortising">Amortising (Annuity Equal Payments)</option>
                    <option value="interest_only">Interest-Only (Bullet Principal)</option>
                    <option value="bullet">Bullet (Interest + Principal at Maturity)</option>
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Principal (₵)</label>
                  <input
                    type="number"
                    min="1000"
                    value={fPrincipal}
                    onChange={(e) => setFPrincipal(Number(e.target.value))}
                    className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Annual Rate (%)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={fRate}
                    onChange={(e) => setFRate(Number(e.target.value))}
                    className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="block font-bold text-[#0a253e] mb-1">Term (Months)</label>
                  <input
                    type="number"
                    min="1"
                    value={fTerm}
                    onChange={(e) => setFTerm(Number(e.target.value))}
                    className="w-full rounded border border-sky-300 px-3 py-1.5 outline-none"
                    required
                  />
                </div>
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-2 border-t border-sky-100">
              <button type="button" onClick={() => setShowNewModal(false)} className="rounded px-3 py-1.5 text-xs font-semibold text-[#2d4f6d]">Cancel</button>
              <button type="submit" className="rounded bg-[#082f4f] px-4 py-1.5 text-xs font-bold text-white">Generate Schedule</button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
