import { useEffect, useMemo, useState } from 'react';
import type {
  AccountMaster,
  ACDOCALine,
  BankAccount,
  BusinessPartner,
  ClientEntity,
  PrepaymentCategory,
  PrepaymentMethod,
  PrepaymentRecord,
  PrepaymentScheduleLine,
  PrepaymentSource,
  UserAccount,
} from '../types/accounting';
import { Card, PageHeader, Stat, formatGHS, thCls, numCls, rowCls } from './ui';
import { persistentStorage } from '../utils/persistentStorage';
import { benefitEndDate, buildPrepaymentSchedule, summarizePrepayment, validateSchedule } from '../utils/prepayments';
import { Download, Play, Plus, Printer, Save, X } from 'lucide-react';
import { uniqueId } from '../utils/ids';

interface Props {
  currentClient: ClientEntity;
  currentUser: UserAccount;
  isPeriodClosed: boolean;
  lines: ACDOCALine[];
  accounts: AccountMaster[];
  bankAccounts: BankAccount[];
  partners: BusinessPartner[];
  onAddJournalLines: (lines: ACDOCALine[]) => boolean;
  onBankBalanceChange?: (bankId: number, delta: number) => void;
}

const CATEGORIES: PrepaymentCategory[] = [
  'Insurance', 'Rent', 'Software subscription', 'Maintenance contract',
  'Professional retainer', 'Licence & permits', 'Utilities deposit', 'Other',
];

const round2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;

const recalcBalances = (record: PrepaymentRecord, schedules: PrepaymentScheduleLine[]): PrepaymentScheduleLine[] => {
  let opening = record.totalAmount;
  return [...schedules]
    .sort((a, b) => a.sequence - b.sequence)
    .map((line) => {
      const closing = round2(opening - line.amount);
      const next = { ...line, openingBalance: opening, closingBalance: closing };
      opening = closing;
      return next;
    });
};

export const PrepaymentsSection = ({
  currentClient,
  currentUser,
  isPeriodClosed,
  lines,
  accounts,
  bankAccounts,
  partners,
  onAddJournalLines,
  onBankBalanceChange,
}: Props) => {
  const [records, setRecords] = useState<PrepaymentRecord[]>(() => persistentStorage.getPrepayments());
  const [schedules, setSchedules] = useState<PrepaymentScheduleLine[]>(() => persistentStorage.getPrepaymentSchedules());
  const [chosenId, setSelectedId] = useState<string>('');
  const [runPeriod, setRunPeriod] = useState(() => new Date().toISOString().slice(0, 7));
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | PrepaymentRecord['status']>('all');
  const [showCreate, setShowCreate] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  // Create form
  const [code, setCode] = useState('');
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<PrepaymentCategory>('Insurance');
  const [vendorName, setVendorName] = useState('');
  const [reference, setReference] = useState('');
  const [paymentDate, setPaymentDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [benefitStart, setBenefitStart] = useState(() => new Date().toISOString().slice(0, 10));
  const [termMonths, setTermMonths] = useState(12);
  const [totalAmount, setTotalAmount] = useState(0);
  const [method, setMethod] = useState<PrepaymentMethod>('straight_line');
  const [prepaidAccountNo, setPrepaidAccountNo] = useState('116000');
  const [expenseAccountNo, setExpenseAccountNo] = useState('630000');
  const [costCenter, setCostCenter] = useState('CC-OPS');
  const [source, setSource] = useState<PrepaymentSource>('bank');
  const [sourceBankId, setSourceBankId] = useState<number>(bankAccounts[0]?.id || 0);
  const [note, setNote] = useState('');

  const clientRecords = records.filter((r) => r.clientId === currentClient.id);
  // Derived during render (was a setState-in-effect that re-rendered twice):
  // fall back to the entity's first record when the choice is empty or belongs
  // to another entity. Declared BEFORE first use — reading it later caused a
  // temporal-dead-zone crash ("Cannot access 'selectedId' before initialization")
  // that took the whole workspace page down whenever this desk was opened.
  const selectedId = clientRecords.some((r) => r.id === chosenId) ? chosenId : (clientRecords[0]?.id || '');
  const selectedRecord = clientRecords.find((r) => r.id === selectedId) || clientRecords[0];
  const selectedSchedule = selectedRecord
    ? schedules.filter((s) => s.prepaymentId === selectedRecord.id).sort((a, b) => a.sequence - b.sequence)
    : [];
  const selectedSummary = selectedRecord ? summarizePrepayment(selectedRecord, selectedSchedule, runPeriod) : null;

  const prepaidOptions = useMemo(() => {
    const assets = accounts.filter((a) => a.active && a.type === 'Asset');
    return assets.some((a) => a.accountNo === '116000')
      ? assets
      : [{ accountNo: '116000', name: 'Prepayments & Deferred Charges', type: 'Asset' as const, category: 'Current Assets', active: true }, ...assets];
  }, [accounts]);

  const expenseOptions = useMemo(() => {
    const expenses = accounts.filter((a) => a.active && a.type === 'Expense');
    return expenses.some((a) => a.accountNo === '650000')
      ? expenses
      : [...expenses, { accountNo: '650000', name: 'Rent & Occupancy Expense', type: 'Expense' as const, category: 'Operating Expenses', active: true }];
  }, [accounts]);

  useEffect(() => { persistentStorage.savePrepayments(records); }, [records]);
  useEffect(() => { persistentStorage.savePrepaymentSchedules(schedules); }, [schedules]);

  const restricted = currentUser.status === 'restricted' || currentUser.status === 'suspended' || currentUser.permissions?.canPostJournals === false;

  const allSummaries = clientRecords.map((record) => ({
    record,
    summary: summarizePrepayment(record, schedules.filter((s) => s.prepaymentId === record.id), runPeriod),
  }));
  const totalOriginal = allSummaries.reduce((n, x) => n + x.record.totalAmount, 0);
  const totalRecognized = allSummaries.reduce((n, x) => n + x.summary.recognized, 0);
  const totalUnrecognized = allSummaries.reduce((n, x) => n + x.summary.unrecognized, 0);
  const totalDue = allSummaries.reduce((n, x) => n + x.summary.dueAmount, 0);

  const filteredRecords = allSummaries.filter(({ record }) => {
    const matchesStatus = statusFilter === 'all' || record.status === statusFilter;
    const q = search.trim().toLowerCase();
    const matchesSearch = !q || record.code.toLowerCase().includes(q) || record.title.toLowerCase().includes(q) || record.vendorName.toLowerCase().includes(q) || record.category.toLowerCase().includes(q);
    return matchesStatus && matchesSearch;
  });

  const previewSchedule = useMemo(() => {
    try {
      return buildPrepaymentSchedule({
        prepaymentId: 'PREVIEW', clientId: currentClient.id, totalAmount, benefitStart, termMonths, method,
      });
    } catch {
      return [];
    }
  }, [currentClient.id, totalAmount, benefitStart, termMonths, method]);

  const openCreate = () => {
    const nextNo = clientRecords.length + 1;
    setCode(`PRE-${new Date().getFullYear()}-${String(nextNo).padStart(3, '0')}`);
    setFeedback(null);
    setShowCreate(true);
  };

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    if (restricted) return setFeedback('Action blocked: this user cannot post journals.');
    if (isPeriodClosed) return setFeedback('Creation blocked: the accounting period is closed.');
    if (!code.trim() || !title.trim() || !vendorName.trim()) return setFeedback('Code, title and vendor/supplier are required.');
    if (records.some((r) => r.clientId === currentClient.id && r.code.toLowerCase() === code.trim().toLowerCase())) {
      return setFeedback(`Prepayment code ${code} already exists in this workspace.`);
    }
    if (!Number.isFinite(totalAmount) || totalAmount <= 0) return setFeedback('Total prepaid amount must be greater than zero.');
    if (currentUser.makerLimit > 0 && totalAmount > currentUser.makerLimit) {
      return setFeedback(`Amount exceeds maker limit ${formatGHS(currentUser.makerLimit)}. Use the approval workflow before recording this prepayment.`);
    }

    const prepaidAccount = prepaidOptions.find((a) => a.accountNo === prepaidAccountNo);
    const expenseAccount = expenseOptions.find((a) => a.accountNo === expenseAccountNo);
    if (!prepaidAccount || !expenseAccount) return setFeedback('Select valid prepaid and expense GL accounts.');

    const id = uniqueId('PRE');
    const record: PrepaymentRecord = {
      id,
      clientId: currentClient.id,
      code: code.trim().toUpperCase(),
      title: title.trim(),
      category,
      vendorName: vendorName.trim(),
      reference: reference.trim(),
      paymentDate,
      benefitStart,
      benefitEnd: benefitEndDate(benefitStart, termMonths),
      termMonths,
      totalAmount: round2(totalAmount),
      prepaidAccountNo: prepaidAccount.accountNo,
      prepaidAccountName: prepaidAccount.name,
      expenseAccountNo: expenseAccount.accountNo,
      expenseAccountName: expenseAccount.name,
      costCenter: costCenter.trim() || 'CC-ADM',
      method,
      source,
      status: 'active',
      createdBy: currentUser.username,
      createdAt: new Date().toISOString(),
      note: note.trim() || undefined,
    };

    let newSchedule: PrepaymentScheduleLine[];
    try {
      newSchedule = buildPrepaymentSchedule({
        prepaymentId: id, clientId: currentClient.id, totalAmount: record.totalAmount,
        benefitStart, termMonths, method,
      });
    } catch (err) {
      return setFeedback(err instanceof Error ? err.message : 'Could not build the recognition schedule.');
    }

    if (source !== 'opening_balance') {
      const bank = bankAccounts.find((b) => b.id === sourceBankId);
      if (source === 'bank' && !bank) return setFeedback('Select the bank/cash account used to pay this prepayment.');
      if (source === 'bank' && bank && bank.balance + 0.009 < record.totalAmount) {
        return setFeedback(`Insufficient recorded balance in ${bank.name} for ${formatGHS(record.totalAmount)}.`);
      }
      const docNo = `${record.code}-ACQ`;
      if (lines.some((l) => l.clientId === currentClient.id && l.docNo === docNo)) {
        return setFeedback(`Acquisition document ${docNo} already exists.`);
      }
      const creditAccount = source === 'bank'
        ? (bank?.glAccount
            ? { accountNo: bank.glAccount, accountName: bank.glAccount === '104000' ? 'Mobile Money Clearing Account' : bank.kind === 'cash' ? bank.name : `Cash at Bank (${bank.bankName})` }
            : { accountNo: bank?.code === 'BNK-03' ? '102000' : '100000', accountName: bank?.code === 'BNK-03' ? 'Petty Cash Safe Float' : `Cash at Bank (${bank?.bankName || 'Bank'})` })
        : { accountNo: '200000', accountName: `Trade Payables (${record.vendorName})` };
      const posted = onAddJournalLines([
        {
          id: uniqueId('JL-PRE'), docNo, period: paymentDate.slice(0, 7), date: paymentDate, module: 'FI', docType: 'STAT',
          accountNo: record.prepaidAccountNo, accountName: record.prepaidAccountName, costCenter: record.costCenter,
          debit: record.totalAmount, credit: 0, currency: currentClient.currency,
          description: `Prepayment acquired: ${record.title} (${record.reference || record.code})`, createdBy: currentUser.username, clientId: currentClient.id,
        },
        {
          id: uniqueId('JL-PRE'), docNo, period: paymentDate.slice(0, 7), date: paymentDate, module: 'FI', docType: 'STAT',
          accountNo: creditAccount.accountNo, accountName: creditAccount.accountName, costCenter: record.costCenter,
          debit: 0, credit: record.totalAmount, currency: currentClient.currency,
          description: `Prepayment consideration: ${record.title}`, createdBy: currentUser.username, clientId: currentClient.id,
        },
      ]);
      if (!posted) return setFeedback('Acquisition journal was rejected. Check the period, balance and document number.');
      if (source === 'bank' && bank && onBankBalanceChange) onBankBalanceChange(bank.id, -record.totalAmount);
    }

    setRecords((prev) => [...prev, record]);
    setSchedules((prev) => [...prev, ...newSchedule]);
    setSelectedId(id);
    setShowCreate(false);
    setTitle(''); setVendorName(''); setReference(''); setTotalAmount(0); setNote('');
    setFeedback(`Prepayment ${record.code} created with a ${termMonths}-month ${method === 'straight_line' ? 'straight-line' : 'daily pro-rata'} schedule.`);
  };

  const postScheduleLine = (record: PrepaymentRecord, line: PrepaymentScheduleLine): boolean => {
    if (record.status !== 'active' || line.status === 'posted') return false;
    const recordSchedule = schedules.filter((s) => s.prepaymentId === record.id);
    const validation = validateSchedule(record, recordSchedule);
    if (validation) { setFeedback(validation); return false; }
    if (line.period > runPeriod) { setFeedback(`Schedule line ${line.sequence} is not due until ${line.period}.`); return false; }
    const docNo = `${record.code}-${String(line.sequence).padStart(3, '0')}`;
    const alreadyInLedger = lines.some((l) => l.clientId === currentClient.id && l.docNo === docNo);
    if (!alreadyInLedger) {
      const posted = onAddJournalLines([
        {
          id: uniqueId('JL-PRE'), docNo, period: line.period, date: line.recognitionDate, module: 'FI', docType: 'STAT',
          accountNo: record.expenseAccountNo, accountName: record.expenseAccountName, costCenter: record.costCenter,
          debit: line.amount, credit: 0, currency: currentClient.currency,
          description: `Prepayment amortisation: ${record.title} (${line.period})`, createdBy: currentUser.username, clientId: currentClient.id,
        },
        {
          id: uniqueId('JL-PRE'), docNo, period: line.period, date: line.recognitionDate, module: 'FI', docType: 'STAT',
          accountNo: record.prepaidAccountNo, accountName: record.prepaidAccountName, costCenter: record.costCenter,
          debit: 0, credit: line.amount, currency: currentClient.currency,
          description: `Prepayment amortisation: ${record.title} (${line.period})`, createdBy: currentUser.username, clientId: currentClient.id,
        },
      ]);
      if (!posted) { setFeedback(`Posting rejected for ${record.code} line ${line.sequence}. Check period lock or duplicate document.`); return false; }
    }
    const updated = schedules.map((s) => s.id === line.id ? { ...s, status: 'posted' as const, docNo, postedAt: new Date().toISOString() } : s);
    setSchedules(updated);
    const remaining = updated.filter((s) => s.prepaymentId === record.id && s.status === 'scheduled').length;
    if (remaining === 0) setRecords((prev) => prev.map((r) => r.id === record.id ? { ...r, status: 'fully_amortised' as const } : r));
    return true;
  };

  const postDueForRecord = (record: PrepaymentRecord) => {
    if (restricted) return setFeedback('Posting blocked: this user cannot post journals.');
    if (isPeriodClosed) return setFeedback('Posting blocked: the accounting period is closed.');
    const due = schedules
      .filter((s) => s.prepaymentId === record.id && s.status === 'scheduled' && s.period <= runPeriod)
      .sort((a, b) => a.sequence - b.sequence);
    if (!due.length) return setFeedback(`No due recognition lines for ${record.code} through ${runPeriod}.`);
    let posted = 0;
    for (const line of due) {
      if (postScheduleLine(record, line)) posted += 1;
      else break;
    }
    if (posted) setFeedback(`Posted ${posted} recognition line(s) for ${record.code} through ${runPeriod}.`);
  };

  const postAllDue = () => {
    if (restricted) return setFeedback('Posting blocked: this user cannot post journals.');
    if (isPeriodClosed) return setFeedback('Posting blocked: the accounting period is closed.');
    let posted = 0;
    for (const { record, summary } of allSummaries) {
      for (const line of summary.dueLines) {
        if (postScheduleLine(record, line)) posted += 1;
      }
    }
    setFeedback(posted ? `Posted ${posted} due prepayment recognition line(s) through ${runPeriod}.` : `No due recognition lines through ${runPeriod}.`);
  };

  const updateScheduleAmount = (line: PrepaymentScheduleLine, amount: number) => {
    if (!selectedRecord || line.status === 'posted') return;
    const updatedForRecord = recalcBalances(
      selectedRecord,
      schedules.filter((s) => s.prepaymentId === selectedRecord.id).map((s) => s.id === line.id ? { ...s, amount: round2(amount || 0) } : s),
    );
    const byId = new Map(updatedForRecord.map((s) => [s.id, s]));
    setSchedules((prev) => prev.map((s) => byId.get(s.id) || s));
  };

  const rebalanceLastLine = () => {
    if (!selectedRecord) return;
    const recordSchedule = schedules.filter((s) => s.prepaymentId === selectedRecord.id).sort((a, b) => a.sequence - b.sequence);
    const scheduled = recordSchedule.filter((s) => s.status === 'scheduled');
    if (!scheduled.length) return;
    const last = scheduled[scheduled.length - 1];
    const others = recordSchedule.filter((s) => s.id !== last.id).reduce((n, s) => n + s.amount, 0);
    const adjusted = round2(selectedRecord.totalAmount - others);
    if (adjusted < 0) return setFeedback('Cannot rebalance: earlier lines already exceed the prepayment total.');
    updateScheduleAmount(last, adjusted);
    setFeedback('Final scheduled line rebalanced to the prepayment total.');
  };

  const cancelRecord = (record: PrepaymentRecord) => {
    const hasPosted = schedules.some((s) => s.prepaymentId === record.id && s.status === 'posted');
    if (hasPosted || record.source !== 'opening_balance') {
      return setFeedback('Only an opening-balance prepayment with no posted recognition can be cancelled here. Posted records require a reversal journal.');
    }
    setRecords((prev) => prev.map((r) => r.id === record.id ? { ...r, status: 'cancelled' as const } : r));
    setFeedback(`Prepayment ${record.code} cancelled.`);
  };

  const exportCsv = () => {
    if (!selectedRecord) return;
    let csv = `Prepayment Schedule,${selectedRecord.code},${selectedRecord.title}\n`;
    csv += `Sequence,Period,RecognitionDate,OpeningBalance,Amount,ClosingBalance,Status,DocNo\n`;
    selectedSchedule.forEach((l) => {
      csv += `${l.sequence},${l.period},${l.recognitionDate},${l.openingBalance},${l.amount},${l.closingBalance},${l.status},${l.docNo || ''}\n`;
    });
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${currentClient.code}_${selectedRecord.code}_Prepayment_Schedule.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const ledgerBalanceForSelected = selectedRecord
    ? lines
      .filter((l) => l.clientId === currentClient.id && l.accountNo === selectedRecord.prepaidAccountNo && l.docNo.startsWith(selectedRecord.code))
      .reduce((n, l) => n + l.debit - l.credit, 0)
    : 0;
  const ledgerVariance = selectedRecord && selectedSummary ? round2(ledgerBalanceForSelected - selectedSummary.unrecognized) : 0;

  return (
    <div className="space-y-6">
      <PageHeader
        kicker={`PRE · Prepayments & Deferred Charges · ${currentClient.code}`}
        title="Prepayment Schedules & Amortisation"
        desc="Create prepaid assets, generate monthly recognition schedules, post due amortisation to the journal, and reconcile the remaining balance to GL 116000."
      >
        <button onClick={openCreate} disabled={restricted} className="flex items-center gap-1.5 rounded-lg bg-[#082f4f] px-3.5 py-2 text-xs font-bold text-white hover:bg-[#0c3f68] transition shadow-xs disabled:opacity-40">
          <Plus className="h-4 w-4" /> New Prepayment
        </button>
      </PageHeader>

      {feedback && <div className={`rounded-lg border p-3 text-xs font-bold ${feedback.includes('blocked') || feedback.includes('required') || feedback.includes('rejected') || feedback.includes('does not') || feedback.includes('Cannot') ? 'border-rose-300 bg-rose-50 text-rose-900' : 'border-emerald-300 bg-emerald-50 text-emerald-900'}`}>{feedback}</div>}

      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        <Stat label="Active prepayments" value={clientRecords.filter(r => r.status === 'active').length} sub={`${clientRecords.length} records in workspace`} />
        <Stat label="Original prepaid amount" value={`₵${formatGHS(totalOriginal)}`} sub="All active and completed schedules" />
        <Stat label="Recognised to date" value={`₵${formatGHS(totalRecognized)}`} tone="text-emerald-700" sub="Posted amortisation" />
        <Stat label={`Due through ${runPeriod}`} value={`₵${formatGHS(totalDue)}`} tone="text-rose-700" sub={`Unrecognised balance ₵${formatGHS(totalUnrecognized)}` } />
      </div>

      <div className="rounded-xl border border-sky-200 bg-white p-4 shadow-xs flex flex-wrap items-end justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-end gap-3">
          <label className="font-bold text-[#355875]">Run period
            <input type="month" value={runPeriod} onChange={(e) => setRunPeriod(e.target.value)} className="block mt-1 rounded border border-sky-300 p-2 font-mono" />
          </label>
          <label className="font-bold text-[#355875]">Status
            <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value as typeof statusFilter)} className="block mt-1 rounded border border-sky-300 p-2 font-semibold">
              <option value="all">All statuses</option><option value="active">Active</option><option value="fully_amortised">Fully amortised</option><option value="cancelled">Cancelled</option>
            </select>
          </label>
          <label className="font-bold text-[#355875]">Search
            <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Code, title, vendor..." className="block mt-1 w-56 rounded border border-sky-300 p-2" />
          </label>
        </div>
        <button onClick={postAllDue} disabled={restricted || isPeriodClosed} className="rounded-lg bg-emerald-700 px-4 py-2 font-bold text-white hover:bg-emerald-800 disabled:opacity-40 flex items-center gap-1.5">
          <Play className="h-3.5 w-3.5" /> Post all due through {runPeriod}
        </button>
      </div>

      <Card title="Prepayment register" sub="Select a record to view and post its recognition schedule">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[980px] text-xs">
            <thead><tr className="border-b border-sky-200 bg-sky-50/70">
              <th className={thCls}>Code</th><th className={thCls}>Prepayment</th><th className={thCls}>Vendor</th><th className={thCls}>Benefit period</th>
              <th className={thCls + ' text-right'}>Total</th><th className={thCls + ' text-right'}>Recognised</th><th className={thCls + ' text-right'}>Unrecognised</th>
              <th className={thCls + ' text-right'}>Progress</th><th className={thCls}>Status</th><th className={thCls + ' text-center'}>Action</th>
            </tr></thead>
            <tbody>
              {filteredRecords.length === 0 ? (
                <tr><td colSpan={10} className="px-3 py-8 text-center text-[#355875]">No prepayments match the current filter. Create a new prepayment to generate its schedule.</td></tr>
              ) : filteredRecords.map(({ record, summary }) => (
                <tr key={record.id} className={`${rowCls} ${selectedRecord?.id === record.id ? 'bg-sky-50' : ''}`}>
                  <td className="px-3 py-2 font-mono font-bold text-[#855b00]">{record.code}</td>
                  <td className="px-3 py-2"><strong className="text-[#082f4f]">{record.title}</strong><div className="text-[10px] text-[#355875]">{record.category} · {record.method === 'straight_line' ? 'Straight-line' : 'Daily pro-rata'}</div></td>
                  <td className="px-3 py-2">{record.vendorName}</td>
                  <td className="px-3 py-2 font-mono text-[11px]">{record.benefitStart} → {record.benefitEnd}</td>
                  <td className={numCls}>{formatGHS(record.totalAmount)}</td>
                  <td className={numCls + ' text-emerald-700'}>{formatGHS(summary.recognized)}</td>
                  <td className={numCls + ' font-bold'}>{formatGHS(summary.unrecognized)}</td>
                  <td className={numCls}>{summary.percentRecognized}%</td>
                  <td className="px-3 py-2"><span className={`rounded px-2 py-0.5 text-[10px] font-bold ${record.status === 'active' ? 'bg-sky-100 text-[#006f98]' : record.status === 'fully_amortised' ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'}`}>{record.status.replace('_', ' ')}</span></td>
                  <td className="px-3 py-2 text-center"><button onClick={() => setSelectedId(record.id)} className="rounded bg-[#082f4f] px-2.5 py-1 text-[11px] font-bold text-white">Schedule</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {selectedRecord && selectedSummary && (
        <Card
          title={`Recognition schedule — ${selectedRecord.code} · ${selectedRecord.title}`}
          sub={`${selectedRecord.prepaidAccountNo} → ${selectedRecord.expenseAccountNo} · ${selectedRecord.costCenter} · ${selectedRecord.termMonths} months`}
          action={<div className="flex gap-2">
            <button onClick={exportCsv} className="rounded border border-sky-300 bg-white px-3 py-1.5 text-xs font-bold text-[#082f4f] flex items-center gap-1.5"><Download className="h-3.5 w-3.5" /> Export CSV</button>
            <button onClick={() => window.print()} className="rounded border border-sky-300 bg-white px-3 py-1.5 text-xs font-bold text-[#082f4f] flex items-center gap-1.5"><Printer className="h-3.5 w-3.5" /> Print</button>
            <button onClick={() => postDueForRecord(selectedRecord)} disabled={restricted || isPeriodClosed || selectedRecord.status !== 'active'} className="rounded bg-emerald-700 px-3 py-1.5 text-xs font-bold text-white disabled:opacity-40">Post due lines</button>
          </div>}
        >
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-4 text-xs">
            <div className="rounded-lg bg-sky-50 border border-sky-200 p-3"><span className="text-[#355875] font-bold block">Schedule unrecognised</span><strong className="font-mono text-base text-[#082f4f]">₵{formatGHS(selectedSummary.unrecognized)}</strong></div>
            <div className="rounded-lg bg-sky-50 border border-sky-200 p-3"><span className="text-[#355875] font-bold block">Ledger balance for record</span><strong className="font-mono text-base text-[#082f4f]">₵{formatGHS(ledgerBalanceForSelected)}</strong></div>
            <div className={`rounded-lg border p-3 ${Math.abs(ledgerVariance) < 0.01 ? 'bg-emerald-50 border-emerald-200' : 'bg-amber-50 border-amber-300'}`}><span className="text-[#355875] font-bold block">Reconciliation variance</span><strong className={`font-mono text-base ${Math.abs(ledgerVariance) < 0.01 ? 'text-emerald-800' : 'text-amber-800'}`}>₵{formatGHS(ledgerVariance)}</strong></div>
            <div className="rounded-lg bg-sky-50 border border-sky-200 p-3"><span className="text-[#355875] font-bold block">Next due</span><strong className="font-mono text-base text-[#082f4f]">{selectedSummary.nextLine ? `${selectedSummary.nextLine.period} · ₵${formatGHS(selectedSummary.nextLine.amount)}` : 'Complete'}</strong></div>
          </div>

          {selectedSummary.scheduleVariance !== 0 && (
            <div className="mb-3 rounded-lg border border-amber-300 bg-amber-50 p-3 text-xs text-amber-900 flex flex-wrap items-center justify-between gap-2">
              <span>Schedule total differs from the prepayment amount by ₵{formatGHS(selectedSummary.scheduleVariance)}. Posting is blocked until it reconciles.</span>
              <button onClick={rebalanceLastLine} className="rounded bg-amber-600 px-3 py-1.5 font-bold text-white">Rebalance final line</button>
            </div>
          )}

          <div className="overflow-x-auto">
            <table className="w-full min-w-[900px] text-xs">
              <thead><tr className="border-b border-sky-200 bg-sky-50/70">
                <th className={thCls}>#</th><th className={thCls}>Period</th><th className={thCls}>Recognition date</th>
                <th className={thCls + ' text-right'}>Opening</th><th className={thCls + ' text-right'}>Amortisation</th><th className={thCls + ' text-right'}>Closing</th>
                <th className={thCls}>Status</th><th className={thCls}>Journal</th><th className={thCls + ' text-center'}>Action</th>
              </tr></thead>
              <tbody>
                {selectedSchedule.map((line) => {
                  const due = line.status === 'scheduled' && line.period <= runPeriod;
                  return (
                    <tr key={line.id} className={rowCls}>
                      <td className="px-3 py-2 font-mono">{line.sequence}</td>
                      <td className="px-3 py-2 font-mono font-bold">{line.period}</td>
                      <td className="px-3 py-2 font-mono">{line.recognitionDate}</td>
                      <td className={numCls}>{formatGHS(line.openingBalance)}</td>
                      <td className="px-3 py-1 text-right">
                        <input type="number" min="0" step="0.01" value={line.amount || ''} disabled={line.status === 'posted'} onChange={(e) => updateScheduleAmount(line, Number(e.target.value))} className="w-28 rounded border border-sky-200 px-2 py-1 text-right font-mono disabled:bg-slate-50 disabled:text-slate-400" />
                      </td>
                      <td className={numCls}>{formatGHS(line.closingBalance)}</td>
                      <td className="px-3 py-2"><span className={`rounded px-2 py-0.5 text-[10px] font-bold ${line.status === 'posted' ? 'bg-emerald-100 text-emerald-800' : due ? 'bg-amber-100 text-amber-800' : 'bg-sky-100 text-[#006f98]'}`}>{line.status === 'posted' ? 'Posted' : due ? 'Due' : 'Scheduled'}</span></td>
                      <td className="px-3 py-2 font-mono text-[11px]">{line.docNo || '—'}</td>
                      <td className="px-3 py-2 text-center">
                        {line.status === 'scheduled' && <button onClick={() => postScheduleLine(selectedRecord, line)} disabled={!due || restricted || isPeriodClosed || selectedRecord.status !== 'active'} className="rounded bg-[#082f4f] px-2.5 py-1 text-[11px] font-bold text-white disabled:opacity-40">Post</button>}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <div className="mt-4 flex flex-wrap justify-between gap-2 border-t border-sky-100 pt-3">
            <span className="text-[11px] text-[#355875]">Recognition posts <strong>Dr {selectedRecord.expenseAccountNo} {selectedRecord.expenseAccountName}</strong> / <strong>Cr {selectedRecord.prepaidAccountNo} {selectedRecord.prepaidAccountName}</strong>.</span>
            <button onClick={() => cancelRecord(selectedRecord)} className="text-xs font-bold text-rose-700 hover:underline">Cancel opening-balance record</button>
          </div>
        </Card>
      )}

      {showCreate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 overflow-y-auto">
          <form onSubmit={handleCreate} className="w-full max-w-2xl rounded-xl border border-sky-300 bg-white p-6 shadow-xl space-y-4 text-xs my-6">
            <div className="flex items-center justify-between border-b border-sky-100 pb-2">
              <h3 className="text-base font-bold text-[#082f4f]">Create Prepayment & Schedule</h3>
              <button type="button" onClick={() => setShowCreate(false)}><X className="h-5 w-5 text-slate-400" /></button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <label className="font-bold text-[#355875]">Prepayment code
                <input value={code} onChange={(e) => setCode(e.target.value)} className="mt-1 w-full rounded border border-sky-300 p-2 font-mono" required />
              </label>
              <label className="font-bold text-[#355875]">Category
                <select value={category} onChange={(e) => setCategory(e.target.value as PrepaymentCategory)} className="mt-1 w-full rounded border border-sky-300 p-2">
                  {CATEGORIES.map((c) => <option key={c}>{c}</option>)}
                </select>
              </label>
            </div>

            <label className="block font-bold text-[#355875]">Description / title
              <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Annual insurance premium" className="mt-1 w-full rounded border border-sky-300 p-2" required />
            </label>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <label className="font-bold text-[#355875]">Vendor / supplier
                {partners.filter((p) => p.type === 'Vendor').length ? (
                  <select value={vendorName} onChange={(e) => setVendorName(e.target.value)} className="mt-1 w-full rounded border border-sky-300 p-2">
                    <option value="">Select vendor</option>
                    {partners.filter((p) => p.type === 'Vendor').map((p) => <option key={p.id} value={p.name}>{p.code} · {p.name}</option>)}
                  </select>
                ) : <input value={vendorName} onChange={(e) => setVendorName(e.target.value)} className="mt-1 w-full rounded border border-sky-300 p-2" required />}
              </label>
              <label className="font-bold text-[#355875]">Source document / reference
                <input value={reference} onChange={(e) => setReference(e.target.value)} placeholder="Invoice, policy or lease ref" className="mt-1 w-full rounded border border-sky-300 p-2" />
              </label>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <label className="font-bold text-[#355875]">Payment date
                <input type="date" value={paymentDate} onChange={(e) => setPaymentDate(e.target.value)} className="mt-1 w-full rounded border border-sky-300 p-2" required />
              </label>
              <label className="font-bold text-[#355875]">Benefit starts
                <input type="date" value={benefitStart} onChange={(e) => setBenefitStart(e.target.value)} className="mt-1 w-full rounded border border-sky-300 p-2" required />
              </label>
              <label className="font-bold text-[#355875]">Term (months)
                <input type="number" min="1" max="240" step="1" value={termMonths} onChange={(e) => setTermMonths(Number(e.target.value))} className="mt-1 w-full rounded border border-sky-300 p-2 font-mono" required />
              </label>
              <label className="font-bold text-[#355875]">Total amount
                <input type="number" min="0" step="0.01" value={totalAmount || ''} onChange={(e) => setTotalAmount(Number(e.target.value))} className="mt-1 w-full rounded border border-sky-300 p-2 font-mono" required />
              </label>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <label className="font-bold text-[#355875]">Recognition method
                <select value={method} onChange={(e) => setMethod(e.target.value as PrepaymentMethod)} className="mt-1 w-full rounded border border-sky-300 p-2">
                  <option value="straight_line">Straight-line monthly</option>
                  <option value="daily_prorata">Daily pro-rata</option>
                </select>
              </label>
              <label className="font-bold text-[#355875]">Cost centre
                <input value={costCenter} onChange={(e) => setCostCenter(e.target.value)} className="mt-1 w-full rounded border border-sky-300 p-2 font-mono" required />
              </label>
              <label className="font-bold text-[#355875]">Prepaid asset GL
                <select value={prepaidAccountNo} onChange={(e) => setPrepaidAccountNo(e.target.value)} className="mt-1 w-full rounded border border-sky-300 p-2">
                  {prepaidOptions.map((a) => <option key={a.accountNo} value={a.accountNo}>{a.accountNo} · {a.name}</option>)}
                </select>
              </label>
              <label className="font-bold text-[#355875]">Expense GL on recognition
                <select value={expenseAccountNo} onChange={(e) => setExpenseAccountNo(e.target.value)} className="mt-1 w-full rounded border border-sky-300 p-2">
                  {expenseOptions.map((a) => <option key={a.accountNo} value={a.accountNo}>{a.accountNo} · {a.name}</option>)}
                </select>
              </label>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <label className="font-bold text-[#355875]">How was it settled?
                <select value={source} onChange={(e) => setSource(e.target.value as PrepaymentSource)} className="mt-1 w-full rounded border border-sky-300 p-2">
                  <option value="bank">Paid from bank/cash now</option>
                  <option value="supplier_payable">Supplier invoice payable</option>
                  <option value="opening_balance">Already in opening balances</option>
                </select>
              </label>
              {source === 'bank' && (
                <label className="font-bold text-[#355875]">Payment account
                  <select value={sourceBankId} onChange={(e) => setSourceBankId(Number(e.target.value))} className="mt-1 w-full rounded border border-sky-300 p-2">
                    {bankAccounts.map((b) => <option key={b.id} value={b.id}>{b.name} · {formatGHS(b.balance)}</option>)}
                  </select>
                </label>
              )}
            </div>

            <label className="block font-bold text-[#355875]">Notes
              <input value={note} onChange={(e) => setNote(e.target.value)} className="mt-1 w-full rounded border border-sky-300 p-2" placeholder="Optional operational note" />
            </label>

            <div className="rounded-lg bg-sky-50 border border-sky-200 p-3 grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
              <div><span className="block text-[10px] uppercase font-bold text-[#355875]">Benefit ends</span><strong className="font-mono">{benefitEndDate(benefitStart, termMonths)}</strong></div>
              <div><span className="block text-[10px] uppercase font-bold text-[#355875]">Schedule lines</span><strong className="font-mono">{previewSchedule.length}</strong></div>
              <div><span className="block text-[10px] uppercase font-bold text-[#355875]">First amount</span><strong className="font-mono">₵{formatGHS(previewSchedule[0]?.amount || 0)}</strong></div>
              <div><span className="block text-[10px] uppercase font-bold text-[#355875]">Schedule total</span><strong className="font-mono">₵{formatGHS(previewSchedule.reduce((n, l) => n + l.amount, 0))}</strong></div>
            </div>

            <div className="flex justify-end gap-2 border-t border-sky-100 pt-3">
              <button type="button" onClick={() => setShowCreate(false)} className="rounded px-4 py-2 font-semibold text-[#2d4f6d]">Cancel</button>
              <button type="submit" className="rounded bg-[#082f4f] px-4 py-2 font-bold text-white flex items-center gap-1.5"><Save className="h-3.5 w-3.5" /> Create & generate schedule</button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
