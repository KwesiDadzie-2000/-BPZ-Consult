# BPZ Consult ERP — production readiness

## Current state: production-grade data layer

The system now runs on **PostgreSQL via Drizzle ORM** with an authenticated,
tenant-enforced API — the books, master data and credentials are server-side.

- **Database:** full schema in `src/db/schema.ts` (users, sessions, clients, journal
  lines, treasury, orders, invoices, employees, profiles, chart of accounts, partners,
  payroll, prepayments, approvals, disclosures, closed periods, audit log).
  Seeded by `npx tsx src/db/seed.ts` (schema via `npx drizzle-kit push`).
- **Authentication:** `POST /api/auth/login` verifies SHA-256 + per-user salt
  (never plaintext); sessions are revocable Bearer tokens with an 8-hour TTL that
  slides forward on every authenticated request (a working day never loses the
  session mid-task); server-side failed-attempt lockout. Owner user management
  hashes passwords server-side (`PUT /api/users`).
- **Tenant enforcement:** every API read and write is session-scoped. The owner
  receives all entities' data; other users receive only their own entity's rows
  (plus the firm chart master and their own custom accounts). Cross-tenant writes
  are rejected with 403.
- **Server-side posting service:** `POST /api/journal` validates tenant ownership,
  open periods, chart-of-accounts existence, non-negative amounts and per-document
  double entry in minor units, rejects duplicate/conflicting documents
  (idempotent re-sends allowed), and inserts with an audit-trail entry in one
  transaction. `PUT /api/state` is the validated, transactional full-state sync
  (partial payloads rejected; new documents audit-logged).
- **Per-entity, per-period close:** closed periods are stored per entity; posting
  into a closed period is rejected client- and server-side.
- The browser keeps a localStorage cache for instant paint; the server is
  authoritative and hydrates the workspace on login.

## Audit rectifications delivered (all revisions)

- Chart of accounts expanded and scrutinised (201 accounts); spendable ledgers
  tailored to every Ghanaian economic sector; unknown-GL posting rejected.
- Cash separated from bank (own GLs, treasury `kind` + `glAccount` mapping,
  separate opening balances, GL tie-out surfaced at the banking desk).
- Each entity owns its trial balance (per-entity opening schedules, per-entity TB,
  owner report-entity switcher, per-entity balance proof strip).
- Owner sets the fiscal year for all entities; reports measure from it.
- GRA 2026 indirect tax: VAT 15% + NHIL 2.5% + GETFund 2.5%; CST 5% cascades into
  the VAT base (Act 1151 s.15.3) and is optional with Class-1 confirmation;
  Tourism Levy 1% optional for hospitality; VAT withholding fixed at 7% of
  taxable value; full Act 896 WHT schedule (resident + non-resident) captured;
  resident professional fees at the current 7.5% services rate.
- Vendor VAT treatments on POs (standard / VAT-inclusive / non-VAT / zero-rated)
  with quotation references; expenses split recoverable input VAT; customer VAT
  withholding at source settles via WHT receivable; WHT base always the
  VAT-exclusive consideration.
- Hidden defects fixed: seeded depreciation now credits accumulated depreciation;
  payroll journals record the real maker/checker; payroll persistence merges;
  expense/asset/inventory postings update treasury and stock consistently; stock
  adjustments post to the GL; orphaned seed assets/timesheets wired in; duplicate
  IAS 12 removed; COA badge reflects account state; opening-balance posting honours
  rejection; IFRS/loan journals record the acting user.
- Missing links implemented: IAS 7 cash flow (residual-proven), IAS 1 statement of
  changes in equity, cost-centre P&L, AR/AP aging, bank statement CSV import with
  auto-match reconciliation, IAS 21 FX revaluation with postable journals, CIT
  working paper with postable provision, credit notes (sales returns), debit notes
  (purchase returns), fixed-asset depreciation run and disposal, computed
  consolidated trial balance, per-entity COA scoping.

## Remaining before external audit / big-firm procurement

1. **MFA and password policy** on top of the hashed-credential login; SSO/SAML
   (the desk exists as a mock) for enterprise rollout.
2. **Off-site encrypted backups, automated restore drills, monitoring and an
   audit trail replica** outside the primary database; alerting on failed syncs.
3. ~~**Approval-to-posting loop**~~ — **delivered:** requests carry their proposed
   journal lines (`payload`); approval posts them exactly once with the approver
   as the independent checker, and every resolution is audit-logged.
4. **Subledger depth:** 3-way match (PO → GRN → invoice), vendor bill entry,
   customer/supplier statements, dunning, AR/AP netting, inventory cost layers.
5. **IFRS engines:** IFRS 16 lease calculator, IFRS 15 POC revenue engine,
   IAS 12 deferred tax computation, IAS 21 translation for consolidation.
6. **Multi-currency presentation:** rate table, entity-currency report labels,
   translation at consolidation.
7. **Compliance integrations:** GRA e-filing/CIS-FED invoicing, SSNIT remittance
   files, bank payment files (ACH/ISO 20022), positive pay, bank feeds.
8. **Scale hardening:** pagination/cursor APIs (the sync is full-state),
   database-backed rate limiting, row-level security in Postgres, component tests.

## Correction controls release — real-books error prevention

- **Immutable counter-reversals:** every posted document can be reversed once.
  The reversal (`REV-<docNo>`) posts to the CURRENT period (a frozen period can
  never be amended), mirrors every line, references the original, and the
  original is flagged REVERSED in the ledger — double reversal is impossible.
  Fixes the previous bug where reversals posted into the selected (wrong)
  period and never marked the original.
- **Segregation of duties (server-enforced):** a document above the maker's
  threshold must carry an independent checker; self-checking above the limit —
  or posting above it unchecked — is rejected at the API. Within the limit the
  maker may self-certify, matching standard maker/checker policy.
- **Approval queue posts:** approving a request with proposed lines posts them
  (approver = checker of record); the decision and the posting are audit events.
- **Audit trail:** `GET /api/audit` (tenant-scoped; owner sees all) and the
  Universal Journal desk now show the server's immutable control history —
  postings, period freezes/reopens, reversals and approval resolutions.
- **Year-end close:** Month-End Close now posts `YE-CLOSE-<year>` — one balanced
  document zeroing every P/L account's fiscal-year balance into Retained
  Earnings (310000), with profit/loss preview before posting.

## System audit — 2026 statutory payroll and entity-isolation release

- **Payroll brought to the official SSNIT/GRA model.** The combined mandatory
  contribution is 18.5% of **basic salary** (2026 insurable band GHS 587.80 –
  69,000): 5.5% employee deduction + 13% employer cost. Remittance split of the
  18.5%: 13.5% to SSNIT Tier 1 (of which 2.5% is forwarded to NHIA) and the
  **mandatory 5% Tier 2** to the worker's occupational trustee — funded inside
  the 18.5%, never an additional deduction. The previous build computed SSNIT on
  gross pay, deducted an extra 5% "Tier 2" from the worker and mislabelled the
  13% employer line as Tier 2. PAYE uses the GRA Act 1178 (2026) graduated bands;
  the payslip, register, CSV export, statutory panel and the payroll journal
  (510000 / 511000 / 205000 / 206000 / 207000 / 208000) all reflect the model,
  and a one-time migration re-derives any payslip saved under the old model.
- **Client workspaces show only their own information.** Non-owner users are
  hard-bound to their assigned entity at the data layer (bootstrap, state sync,
  posting) and at the UI layer (no group switcher, no cross-entity report
  scope, per-entity trial-balance strip is owner-only). An account whose entity
  is missing sees an explicit "no workspace assigned" state instead of another
  client's books.
- **Nothing fails silently.** Every rejected server operation (expired session,
  cross-tenant write, frozen period, conflicting document, unreachable server)
  is surfaced in a dismissible "System notices" strip; local posts that the
  server rejects are rolled back.
- **Opening balances:** posted schedules are locked and shown as "Verified In
  Books" (corrections via adjusting entries), the post button names the exact
  blocker (already-in-journal / frozen period / Dr ≠ Cr) and shows the per-entity
  frozen-period warning inline.
- **Hidden defects fixed by the audit:** period freezes are per entity (closing
  one client's period no longer blocks another's posting); full-state sync no
  longer re-validates already-posted documents against closed periods (which
  previously made a period impossible to reopen); the owner's sync now replaces
  the whole workspace so legacy rows cannot cause primary-key collisions; the
  seed now tags every legacy row to its owning client; journal idempotency
  rejects supersets of a posted document with 409 instead of a key collision;
  stale "browser only / 30-minute session" copy corrected.
- **Test coverage:** 67 regression tests including a standard transaction set
  per industry (mining, agribusiness, UK logistics), statutory payroll checks,
  per-entity freeze/isolation proofs, and legacy-record migration; plus a live
  23-check API E2E (auth, tenant isolation, posting, idempotency, conflict,
  freeze/reopen, RBAC) run against the production build.

`npm run build` and `node --import tsx --test tests/*.test.ts` verify the build
and the accounting/audit regression suites.

## Payment-desk workflow hardening (this release)

- **Single point of disbursement.** The Expenses & Statutory desk now RECORDS
  obligations only: every expense bill posts Dr expense (+ recoverable input
  VAT) / Cr 202000 Accrued Expenses & Other Payables. Direct bank payments from
  that desk were removed. All payments — supplier invoices, expense bills,
  statutory remittances and payroll release — are effected exclusively at the
  Payment Desk (Dr payable / Cr bank-cash), with full/partial settlement,
  payment vouchers, period locks and maker-checker limits.
- **Instant statutory payables after payroll posting.** Posting payroll credits
  PAYE (207000), SSNIT Tier 1 13.5% incl. NHIA (206000) and the mandatory Tier 2
  5% (new GL 206100) as separate payables. They appear immediately in the live
  statutory register on BOTH the Expenses & Statutory desk and the Payment
  Desk, with the authority, statutory due date (PAYE 15th, SSNIT/Tier 2 14th)
  and one-click remittance. Balances are derived from the ledger, so the
  register can never drift from the books.
- **Approvals now effect payments.** Above-maker-limit payments queue with the
  proposed journal AND settlement metadata; on independent approval the journal
  posts, the treasury balance moves and the supplier/customer document is
  settled — previously an approved payment request never actually moved money.
- **Other fixes:** Payment Desk now honours the closed-period lock (prop was
  never passed); duplicate payment references on partial settlements get unique
  document numbers instead of being rejected; salary release is capped at the
  live 205000 balance and posts in the open period; expense period summary shows
  debits and credits (accruals vs settlements) instead of a misleading
  debit-only figure; AP aging includes recorded expense bills; tax
  reconciliation shows Tier 1 and Tier 2 separately.
- **New regression suite:** `tests/payment-workflow.test.ts` proves accrual →
  partial → full settlement, reversal handling, instant PAYE/Tier 1/Tier 2
  payable registration, remittance balance reduction and entity isolation.
