import type { ClientEntity, UserAccount } from '../types/accounting';

// UI-level scoping for the demo. The production API must independently enforce every rule.
export const serviceForSection: Record<string, string> = {
  procurement: 'bookkeeping', sales: 'bookkeeping', business_partners: 'bookkeeping',
  payment_desk: 'bookkeeping', banking: 'bookkeeping', expenses: 'bookkeeping',
  inventory: 'bookkeeping', assets: 'bookkeeping', prepayments: 'management_accounts', payroll: 'payroll',
  tax_schedule: 'tax_compliance', coa_master: 'management_accounts',
  universal_journal: 'management_accounts', manual_journal: 'management_accounts',
  opening_balance: 'management_accounts', month_end: 'management_accounts',
  financial_reports: 'management_accounts', standards_desk: 'ifrs_reporting',
  loans_desk: 'ifrs_reporting', disclosures: 'ifrs_reporting',
};

export const maySeeSection = (user: UserAccount, client: ClientEntity, section: string) => {
  if (user.role === 'owner') return true;
  if (user.clientId && user.clientId !== client.id) return false;
  if (user.status === 'restricted' || user.status === 'suspended') return false;
  const service = serviceForSection[section];
  if (service && client.assignedServices && !client.assignedServices.includes(service)) return false;
  if (section === 'payroll' && user.permissions?.canRunPayroll === false) return false;
  if (section === 'month_end' && user.permissions?.canClosePeriod === false) return false;
  if (section === 'coa_master' && user.permissions?.canModifyCOA === false) return false;
  return true;
};
/**
 * Firm-wide data scope: the owner plus firm-level partner/manager accounts that
 * are not bound to a client entity. Shared by the API (tenant filtering) and the
 * UI (entity switcher) so both apply exactly the same rule.
 */
export function hasFirmWideScope(user: { role: string; clientId?: number | null }): boolean {
  if (user.role === 'owner') return true;
  return (user.clientId === undefined || user.clientId === null) && (user.role === 'partner' || user.role === 'manager');
}
