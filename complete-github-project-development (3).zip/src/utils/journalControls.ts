import type { ACDOCALine, AccountMaster } from '../types/accounting';

const round2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;

/**
 * Builds the immutable counter-reversal document for a posted document.
 * Reversals post to the CURRENT period (never the frozen original period),
 * mirror every line (Dr ↔ Cr), reference the original document number and are
 * flagged as reversal lines. A document may only be reversed once — the caller
 * must confirm no `REV-<docNo>` exists yet and mark the original isReversed.
 */
export function buildReversalLines(
  original: ACDOCALine[],
  opts: { username: string; canCheck: boolean; period: string; date: string }
): ACDOCALine[] {
  if (!original.length) return [];
  const docNo = original[0].docNo;
  return original.map((orig, i) => ({
    id: `JL-REV-${opts.date.replace(/-/g, '')}-${i}`,
    docNo: `REV-${docNo}`,
    period: opts.period,
    date: opts.date,
    module: orig.module,
    docType: 'REV',
    accountNo: orig.accountNo,
    accountName: orig.accountName,
    costCenter: orig.costCenter,
    debit: orig.credit,
    credit: orig.debit,
    currency: orig.currency,
    description: `Reversal of ${docNo}: ${orig.description}`,
    createdBy: opts.username,
    checkedBy: opts.canCheck ? opts.username : undefined,
    clientId: orig.clientId,
    isReversed: true,
    reference: docNo,
  }));
}

export interface YearEndCloseResult {
  lines: ACDOCALine[];
  /** Profit (positive) or loss (negative) transferred to retained earnings. */
  net: number;
  /** P/L account codes with non-zero year balances. */
  accountsClosed: string[];
}

/**
 * Year-end close: zero every Income/Expense account's fiscal-year balance into
 * Retained Earnings (310000). One line per account with a non-zero balance plus
 * the retained-earnings offset — the document always balances by construction.
 * Returns null when there is nothing to close (no P/L activity or net = 0).
 */
export function buildYearEndCloseEntries(
  yearLines: ACDOCALine[],
  accounts: AccountMaster[],
  opts: { year: number; period: string; date: string; currency: string; username: string; canCheck: boolean; clientId: number }
): YearEndCloseResult | null {
  const balances = new Map<string, number>(); // positive = debit balance, negative = credit
  for (const l of yearLines) {
    balances.set(l.accountNo, (balances.get(l.accountNo) ?? 0) + l.debit - l.credit);
  }
  const typeOf = (code: string) => accounts.find((a) => a.accountNo === code)?.type;
  const pl = [...balances.entries()]
    .filter(([code, bal]) => Math.abs(bal) >= 0.005 && (typeOf(code) === 'Income' || typeOf(code) === 'Expense'))
    .map(([code, bal]) => ({ code, bal, name: accounts.find((a) => a.accountNo === code)?.name || 'P/L account' }));

  if (!pl.length) return null;
  // Retained-earnings offset: income accounts carry credit balances (negative bal)
  // and must be debited; expense accounts carry debit balances (positive bal) and
  // must be credited. The RE line absorbs the remainder so Dr = Cr exactly.
  const reOffset = round2(pl.reduce((s, p) => s + p.bal, 0));
  if (Math.abs(reOffset) < 0.005) return null;

  const base = {
    docNo: `YE-CLOSE-${opts.year}`,
    period: opts.period,
    date: opts.date,
    module: 'FI' as const,
    docType: 'JE' as const,
    costCenter: 'CC-ADM' as const,
    currency: opts.currency,
    createdBy: opts.username,
    checkedBy: opts.canCheck ? opts.username : undefined,
    clientId: opts.clientId,
    reference: `Fiscal year ${opts.year} close`,
  };

  const lines: ACDOCALine[] = pl.map((p, i) => ({
    ...base,
    id: `JL-YE-${opts.year}-${i}`,
    accountNo: p.code,
    accountName: p.name,
    debit: p.bal < 0 ? round2(-p.bal) : 0,
    credit: p.bal > 0 ? round2(p.bal) : 0,
    description: `Year-end close ${opts.year}: clear ${p.name}`,
  }));
  lines.push({
    ...base,
    id: `JL-YE-${opts.year}-RE`,
    accountNo: '310000',
    accountName: 'Retained Earnings',
    debit: reOffset > 0 ? round2(reOffset) : 0,
    credit: reOffset < 0 ? round2(-reOffset) : 0,
    description: `Year-end close ${opts.year}: transfer ${reOffset >= 0 ? 'profit' : 'loss'} to retained earnings`,
  });
  return { lines, net: round2(-reOffset), accountsClosed: pl.map((p) => p.code) };
}
