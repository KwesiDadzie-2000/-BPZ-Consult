export interface UserPermissions {
  canPostJournals: boolean;
  canApprovePayments: boolean;
  canRunPayroll: boolean;
  canClosePeriod: boolean;
  canModifyCOA: boolean;
}

export interface ClientEntity {
  id: number;
  code: string;
  name: string;
  sector: string;
  currency: string;
  jurisdiction: string;
  regNumber: string;
  isParent?: boolean;
  assignedServices?: string[];
  adminUsername?: string;
  adminEmail?: string;
  adminPassword?: string;
  loginUrl?: string;
}

export interface UserAccount {
  username: string;
  name: string;
  role: 'owner' | 'partner' | 'manager' | 'accountant' | 'auditor';
  makerLimit: number;
  canCheck: boolean;
  email: string;
  clientId?: number;
  password?: string;
  passwordHash?: string;
  passwordSalt?: string;
  status?: 'active' | 'restricted' | 'suspended';
  restrictionReason?: string;
  permissions?: UserPermissions;
}

export interface CompanyProfile {
  clientId: number;
  legalName: string;
  tradingName: string;
  tin: string;
  vatRegNo: string;
  address: string;
  phone: string;
  email: string;
  website: string;
  fiscalYearStart: string;
  bankPaymentDetails: string;
}

export interface ApprovalRequest {
  id: string;
  clientId: number;
  clientCode: string;
  clientName: string;
  docNo: string;
  docType: 'JE' | 'PO' | 'PAY' | 'PAYROLL' | 'REV';
  amount: number;
  requestedBy: string;
  requestedAt: string;
  description: string;
  reasonForApproval: string;
  status: 'pending' | 'approved' | 'rejected';
  reviewedBy?: string;
  reviewedAt?: string;
  rejectionReason?: string;
  /** Proposed journal lines — posted exactly once when the request is approved. */
  payload?: { lines: ACDOCALine[]; settlement?: PaymentSettlementMeta };
}

/**
 * Side effects attached to an above-maker-limit payment request. When the
 * approver signs off, the journal is posted AND these effects are applied
 * (treasury balance movement, supplier/customer document settlement), so an
 * approved payment is actually effected — never silently left unexecuted.
 */
export interface PaymentSettlementMeta {
  kind: 'supplier' | 'customer' | 'salary' | 'expense' | 'statutory';
  clientId: number;
  /** PO id / invoice id / expense bill no / statutory GL account, as applicable. */
  targetId?: string;
  /** Amount applied against the payable/receivable document (gross of WHT). */
  settleAmount: number;
  /** Signed change to the funding treasury record (negative = disbursement). */
  cashDelta: number;
  /** Treasury record that funds the payment / receives the receipt. */
  bankId: number;
}

export interface ACDOCALine {
  id: string;
  docNo: string;
  period: string;
  date: string;
  module: 'MM' | 'SD' | 'HR' | 'FI-AA' | 'ADMIN' | 'FI' | 'INV';
  docType: 'INV' | 'PO' | 'PAY' | 'JE' | 'DEP' | 'STAT' | 'REV';
  accountNo: string;
  accountName: string;
  costCenter?: string;
  debit: number;
  credit: number;
  currency: string;
  description: string;
  createdBy: string;
  checkedBy?: string;
  clientId: number;
  isReversed?: boolean;
  reference?: string;
}

export interface BankAccount {
  id: number;
  clientId?: number;
  code: string;
  name: string;
  bankName: string;
  accountNo: string;
  currency: string;
  balance: number;
  /** Treasury classification: a true bank account or a cash-on-hand float/wallet. */
  kind?: 'bank' | 'cash';
  /** GL account in the chart of accounts that this treasury account is reconciled against. */
  glAccount?: string;
}

export interface PayrollDeductionConfig {
  id: string;
  name: string;
  base: 'gross' | 'basic' | 'net';
  ratePct?: number;
  fixedAmount: number;
}

export interface EmployeeProfile {
  id: number;
  clientId?: number;
  bpNo: string;
  name: string;
  role: string;
  department: string;
  jurisdiction: string;
  basicSalary: number;
  allowances: number;
  ssnitNumber: string;
  tin: string;
  status: 'active' | 'inactive';
  isResident?: boolean;
  exemptTier1?: boolean;
  exemptTier2?: boolean;
  ssnitExempt?: boolean;
  ssnitExemptionReason?: string;
  taxRelief?: number;
  reliefType?: string;
  deductions?: PayrollDeductionConfig[];
}

export interface MonthlyPayrollRecord {
  id: string;
  clientId?: number;
  employeeId: number;
  bpNo: string;
  name: string;
  department: string;
  role: string;
  period: string; // e.g. "2026-03"
  currency: string;
  isResident: boolean;
  exemptTier1: boolean;
  exemptTier2: boolean;
  ssnitExempt?: boolean;
  ssnitExemptionReason?: string;

  // Earnings
  basicSalary: number;
  allowances: number;
  bonusAdditions: number;
  grossPay: number;

  // Reliefs & Taxable
  taxRelief: number;
  reliefType?: string;

  // Statutory Pension (SSNIT 18.5% of insurable basic salary = 5.5% employee + 13% employer)
  ssnitInsurableBase: number;   // 2026 insurable-earnings band (min 587.80 / max 69,000)
  ssnitTier1Employee: number;   // 5.5% of insurable basic — the worker's mandatory deduction
  ssnitTier2Employee: number;   // 0 — the Tier 2 5% is funded inside the combined 18.5% remittance
  ssnitEmployerCost: number;    // 13.0% of insurable basic — the employer's mandatory cost
  ssnitTier1Allocation: number; // 13.5% of insurable basic → SSNIT Tier 1 (incl. 2.5% → NHIA)
  ssnitTier2Allocation: number; // 5.0% of insurable basic → Tier 2 occupational trustee (mandatory)
  nhiaRemittance: number;       // 2.5% of insurable basic → NHIA (routed via the 13.5%)

  // Tax
  taxableIncome: number;
  payeTax: number;

  // Other Deductions on Gross, Basic, or Net
  customDeductions: {
    id: string;
    name: string;
    base: 'gross' | 'basic' | 'net';
    amount: number;
  }[];
  totalCustomDeductions: number;

  // Summary
  totalEmployeeDeductions: number;
  netSalary: number;
  employerTotalCost: number;

  // Status & Posting
  status: 'Draft' | 'Approved' | 'Posted';
  docNo?: string;
  postedDate?: string;
}

export interface PurchaseOrder {
  id: string;
  clientId?: number;
  poNo: string;
  vendorName: string;
  itemType: 'material' | 'service';
  itemDescription: string;
  qty: number;
  unitPrice: number;
  vatRecoverable: number;
  totalAmount: number;
  paidAmount?: number;
  status: 'Open' | 'Goods Received' | 'Invoiced' | 'Paid' | 'Debited';
  date: string;
  /** Transaction currency of the purchase order (defaults to the entity's functional currency). */
  currency?: string;
  /**
   * VAT treatment of the vendor's quotation / bill:
   * - 'standard'   quotation exclusive of VAT; 20% input VAT added (VAT-registered vendor)
   * - 'inclusive'  quoted price already includes VAT; input VAT split out
   * - 'none'       vendor not VAT-registered / bill not VAT-inclusive; no input VAT
   * - 'zero_rated' zero-rated supply; no input VAT
   */
  vatTreatment?: 'standard' | 'inclusive' | 'none' | 'zero_rated';
  /** VAT-exclusive consideration of the order (used as the WHT base). */
  netAmount?: number;
  /** Supplier quotation / competitive tender reference the PO was raised from. */
  quotationRef?: string;
  glAccount: string;
  glAccountName: string;
  costCenter: string;
  costCenterName: string;
}

export interface SalesInvoice {
  id: string;
  clientId?: number;
  invNo: string;
  customerName: string;
  revenueStream: string;
  netRevenue: number;
  vatOutput: number;
  cstAmount?: number;
  tourismLevyAmount?: number;
  vatWithheldByCustomer?: number;
  totalReceivable: number;
  paidAmount: number;
  status: 'Draft' | 'Open' | 'Partial' | 'Paid' | 'Credited';
  date: string;
}

export interface AccountMaster {
  accountNo: string;
  name: string;
  type: 'Asset' | 'Liability' | 'Equity' | 'Income' | 'Expense';
  category: string;
  active: boolean;
  isCustom?: boolean;
  /** Owning entity for custom accounts (absent = firm master chart, shared by all). */
  clientId?: number;
}

export type PrepaymentCategory =
  | 'Insurance'
  | 'Rent'
  | 'Software subscription'
  | 'Maintenance contract'
  | 'Professional retainer'
  | 'Licence & permits'
  | 'Utilities deposit'
  | 'Other';

export type PrepaymentMethod = 'straight_line' | 'daily_prorata';
export type PrepaymentSource = 'bank' | 'supplier_payable' | 'opening_balance';
export type PrepaymentStatus = 'active' | 'fully_amortised' | 'cancelled';

export interface PrepaymentRecord {
  id: string;
  clientId: number;
  code: string;
  title: string;
  category: PrepaymentCategory;
  vendorName: string;
  reference: string;
  paymentDate: string;
  benefitStart: string;
  benefitEnd: string;
  termMonths: number;
  totalAmount: number;
  prepaidAccountNo: string;
  prepaidAccountName: string;
  expenseAccountNo: string;
  expenseAccountName: string;
  costCenter: string;
  method: PrepaymentMethod;
  source: PrepaymentSource;
  status: PrepaymentStatus;
  createdBy: string;
  createdAt: string;
  note?: string;
}

export interface PrepaymentScheduleLine {
  id: string;
  prepaymentId: string;
  clientId: number;
  sequence: number;
  period: string;
  recognitionDate: string;
  openingBalance: number;
  amount: number;
  closingBalance: number;
  status: 'scheduled' | 'posted';
  docNo?: string;
  postedAt?: string;
}

export interface BusinessPartner {
  id: string;
  clientId?: number;
  code: string;
  name: string;
  type: 'Vendor' | 'Customer';
  tin: string;
  email: string;
  phone: string;
  address: string;
  currency: string;
  isVatWithholdingAgent: boolean;
  vatWithholdingRate?: number;
  isCstApplicable: boolean;
  isTourismLevyApplicable: boolean;
  /** Is the partner VAT-registered (i.e. do their bills carry VAT)? Defaults to true when unset. */
  isVatRegistered?: boolean;
}

export interface FixedAsset {
  id: string;
  assetTag: string;
  name: string;
  classCode: string;
  cost: number;
  accumDep: number;
  nbv: number;
  usefulLife: string;
  location: string;
}

export interface PracticeTimesheet {
  id: string;
  staffName: string;
  engagement: string;
  hours: number;
  hourlyRate: number;
  billableFee: number;
  date: string;
  status: 'Approved' | 'Draft';
}

export interface GroupSubsidiary {
  clientId: number;
  code: string;
  name: string;
  ownershipPct: number;
  method: 'Full (IFRS 10)' | 'Equity (IAS 28)';
  nciPct: number;
  goodwill: number;
  reportingCcy: string;
}

export interface EliminationRecord {
  id: string;
  fromEntity: string;
  toEntity: string;
  description: string;
  amount: number;
  eliminated: boolean;
  journalRef: string;
}

export interface DisclosureNote {
  key: string;
  noteNumber: number;
  title: string;
  standardRef: string;
  applicable: boolean;
  notApplicableReason?: string;
  body: string;
  tables?: {
    headers: string[];
    rows: (string | number)[][];
  }[];
  editableOverride?: boolean;
}

/* ============================================
 * PAYE TAX BANDS (Progressive Income Tax)
 * -----------------------------------------------------------------------------
 * Ghana PAYE brackets effective 2024/2025 per GRA
 * -----------------------------------------------------------------------------
 */
export interface PayeBand {
  id: string;
  name: string;
  from: number;        // Lower bound (inclusive)
  to: number | null;   // Upper bound (exclusive), null = no upper limit
  rate: number;        // Percentage rate
  effectiveFrom: string; // Date this band became effective
  isActive: boolean;
}

/* ============================================
 * VAT & TAX COMPONENTS
 * -----------------------------------------------------------------------------
 * Ghana statutory taxes:
 * - VAT: 12.5%
 * - NHIL: 2.5%
 * - GETFund: 2.5%
 * - COVID-19 Recovery Levy: 1%
 * - Total VAT-inclusive rate: 17.5%
 * - Withholding Tax: 5% goods, 7.5% services, 15% professional
 * - CST (Communication Service Tax): 5%
 * - Tourism Levy: 1%
 * -----------------------------------------------------------------------------
 */
export interface TaxComponent {
  id: string;
  code: string;           // e.g. 'VAT', 'NHIL', 'GETFUND', 'COVID', 'WHT_GOODS', 'WHT_SERVICES', 'CST', 'TOURISM_LEVY'
  name: string;
  rate: number;           // Percentage rate
  type: 'sales_tax' | 'purchase_tax' | 'withholding_tax' | 'special_levy';
  appliesTo: 'sales' | 'purchase' | 'both';
  isActive: boolean;
  effectiveFrom: string;
}

/* ============================================
 * BUSINESS PARTNER EXTENSIONS
 * -----------------------------------------------------------------------------
 * Extended fields for tax withholding agent status
 * -----------------------------------------------------------------------------
 */
export interface BusinessPartnerExtended extends BusinessPartner {
  isVatWithholdingAgent: boolean;      // Is this customer a VAT withholding agent?
  vatWithholdingRate?: number;         // Custom WHT rate if different from default
  isCstApplicable: boolean;            // Is Communication Service Tax applicable?
  isTourismLevyApplicable: boolean;    // Is Tourism Levy applicable?
}

/* ============================================
 * EMPLOYEE EXTENSIONS
 * -----------------------------------------------------------------------------
 * SSNIT exemption flag
 * -----------------------------------------------------------------------------
 */
export interface EmployeeProfileExtended extends EmployeeProfile {
  ssnitExempt: boolean;           // Is employee exempt from SSNIT?
  ssnitExemptionReason?: string;  // Reason for exemption
}
