/**
 * Browser-side session management + authenticated API calls.
 *
 * WHY THIS FILE WAS REWRITTEN
 * ---------------------------
 * The token used to live in `sessionStorage` only, and any 401 from the API was
 * treated as "the session is gone" → the workspace dumped the user back on the
 * login portal (often a second after a perfectly successful sign-in). Every one
 * of those assumptions was wrong in the field:
 *
 *  • `sessionStorage` is per-tab: opening the workspace in a new tab, following
 *    a client login link, or a browser tab-restore lost the token completely.
 *  • When site data is blocked/partitioned (Safari ITP, strict privacy modes,
 *    embedded preview iframes) `setItem` throws — the failure was swallowed, so
 *    the user was "signed in" with no token at all.
 *  • A single 401 could be a stripped `Authorization` header, a cached proxy
 *    response, a cold serverless instance or a database blip — none of which
 *    mean the session ended.
 *
 * Now: the token is mirrored in `sessionStorage` AND `localStorage` (and the
 * server also keeps an HttpOnly cookie, which needs no JavaScript at all), a
 * read repairs whichever copy is missing, and the user is only returned to the
 * sign-in screen after the server has *confirmed* twice that no session exists.
 */

const TOKEN_KEY = "bpz_session_token_v1";
const USER_KEY = "bpz_session_user_v1";

type WebStorage = Storage | null;

function store(kind: "session" | "local"): WebStorage {
  try {
    const s = kind === "session" ? globalThis.sessionStorage : globalThis.localStorage;
    // Probe: some browsers hand back a Storage object that throws on use.
    const probe = "__bpz_probe__";
    s.setItem(probe, "1");
    s.removeItem(probe);
    return s;
  } catch {
    return null;
  }
}

function read(key: string): string | null {
  for (const kind of ["session", "local"] as const) {
    try {
      const value = store(kind)?.getItem(key);
      if (value) return value;
    } catch {
      /* try the next store */
    }
  }
  return null;
}

function write(key: string, value: string): void {
  for (const kind of ["session", "local"] as const) {
    try {
      store(kind)?.setItem(key, value);
    } catch {
      /* a blocked store must never break sign-in — the cookie still carries it */
    }
  }
}

function remove(key: string): void {
  for (const kind of ["session", "local"] as const) {
    try {
      store(kind)?.removeItem(key);
    } catch {
      /* ignore */
    }
  }
}

export function getSessionToken(): string | null {
  const token = read(TOKEN_KEY);
  if (token) {
    // Repair a half-written pair (e.g. only sessionStorage survived a restore).
    write(TOKEN_KEY, token);
  }
  return token;
}

export function setSession(token: string, user: unknown): void {
  if (token) write(TOKEN_KEY, token);
  try {
    write(USER_KEY, JSON.stringify(user));
  } catch {
    /* ignore */
  }
}

/** Stores a token returned by the server (self-healing after a cookie repair). */
export function persistToken(token: string): void {
  if (token && token !== read(TOKEN_KEY)) write(TOKEN_KEY, token);
}

export function getCachedSessionUser<T>(): T | null {
  try {
    const raw = read(USER_KEY);
    return raw ? (JSON.parse(raw) as T) : null;
  } catch {
    return null;
  }
}

export function cacheSessionUser(user: unknown): void {
  try {
    write(USER_KEY, JSON.stringify(user));
  } catch {
    /* ignore */
  }
}

export function clearSessionStore(): void {
  remove(TOKEN_KEY);
  remove(USER_KEY);
}

function authHeaders(init: RequestInit = {}): HeadersInit {
  const token = getSessionToken();
  return {
    "Content-Type": "application/json",
    ...(init.headers || {}),
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
  };
}

/**
 * Authenticated fetch. The HttpOnly session cookie rides along automatically
 * (`credentials: "same-origin"`), the Bearer token is added when JavaScript can
 * read it, and responses are never taken from a cache.
 */
export async function apiFetch(path: string, init: RequestInit = {}): Promise<Response> {
  return fetch(path, {
    ...init,
    credentials: "same-origin",
    cache: "no-store",
    headers: authHeaders(init),
  });
}

export interface SessionProbe {
  /** The server confirmed a live session. */
  user: unknown | null;
  token: string | null;
  /** The server definitively said there is no session (401/403). */
  signedOut: boolean;
  /** Infrastructure problem (network, 5xx, 503) — the session state is UNKNOWN. */
  unreachable: boolean;
}

/** Asks the server who is signed in. Never throws. */
export async function probeSession(): Promise<SessionProbe> {
  try {
    const res = await apiFetch("/api/auth/session");
    const body = await res.json().catch(() => null);
    if (res.ok && body?.ok && body.user) {
      // The server may have re-issued the token/cookie — adopt it.
      if (typeof body.token === "string" && body.token) persistToken(body.token);
      cacheSessionUser(body.user);
      return { user: body.user, token: typeof body.token === "string" ? body.token : null, signedOut: false, unreachable: false };
    }
    if (res.status === 401 || res.status === 403) {
      return { user: null, token: null, signedOut: true, unreachable: false };
    }
    return { user: null, token: null, signedOut: false, unreachable: true };
  } catch {
    return { user: null, token: null, signedOut: false, unreachable: true };
  }
}

/**
 * Confirms that the session really is gone before anyone is signed out.
 *
 * Resolves `true` ONLY when the server answers 401/403 to a fresh probe (twice,
 * with a short pause, so a cold start or a dropped header cannot misfire).
 * Network errors, 5xx and 503 resolve `false` — "we do not know", and the user
 * keeps working against the browser copy instead of being thrown out.
 */
export async function confirmSessionLost(): Promise<boolean> {
  for (let attempt = 0; attempt < 2; attempt += 1) {
    if (attempt > 0) await new Promise((resolve) => setTimeout(resolve, 700));
    const probe = await probeSession();
    if (probe.unreachable) return false;
    if (!probe.signedOut) return false;
  }
  // Two consecutive definitive rejections: the session is genuinely gone.
  clearSessionStore();
  return true;
}

/**
 * `fetch` with an automatic session check: on a 401 the session is verified
 * before it is believed. Returns the (possibly retried) response plus a flag
 * telling the caller whether the sign-out is confirmed.
 */
export async function apiFetchVerified(
  path: string,
  init: RequestInit = {}
): Promise<{ response: Response | null; sessionLost: boolean }> {
  let response: Response;
  try {
    response = await apiFetch(path, init);
  } catch {
    return { response: null, sessionLost: false };
  }
  if (response.status !== 401 && response.status !== 403) {
    return { response, sessionLost: false };
  }
  const lost = await confirmSessionLost();
  if (lost) return { response, sessionLost: true };
  // The session is alive (the first 401 was a blip) — retry the request once.
  try {
    const retried = await apiFetch(path, init);
    return { response: retried, sessionLost: false };
  } catch {
    return { response, sessionLost: false };
  }
}

/** Fired in every other tab when this tab signs out (or in), so tabs agree. */
export const SESSION_STORAGE_EVENT = "bpz-session-changed";

export function broadcastSessionChange(signedIn: boolean): void {
  try {
    globalThis.localStorage?.setItem("bpz_session_signal_v1", `${signedIn ? "in" : "out"}:${Date.now()}`);
  } catch {
    /* ignore */
  }
}
