import { useState, useEffect, useRef, useCallback } from 'react';
import { Menu } from 'lucide-react';
import { LoginScreen, clearSession } from './components/LoginScreen';
import { AccountingHeader } from './components/AccountingHeader';
import { AccountingSidebar } from './components/AccountingSidebar';
import { AccountingDashboard } from './components/AccountingDashboard';
import { ProcurementSection } from './components/ProcurementSection';
import { SalesSection } from './components/SalesSection';
import { PayrollSection } from './components/PayrollSection';
import { BankingSection } from './components/BankingSection';
import { ManualJournalSection } from './components/ManualJournalSection';
import { FinancialReportsSection } from './components/FinancialReportsSection';
import { FixedAssetsSection } from './components/FixedAssetsSection';
import { InventorySection } from './components/InventorySection';
import { ExpensesSection } from './components/ExpensesSection';
import { PaymentDeskSection } from './components/PaymentDeskSection';
import { ClientsManagementSection } from './components/ClientsManagementSection';
import { AdvisorySection } from './components/AdvisorySection';
import { MonthEndSection } from './components/MonthEndSection';
import { ComprehensiveStandardsDesk } from './components/ComprehensiveStandardsDesk';
import { LoansAmortisationDesk } from './components/LoansAmortisationDesk';
import { CompanyProfileSection } from './components/CompanyProfileSection';
import { ChartOfAccountsSection } from './components/ChartOfAccountsSection';
import { BusinessPartnersSection } from './components/BusinessPartnersSection';
import { OpeningBalanceSection } from './components/OpeningBalanceSection';
import { TaxFilingScheduleSection } from './components/TaxFilingScheduleSection';
import { TaxSettingsDesk } from './components/TaxSettingsDesk';
import { PrepaymentsSection } from './components/PrepaymentsSection';
import { AdjustmentsDesk } from './components/AdjustmentsDesk';
import { ModuleErrorBoundary } from './components/ModuleErrorBoundary';
import { persistentStorage } from './utils/persistentStorage';
import { hasFirmWideScope, maySeeSection } from './utils/access';
import { fundingAccountFor as resolveFunding, paymentAccountFor, type PaymentMethod } from './utils/treasury';
import { deriveExpenseBills, liabilityBalance, EXPENSE_PAYABLE_ACCOUNT, type ExpenseBill, type StatutoryPayableRow, type PaymentResult, type PaymentExtras, type PaymentPayee, payeeSuffix, whtSuffix } from './utils/payables';
import { computeCustomerVatWithholding } from './utils/transactionMath';
import { buildCreditNoteEntries, buildDebitNoteEntries } from './utils/reports';
import { buildReversalLines, buildYearEndCloseEntries, checkReversal } from './utils/journalControls';
import {
  apiFetch,
  apiFetchVerified,
  clearSessionStore,
  confirmSessionLost,
  getCachedSessionUser,
  getSessionToken,
  probeSession,
  broadcastSessionChange,
} from './utils/session';

// Enterprise owner-only administration components
import { DisclosureNotesDesk } from './components/DisclosureNotesDesk';
import { ConsolidationDesk } from './components/ConsolidationDesk';
import { SsoDesk } from './components/SsoDesk';
import { GlobalTaxDesk } from './components/GlobalTaxDesk';
import { SocBackupDesk } from './components/SocBackupDesk';
import { IntegrationsDesk } from './components/IntegrationsDesk';
import { UserPermissionsDesk } from './components/UserPermissionsDesk';
import { ApprovalsModal } from './components/ApprovalsModal';

import {
  INITIAL_CLIENTS,
  INITIAL_CHART_OF_ACCOUNTS,
} from './data/accountingSeed';
import {
  ClientEntity,
  UserAccount,
  ACDOCALine,
  PurchaseOrder,
  SalesInvoice,
  EmployeeProfile,
  DisclosureNote,
  BankAccount,
  AccountMaster,
  BusinessPartner,
  MonthlyPayrollRecord,
  PaymentSettlementMeta,
} from './types/accounting';
import { docSuffix, uniqueId } from './utils/ids';

/**
 * Shown while the server is being asked "who is signed in?". Rendering the
 * login form during that window is precisely the "signed in, then instantly
 * back at the login portal" flash that was reported.
 */
function RestoringSession() {
  return (
    <div className="min-h-screen bg-[#f0f6fc] text-[#0a253e] flex items-center justify-center font-sans">
      <div className="flex flex-col items-center gap-3">
        <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-[#f5b719] font-black text-[#082f4f] text-lg shadow-md">
          BPZ
        </span>
        <div className="text-xs font-bold uppercase tracking-widest text-[#355875]">Opening your secure session…</div>
      </div>
    </div>
  );
}

export function App() {
  const [currentUser, setCurrentUser] = useState<UserAccount | null>(null);
  const [signInNotice, setSignInNotice] = useState<string | null>(null);
  const [restoring, setRestoring] = useState(true);

  /**
   * Restore the session ONCE, before the login form is ever considered.
   *
   * The server is asked even when JavaScript holds no token, because the
   * HttpOnly session cookie (set at sign-in) needs no storage at all — that is
   * what keeps a signed-in user signed in across reloads, new tabs, restored
   * tabs, blocked site data and proxies that strip `Authorization` headers.
   */
  useEffect(() => {
    let cancelled = false;
    const restore = async () => {
      const probe = await Promise.race([
        probeSession(),
        new Promise<null>((resolve) => setTimeout(() => resolve(null), 8000)),
      ]);
      if (cancelled) return;
      if (probe && probe.user) {
        setSignInNotice(null);
        setCurrentUser(probe.user as UserAccount);
      } else if (probe === null || probe?.unreachable) {
        // The server could not be reached. If this browser still holds a token
        // and a cached identity, keep the user in their books (browser-side
        // copy, sync resumes when the server returns) instead of locking them
        // out at the door — an outage is not a sign-out.
        const cached = getCachedSessionUser<UserAccount>();
        if (getSessionToken() && cached) {
          setCurrentUser(cached);
          setSignInNotice('The sign-in service could not be reached, so the workspace opened from this browser’s saved copy. Server sync resumes automatically once the connection returns.');
        }
      }
      setRestoring(false);
    };
    void restore();
    return () => { cancelled = true; };
  }, []);

  // Tabs must agree: signing out (or being signed out) anywhere signs out here.
  useEffect(() => {
    const onStorage = (event: StorageEvent) => {
      if (event.key !== 'bpz_session_signal_v1') return;
      const value = typeof event.newValue === 'string' ? event.newValue : '';
      if (value.startsWith('out:')) {
        clearSessionStore();
        setCurrentUser(null);
        setRestoring(false);
      }
    };
    try { globalThis.addEventListener?.('storage', onStorage); } catch { /* ignore */ }
    return () => { try { globalThis.removeEventListener?.('storage', onStorage); } catch { /* ignore */ } };
  }, []);

  if (restoring) return <RestoringSession />;

  if (!currentUser) {
    return (
      <LoginScreen
        notice={signInNotice}
        onLogin={(user) => { setSignInNotice(null); setCurrentUser(user); }}
      />
    );
  }

  return (
    <AccountingWorkspace
      key={currentUser.username}
      currentUser={currentUser}
      onSwitchUser={setCurrentUser}
      onSignOut={() => { clearSession(); setCurrentUser(null); }}
      onSessionExpired={() => {
        // Reached only after the server has CONFIRMED (twice) that the session
        // is gone - see confirmSessionLost(). A transient 401, a cold serverless
        // instance or a stripped Authorization header no longer throws a
        // signed-in user back to the login portal.
        clearSessionStore();
        broadcastSessionChange(false);
        setSignInNotice('Your secure session ended, so the workspace stopped syncing to the firm\u2019s server. Everything you entered is still saved in this browser — sign in again to resume syncing.');
        setCurrentUser(null);
      }}
    />
  );
}

function AccountingWorkspace({
  currentUser,
  onSwitchUser,
  onSignOut,
  onSessionExpired,
}: {
  currentUser: UserAccount;
  onSwitchUser: (user: UserAccount) => void;
  onSignOut: () => void;
  onSessionExpired: () => void;
}) {
  const [clients, setClients] = useState<ClientEntity[]>(() => persistentStorage.getClients());
  const [currentClientId, setCurrentClientId] = useState<number>(() => persistentStorage.getCurrentClientId());
  // Entity isolation: a non-owner user is hard-bound to their own entity. If their
  // assigned entity no longer exists, `workspaceMissing` blocks the render below so
  // they see nothing rather than another client's books.
  const resolvedClient = currentUser.role !== 'owner' && currentUser.clientId
    ? clients.find((c) => c.id === currentUser.clientId)
    : clients.find((c) => c.id === currentClientId) || clients[0];
  const workspaceMissing = !resolvedClient;
  const currentClient = resolvedClient || INITIAL_CLIENTS[1];
  const [activeSection, setActiveSectionRaw] = useState<string>('dashboard');
  // Mobile navigation drawer + the independently scrolling content pane.
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const mainRef = useRef<HTMLElement | null>(null);
  // Every navigation (sidebar, dashboard tiles, in-page links) closes the drawer and
  // returns the content pane to the top, so the click is always visibly acknowledged
  // instead of leaving the user scrolled to the bottom of the previous page.
  const setActiveSection = useCallback((section: string) => {
    setActiveSectionRaw(section);
    setMobileNavOpen(false);
    requestAnimationFrame(() => {
      mainRef.current?.scrollTo({ top: 0, behavior: 'auto' });
      if (typeof window !== 'undefined') window.scrollTo({ top: 0, behavior: 'auto' });
    });
  }, []);
  useEffect(() => {
    if (!mobileNavOpen) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') setMobileNavOpen(false); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [mobileNavOpen]);
  // Visible audit of anything that failed server-side — nothing fails silently.
  const [systemNotices, setSystemNotices] = useState<string[]>([]);
  const pushNotice = (msg: string) =>
    setSystemNotices((prev) => (prev.includes(msg) ? prev : [...prev.slice(-4), msg]));

  // Shared reactive accounting data from backend
  const [lines, setLines] = useState<ACDOCALine[]>(() => persistentStorage.getJournalLines());
  const [bankAccounts, setBankAccounts] = useState<BankAccount[]>(() => persistentStorage.getBankAccounts());
  const [purchaseOrders, setPurchaseOrders] = useState<PurchaseOrder[]>(() => persistentStorage.getPurchaseOrders());
  const [salesInvoices, setSalesInvoices] = useState<SalesInvoice[]>(() => persistentStorage.getSalesInvoices());
  const [employees, setEmployees] = useState<EmployeeProfile[]>(() => persistentStorage.getEmployees());
  const [notes, setNotes] = useState<DisclosureNote[]>(() => persistentStorage.getDisclosureNotes());
  // Closed fiscal periods per entity — each entity's books freeze independently.
  const [closedPeriodsMap, setClosedPeriodsMap] = useState<Record<number, string[]>>(() => persistentStorage.getClosedPeriods());
  const closedPeriods = closedPeriodsMap[currentClient.id] || [];
  // "Is the current month closed" for this entity (drives the desk-level posting guards).
  const isPeriodClosed = closedPeriods.includes(new Date().toISOString().slice(0, 7));
  const [chartOfAccounts, setChartOfAccounts] = useState<AccountMaster[]>(() => {
    const stored = persistentStorage.getChartOfAccounts();
    const storedNos = new Set(stored.map((a) => a.accountNo));
    const missing = INITIAL_CHART_OF_ACCOUNTS.filter((a) => !storedNos.has(a.accountNo));
    return missing.length ? [...stored, ...missing] : stored;
  });
  const [businessPartners, setBusinessPartners] = useState<BusinessPartner[]>(() => persistentStorage.getBusinessPartners());
  // Untagged legacy sample rows belong only to the original demonstration client.
  const ownedByCurrent = (row: { clientId?: number }) => (row.clientId ?? INITIAL_CLIENTS[1].id) === currentClient.id;
  const visibleBanks = bankAccounts.filter(ownedByCurrent);
  const visibleOrders = purchaseOrders.filter(ownedByCurrent);
  const visibleInvoices = salesInvoices.filter(ownedByCurrent);
  const visibleEmployees = employees.filter(ownedByCurrent);
  const visiblePartners = businessPartners.filter(ownedByCurrent);
  // Chart of accounts is NOT pooled: every entity sees the firm master chart
  // (accounts with no owner) plus only its OWN custom accounts. Accounts created
  // inside another client's workspace never leak into this one.
  const visibleAccounts = chartOfAccounts.filter((a) => a.clientId == null || a.clientId === currentClient.id);
  const [isApprovalsModalOpen, setIsApprovalsModalOpen] = useState(false);
  // Approvals are entity-scoped: the header badge counts only the ACTIVE
  // workspace's pending requests, so opening one client never surfaces another
  // entity's documents at the top of the screen.
  const [approvalsCount, setApprovalsCount] = useState<number>(0);

  const refreshApprovalsCount = () => {
    setApprovalsCount(
      persistentStorage
        .getApprovalRequests()
        .filter((r) => r.status === 'pending' && r.clientId === currentClient.id).length
    );
  };
  useEffect(() => { refreshApprovalsCount(); // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentClient.id, lines.length]);

  useEffect(() => { persistentStorage.saveClients(clients); }, [clients]);
  useEffect(() => { persistentStorage.saveCurrentClientId(currentClientId); }, [currentClientId]);
  useEffect(() => { persistentStorage.saveJournalLines(lines); }, [lines]);
  useEffect(() => { persistentStorage.saveBankAccounts(bankAccounts); }, [bankAccounts]);
  useEffect(() => { persistentStorage.savePurchaseOrders(purchaseOrders); }, [purchaseOrders]);
  useEffect(() => { persistentStorage.saveSalesInvoices(salesInvoices); }, [salesInvoices]);
  useEffect(() => { persistentStorage.saveEmployees(employees); }, [employees]);
  useEffect(() => { persistentStorage.saveDisclosureNotes(notes); }, [notes]);
  useEffect(() => { persistentStorage.saveClosedPeriods(closedPeriodsMap); }, [closedPeriodsMap]);
  useEffect(() => { persistentStorage.saveChartOfAccounts(chartOfAccounts); }, [chartOfAccounts]);
  useEffect(() => { persistentStorage.saveBusinessPartners(businessPartners); }, [businessPartners]);

  // Hydrate from the server (authoritative, tenant-scoped) once per session.
  const [hydrated, setHydrated] = useState(false);
  // Server sync is only allowed once THIS session has loaded the authoritative
  // server state. Previously a failed /api/bootstrap (network error, 5xx) still
  // set `hydrated`, and the debounced sync then PUT this browser's stale
  // localStorage copy — which, for the owner, replaced every table on the server.
  const [serverStateLoaded, setServerStateLoaded] = useState(false);
  // Resilient load: retries, and only a CONFIRMED dead session signs the user out.
  useEffect(() => {
    if (hydrated) return;
    let cancelled = false;
    const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

    const applyServerState = (b: { ok?: boolean; state?: any } | null) => {
      if (!b?.ok || !b.state) {
        pushNotice('The server workspace response could not be understood — server sync is paused so nothing is overwritten. Reload the page to retry.');
        return;
      }
      const s = b.state;
      persistentStorage.saveClients(s.clients || []);
      persistentStorage.saveJournalLines(s.journalLines || []);
      persistentStorage.saveBankAccounts(s.bankAccounts || []);
      persistentStorage.savePurchaseOrders(s.purchaseOrders || []);
      persistentStorage.saveSalesInvoices(s.salesInvoices || []);
      persistentStorage.saveEmployees(s.employees || []);
      persistentStorage.saveBusinessPartners(s.businessPartners || []);
      persistentStorage.savePayrollRecords(s.payrollRecords || []);
      persistentStorage.saveApprovalRequests(s.approvalRequests || []);
      persistentStorage.savePrepayments(s.prepaymentRecords || []);
      persistentStorage.savePrepaymentSchedules(s.prepaymentSchedules || []);
      persistentStorage.saveCompanyProfiles(s.companyProfiles || {});
      persistentStorage.saveChartOfAccounts(s.chartOfAccounts || []);
      persistentStorage.saveDisclosureNotes(s.disclosureNotes || []);
      const closedMap: Record<number, string[]> = {};
      for (const c of s.closedPeriods || []) {
        (closedMap[c.clientId] ||= []).push(c.period);
      }
      persistentStorage.saveClosedPeriods(closedMap);
      if (s.users) persistentStorage.saveUserAccounts(s.users);
      handleRefreshAllData();
      setServerStateLoaded(true);
    };

    const run = async () => {
      // The server is ALWAYS asked, even when no token is readable from
      // JavaScript storage: the HttpOnly session cookie carries the session on
      // its own. Skipping this call used to strand such users on a browser-only
      // copy that never synced.
      for (let attempt = 0; attempt < 3; attempt += 1) {
        try {
          const r = await apiFetch('/api/bootstrap');
          if (r.status === 401 || r.status === 403) {
            // Believe a rejection only once the server confirms it twice. A lone
            // 401 — stripped Authorization header, cached proxy response, cold
            // serverless instance — used to bounce the user to the login portal
            // a moment after a successful sign-in.
            const lost = await confirmSessionLost();
            if (cancelled) return;
            if (lost) { onSessionExpired(); return; }
            if (attempt < 2) { await sleep(600); continue; }
            pushNotice('The workspace load was rejected by the server, but your session is still valid — server sync is paused. Reload the page to retry.');
            return;
          }
          if (!r.ok) {
            const detail = await r.json().catch(() => null);
            if (cancelled) return;
            pushNotice(`The server workspace could not be loaded (HTTP ${r.status}${detail?.error ? `: ${detail.error}` : ''}) — server sync is paused so nothing is overwritten. Reload the page to retry.`);
            return;
          }
          const body = await r.json().catch(() => null);
          if (cancelled) return;
          applyServerState(body);
          return;
        } catch {
          if (cancelled) return;
          if (attempt < 2) { await sleep(800); continue; }
          pushNotice('The server could not be reached — server sync is paused so nothing is overwritten. Reload the page to retry.');
          return;
        }
      }
    };

    void run().finally(() => { if (!cancelled) setHydrated(true); });
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hydrated]);

  // Debounced full-state sync to the server (authoritative, validated, transactional).
  useEffect(() => {
    if (!hydrated || !serverStateLoaded) return;
    const t = setTimeout(() => {
      // No `getSessionToken()` guard: the HttpOnly cookie authenticates the PUT
      // even when JavaScript storage holds no token, so a blocked/cleared store
      // used to switch server sync off silently and permanently.
      const payload = {
        clients,
        journalLines: lines,
        bankAccounts,
        purchaseOrders,
        salesInvoices,
        employees,
        businessPartners,
        payrollRecords: persistentStorage.getPayrollRecords(),
        prepaymentRecords: persistentStorage.getPrepayments(),
        prepaymentSchedules: persistentStorage.getPrepaymentSchedules(),
        approvalRequests: persistentStorage.getApprovalRequests(),
        companyProfiles: persistentStorage.getCompanyProfiles(),
        chartOfAccounts,
        disclosureNotes: notes,
        closedPeriods: Object.entries(closedPeriodsMap).flatMap(([clientId, periods]) =>
          periods.map((period) => ({ clientId: Number(clientId), period }))
        ),
      };
      void (async () => {
        // A 401 here is VERIFIED (and the PUT retried once) before anybody is
        // signed out — this call fired ~800 ms after sign-in and was the second
        // path that dropped users back onto the login portal.
        const { response, sessionLost } = await apiFetchVerified('/api/state', {
          method: 'PUT',
          body: JSON.stringify(payload),
        });
        if (sessionLost) { onSessionExpired(); return; }
        if (!response) {
          pushNotice('Workspace sync failed — the server could not be reached. Changes remain in this browser.');
          return;
        }
        if (response.ok) return;
        const b = await response.json().catch(() => null);
        const serverError = b?.error || `HTTP ${response.status}`;
        pushNotice(`Workspace sync was NOT accepted by the server: ${serverError}`);
        console.warn('Server rejected state sync:', serverError);
      })();
    }, 800);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hydrated, serverStateLoaded, clients, lines, bankAccounts, purchaseOrders, salesInvoices, employees, notes, chartOfAccounts, businessPartners, closedPeriodsMap]);

  const handleRefreshAllData = () => {
    setClients(persistentStorage.getClients());
    setCurrentClientId(persistentStorage.getCurrentClientId());
    setLines(persistentStorage.getJournalLines());
    setBankAccounts(persistentStorage.getBankAccounts());
    setPurchaseOrders(persistentStorage.getPurchaseOrders());
    setSalesInvoices(persistentStorage.getSalesInvoices());
    setEmployees(persistentStorage.getEmployees());
    setNotes(persistentStorage.getDisclosureNotes());
    setChartOfAccounts(persistentStorage.getChartOfAccounts());
    setBusinessPartners(persistentStorage.getBusinessPartners());
    setClosedPeriodsMap(persistentStorage.getClosedPeriods());
  };

  const isOwner = currentUser.role === 'owner';

  // Double-entry validation
  const clientLines = lines.filter((l) => l.clientId === currentClient.id);
  const totalDebits = clientLines.reduce((s, l) => s + l.debit, 0);
  const totalCredits = clientLines.reduce((s, l) => s + l.credit, 0);
  const isBalanced = Math.abs(totalDebits - totalCredits) < 0.01;
  const uniqueDocs = new Set(clientLines.map((l) => l.docNo)).size;

  const handleAddJournalLines = (newLines: ACDOCALine[], docCurrency?: string, expectedClientId?: number): boolean => {
    if (!newLines.length) return false;
    // Per-entity, per-period freeze: no posting into a closed period.
    if (newLines.some((l) => (closedPeriodsMap[l.clientId] || []).includes(l.period))) return false;
    // The owner may post into another entity (e.g. approving a client's queued
    // document while working in a different workspace) — the expected client is
    // therefore parameterised; its functional currency is the default.
    const expectedClient = clients.find((c) => c.id === (expectedClientId ?? currentClient.id)) || currentClient;
    // Every posted line must belong to that entity, carry the document currency,
    // and reference an account that exists in the chart of accounts.
    const expectedCurrency = docCurrency || expectedClient.currency;
    const knownAccounts = new Set(
      chartOfAccounts.filter((a) => a.clientId == null || a.clientId === expectedClient.id).map((a) => a.accountNo)
    );
    if (newLines.some(l => l.clientId !== expectedClient.id || l.currency !== expectedCurrency || !knownAccounts.has(l.accountNo) || !Number.isFinite(l.debit) || !Number.isFinite(l.credit) || l.debit < 0 || l.credit < 0)) return false;
    const debits = newLines.reduce((n, l) => n + Math.round(l.debit * 100), 0);
    const credits = newLines.reduce((n, l) => n + Math.round(l.credit * 100), 0);
    if (debits !== credits || debits <= 0) return false;
    if (newLines.some(l => lines.some(existing => existing.clientId === l.clientId && existing.docNo === l.docNo))) return false;
    setLines(previous => [...previous, ...newLines]);
    // Server-side posting service: the document is validated and posted in one
    // database transaction; if the server rejects it, the local post is rolled back
    // and the rejection is surfaced — nothing fails silently.
    void (async () => {
      const { response: r, sessionLost } = await apiFetchVerified('/api/journal', {
        method: 'POST',
        body: JSON.stringify({ lines: newLines }),
      });
      if (sessionLost) {
        pushNotice('Document posted locally but the server session has ended — it was NOT synced. Sign in again to restore server sync.');
        onSessionExpired();
        return;
      }
      if (!r) {
        pushNotice('Document posted locally but the server could not be reached — it was NOT synced to the server.');
        return;
      }
      if (r.status === 409) {
        const b = await r.json().catch(() => null);
        setLines((previous) => previous.filter((l) => !newLines.some((n) => n.id === l.id)));
        pushNotice(`Document ${newLines[0]?.docNo || 'JOURNAL'} was NOT posted to the server and was rolled back: ${b?.error || 'server rejected the document'}.`);
      } else if (r.status === 401 || r.status === 403) {
        pushNotice('Document posted locally but the server rejected the session — it was NOT synced. Reload the workspace to retry.');
      } else if (!r.ok) {
        const b = await r.json().catch(() => null);
        pushNotice(`Document ${newLines[0]?.docNo || 'JOURNAL'} sync failed: ${b?.error || `HTTP ${r.status}`}.`);
      }
    })();
    return true;
  };

  const periodFrom = (date: string) => date.slice(0, 7);
  const postDate = () => new Date().toISOString().slice(0, 10);
  // Payment references must be unique per entity; partial settlements reuse the
  // same base reference, so a suffix is appended when it is already posted.
  const uniqueDocNo = (base: string, clientId: number) =>
    lines.some((l) => l.clientId === clientId && l.docNo === base) ? `${base}-${docSuffix()}` : base;

  // Queue an above-maker-limit payment for independent approval. The proposed
  // journal AND its settlement side effects travel with the request, so approval
  // actually effects the payment (treasury movement + document settlement).
  const queuePaymentApproval = (
    docNo: string,
    description: string,
    amount: number,
    entries: ACDOCALine[],
    settlement: PaymentSettlementMeta,
  ): PaymentResult => {
    persistentStorage.addApprovalRequest({
      id: `${uniqueId('APP-PAY')}`, clientId: currentClient.id, clientCode: currentClient.code, clientName: currentClient.name,
      docNo, docType: 'PAY', amount,
      requestedBy: `${currentUser.name} (${currentUser.username})`, requestedAt: new Date().toISOString(),
      description,
      reasonForApproval: `Amount ${amount.toFixed(2)} exceeds maker limit ${currentUser.makerLimit.toFixed(2)}. On approval the payment is posted and effected automatically.`,
      status: 'pending', payload: { lines: entries, settlement },
    });
    refreshApprovalsCount();
    return 'queued';
  };

  // Receive an approved PO and post the selected material/service GL, VAT and payable.
  // Honours the vendor's VAT treatment: non-VAT / zero-rated bills post no input VAT line.
  const handlePostPOToJournal = (po: PurchaseOrder): boolean => {
    const date = postDate();
    const period = periodFrom(date);
    const net = po.netAmount ?? Math.round(po.qty * po.unitPrice * 100) / 100;
    const poCurrency = po.currency || currentClient.currency;
    const debitAccount = po.glAccount || (po.itemType === 'material' ? '120000' : '621000');
    const debitName = po.glAccountName || (po.itemType === 'material' ? 'Inventories — Raw Materials & Spares' : 'Contracted Services & Subcontractor Costs');
    const docNo = po.poNo;
    const entries: ACDOCALine[] = [
      { id: `${uniqueId('JL')}-1`, docNo, period, date, module: 'MM', docType: 'PO', accountNo: debitAccount, accountName: debitName, costCenter: po.costCenter, debit: net, credit: 0, currency: poCurrency, description: `${po.itemType} receipt: ${po.itemDescription}`, createdBy: currentUser.username, clientId: currentClient.id },
      { id: `${uniqueId('JL')}-3`, docNo, period, date, module: 'MM', docType: 'PO', accountNo: '200000', accountName: `Trade Payables (${po.vendorName})`, costCenter: po.costCenter, debit: 0, credit: po.totalAmount, currency: poCurrency, description: `Supplier payable for ${po.poNo}`, createdBy: currentUser.username, clientId: currentClient.id },
    ];
    // Input VAT line only when the vendor's bill actually carries VAT.
    if (po.vatRecoverable > 0) {
      entries.splice(1, 0, { id: `${uniqueId('JL')}-2`, docNo, period, date, module: 'MM', docType: 'PO', accountNo: '125000', accountName: 'VAT Input Tax Recoverable', costCenter: po.costCenter, debit: po.vatRecoverable, credit: 0, currency: poCurrency, description: `Input VAT on ${po.poNo}`, createdBy: currentUser.username, clientId: currentClient.id });
    }
    const result = handleAddJournalLines(entries, poCurrency);
    if (result) setPurchaseOrders(previous => previous.map(p => p.id === po.id ? { ...p, status: 'Invoiced', paidAmount: p.paidAmount || 0 } : p));
    return result;
  };

  // Debit note (purchase return): reverses the payable, the GL charge and input VAT.
  const handleIssueDebitNote = (po: PurchaseOrder): boolean => {
    if (po.status === 'Paid' || po.status === 'Debited') return false;
    const entries = buildDebitNoteEntries(po, postDate(), currentClient.currency, currentClient.id, currentUser.username);
    const result = handleAddJournalLines(entries);
    if (result) setPurchaseOrders(previous => previous.map(p => p.id === po.id ? { ...p, status: 'Debited', paidAmount: 0 } : p));
    return result;
  };

  // Credit note (sales return): reverses revenue, output VAT and sector levies against the receivable.
  const handleIssueCreditNote = (inv: SalesInvoice): boolean => {
    if (isPeriodClosed) return false;
    if (inv.status === 'Draft' || inv.status === 'Credited') return false;
    const entries = buildCreditNoteEntries(inv, postDate(), currentClient.currency, currentClient.id, currentUser.username);
    const result = handleAddJournalLines(entries);
    if (result) setSalesInvoices(previous => previous.map(i => i.id === inv.id ? { ...i, status: 'Credited' } : i));
    return result;
  };

  // Issue sales invoice: Dr trade receivable / Cr revenue and configured statutory liabilities.
  const handlePostSalesToJournal = (inv: SalesInvoice): boolean => {
    const date = postDate();
    const period = periodFrom(date);
    const entries: ACDOCALine[] = [
      { id: `${uniqueId('JL')}-1`, docNo: inv.invNo, period, date, module: 'SD', docType: 'INV', accountNo: '110000', accountName: `Trade Receivables (${inv.customerName})`, costCenter: 'CC-SLS', debit: inv.totalReceivable, credit: 0, currency: currentClient.currency, description: `Sales invoice ${inv.invNo}: ${inv.revenueStream}`, createdBy: currentUser.username, clientId: currentClient.id },
      { id: `${uniqueId('JL')}-2`, docNo: inv.invNo, period, date, module: 'SD', docType: 'INV', accountNo: '400000', accountName: 'Revenue from Contracts with Customers', costCenter: 'CC-SLS', debit: 0, credit: inv.netRevenue, currency: currentClient.currency, description: `Revenue recognition for ${inv.invNo}`, createdBy: currentUser.username, clientId: currentClient.id },
    ];
    if (inv.vatOutput > 0) entries.push({ id: `${uniqueId('JL')}-3`, docNo: inv.invNo, period, date, module: 'SD', docType: 'INV', accountNo: '220000', accountName: 'VAT/NHIL/GETFund Output Liability', costCenter: 'CC-SLS', debit: 0, credit: inv.vatOutput, currency: currentClient.currency, description: `VAT stack on ${inv.invNo}`, createdBy: currentUser.username, clientId: currentClient.id });
    if ((inv.cstAmount || 0) > 0) entries.push({ id: `${uniqueId('JL')}-4`, docNo: inv.invNo, period, date, module: 'SD', docType: 'INV', accountNo: '223000', accountName: 'Communication Service Tax Payable', costCenter: 'CC-SLS', debit: 0, credit: inv.cstAmount || 0, currency: currentClient.currency, description: `CST on ${inv.invNo}`, createdBy: currentUser.username, clientId: currentClient.id });
    if ((inv.tourismLevyAmount || 0) > 0) entries.push({ id: `${uniqueId('JL')}-5`, docNo: inv.invNo, period, date, module: 'SD', docType: 'INV', accountNo: '224000', accountName: 'Tourism Levy Payable', costCenter: 'CC-SLS', debit: 0, credit: inv.tourismLevyAmount || 0, currency: currentClient.currency, description: `Tourism levy on ${inv.invNo}`, createdBy: currentUser.username, clientId: currentClient.id });
    const posted = handleAddJournalLines(entries);
    if (posted) setSalesInvoices(previous => previous.map(i => i.id === inv.id ? { ...i, status: i.paidAmount > 0 ? 'Partial' : 'Open' } : i));
    return posted;
  };

  // Treasury routing (bank vs cash float vs mobile money) shared with the Payment Desk.
  const fundingAccountFor = (method: PaymentMethod, bank: BankAccount): BankAccount => resolveFunding(method, bank, bankAccounts);
  const aboveMakerLimit = (amount: number) => currentUser.makerLimit > 0 && amount > currentUser.makerLimit;
  const round2 = (n: number) => Math.round(n * 100) / 100;

  const handleSettleSupplierInvoice = (input: {
    po: PurchaseOrder; grossAmount: number; whtRate: number; vatWithheld: number; bankId: number;
    method: PaymentMethod; reference: string;
  } & PaymentExtras): PaymentResult => {
    const { po, grossAmount, whtRate, vatWithheld, bankId, method, reference, payee, whtNote } = input;
    const date = postDate();
    const period = periodFrom(date);
    if (isPeriodClosed) return 'failed';
    const bank = bankAccounts.find(b => b.id === bankId);
    const outstanding = po.totalAmount - (po.paidAmount || 0);
    if (!bank || grossAmount <= 0 || grossAmount > outstanding + 0.009) return 'failed';
    // Settlements are posted in the purchase order's own currency.
    const payCurrency = po.currency || currentClient.currency;
    // WHT is charged on the consideration exclusive of VAT and levies (the PO net amount).
    const taxBase = po.totalAmount ? grossAmount * (((po.netAmount ?? po.qty * po.unitPrice) / po.totalAmount)) : 0;
    const incomeWht = Math.round(taxBase * whtRate) / 100;
    const cashPaid = round2(grossAmount - incomeWht - vatWithheld);
    // Draw funds from the treasury record matching the method and the PO currency.
    const selectedFunding = fundingAccountFor(method, bank);
    const funding = selectedFunding.currency === payCurrency
      ? selectedFunding
      : bankAccounts.find((b) => b.currency === payCurrency) || selectedFunding;
    if (cashPaid < 0 || funding.balance + 0.009 < cashPaid) return 'failed';
    const paymentGl = paymentAccountFor(method, funding);
    const docNo = uniqueDocNo(reference || `PAY-${po.poNo.replace('PO-', '')}`, currentClient.id);
    const entries: ACDOCALine[] = [
      { id: `${uniqueId('JL')}-1`, docNo, period, date, module: 'FI', docType: 'PAY', accountNo: '200000', accountName: `Trade Payables (${po.vendorName})`, costCenter: po.costCenter, debit: grossAmount, credit: 0, currency: payCurrency, description: `Settlement of ${po.poNo}${payeeSuffix(payee)}`, createdBy: currentUser.username, clientId: currentClient.id },
      { id: `${uniqueId('JL')}-2`, docNo, period, date, module: 'FI', docType: 'PAY', accountNo: paymentGl.no, accountName: paymentGl.name, costCenter: po.costCenter, debit: 0, credit: cashPaid, currency: payCurrency, description: `${method.replace('_', ' ')} payment for ${po.poNo}${payeeSuffix(payee)}${whtSuffix(whtRate > 0, whtRate, whtNote)}`, createdBy: currentUser.username, clientId: currentClient.id },
    ];
    if (incomeWht > 0) entries.push({ id: `${uniqueId('JL')}-3`, docNo, period, date, module: 'FI', docType: 'PAY', accountNo: '209000', accountName: 'Income Withholding Tax Payable', costCenter: po.costCenter, debit: 0, credit: incomeWht, currency: payCurrency, description: `Income WHT ${whtRate}% on ${po.poNo}`, createdBy: currentUser.username, clientId: currentClient.id });
    if (vatWithheld > 0) entries.push({ id: `${uniqueId('JL')}-4`, docNo, period, date, module: 'FI', docType: 'PAY', accountNo: '221000', accountName: 'VAT Withholding Payable', costCenter: po.costCenter, debit: 0, credit: vatWithheld, currency: payCurrency, description: `VAT withholding on ${po.poNo}`, createdBy: currentUser.username, clientId: currentClient.id });
    if (aboveMakerLimit(grossAmount)) {
      return queuePaymentApproval(docNo, `Supplier settlement: ${po.vendorName} (${po.poNo})${payeeSuffix(payee)}`, grossAmount, entries,
        { kind: 'supplier', clientId: currentClient.id, targetId: po.id, settleAmount: grossAmount, cashDelta: -cashPaid, bankId: funding.id });
    }
    const result = handleAddJournalLines(entries, payCurrency);
    if (!result) return 'failed';
    const paidAmount = Math.min(po.totalAmount, (po.paidAmount || 0) + grossAmount);
    setPurchaseOrders(previous => previous.map(p => p.id === po.id ? { ...p, paidAmount, status: paidAmount + 0.009 >= p.totalAmount ? 'Paid' : 'Invoiced' } : p));
    if (funding.currency === payCurrency) setBankAccounts(previous => previous.map(b => b.id === funding.id ? { ...b, balance: round2(b.balance - cashPaid) } : b));
    return 'posted';
  };

  const handleReceiveCustomerPayment = (input: {
    invoice: SalesInvoice; amount: number; bankId: number; method: PaymentMethod; reference: string;
  }): PaymentResult => {
    const { invoice, amount, bankId, method, reference } = input;
    const date = postDate();
    const period = periodFrom(date);
    if (isPeriodClosed) return 'failed';
    const bank = bankAccounts.find(b => b.id === bankId);
    const outstanding = invoice.totalReceivable - invoice.paidAmount;
    if (!bank || amount <= 0 || amount > outstanding + 0.009) return 'failed';
    // Receipts land in the treasury record matching the method (bank, cash float or mobile money).
    const funding = fundingAccountFor(method, bank);
    const receiptGl = paymentAccountFor(method, funding);
    const docNo = uniqueDocNo(reference || `REC-${invoice.invNo.replace('INV-', '')}`, currentClient.id);
    // Appointed VAT-withholding customers deduct 7% of the taxable value at source;
    // the withheld amount settles the receivable via the WHT receivable account (115000).
    const wht = computeCustomerVatWithholding(invoice.vatWithheldByCustomer || 0, invoice.totalReceivable, outstanding, amount);
    const settleTotal = round2(amount + wht);
    const entries: ACDOCALine[] = [
      { id: `${uniqueId('JL')}-1`, docNo, period, date, module: 'FI', docType: 'PAY', accountNo: receiptGl.no, accountName: receiptGl.name, costCenter: 'CC-SLS', debit: amount, credit: 0, currency: currentClient.currency, description: `${method.replace('_', ' ')} receipt for ${invoice.invNo}`, createdBy: currentUser.username, clientId: currentClient.id },
      { id: `${uniqueId('JL')}-2`, docNo, period, date, module: 'FI', docType: 'PAY', accountNo: '110000', accountName: `Trade Receivables (${invoice.customerName})`, costCenter: 'CC-SLS', debit: 0, credit: settleTotal, currency: currentClient.currency, description: `Partial/full receipt for ${invoice.invNo}`, createdBy: currentUser.username, clientId: currentClient.id },
    ];
    if (wht > 0) entries.push({ id: `${uniqueId('JL')}-3`, docNo, period, date, module: 'FI', docType: 'PAY', accountNo: '115000', accountName: 'Withholding Tax Receivable — GRA Credit Notes', costCenter: 'CC-SLS', debit: wht, credit: 0, currency: currentClient.currency, description: `VAT withheld at source by ${invoice.customerName} on ${invoice.invNo}`, createdBy: currentUser.username, clientId: currentClient.id });
    if (aboveMakerLimit(amount)) {
      return queuePaymentApproval(docNo, `Customer receipt: ${invoice.customerName} (${invoice.invNo})`, amount, entries,
        { kind: 'customer', clientId: currentClient.id, targetId: invoice.id, settleAmount: settleTotal, cashDelta: amount, bankId: funding.id });
    }
    const result = handleAddJournalLines(entries);
    if (!result) return 'failed';
    const paidAmount = Math.min(invoice.totalReceivable, invoice.paidAmount + settleTotal);
    setSalesInvoices(previous => previous.map(i => i.id === invoice.id ? { ...i, paidAmount, status: paidAmount + 0.009 >= i.totalReceivable ? 'Paid' : 'Partial' } : i));
    setBankAccounts(previous => previous.map(b => b.id === funding.id ? { ...b, balance: round2(b.balance + amount) } : b));
    return 'posted';
  };

  const handleDisburseSalaries = (period: string, amount: number, bankId: number, method: PaymentMethod, payee?: PaymentPayee): PaymentResult => {
    const date = postDate();
    const payPeriod = periodFrom(date);
    if (isPeriodClosed) return 'failed';
    const bank = bankAccounts.find(b => b.id === bankId);
    if (!bank || amount <= 0) return 'failed';
    const payable = liabilityBalance(lines, currentClient.id, '205000');
    if (amount > payable + 0.009) return 'failed';
    const funding = fundingAccountFor(method, bank);
    if (funding.balance + 0.009 < amount) return 'failed';
    const paymentGl = paymentAccountFor(method, funding);
    const docNo = uniqueDocNo(`PAY-SAL-${period}`, currentClient.id);
    const entries: ACDOCALine[] = [
      { id: `${uniqueId('JL')}-1`, docNo, period: payPeriod, date, module: 'HR', docType: 'PAY', accountNo: '205000', accountName: 'Net Salaries Payable', costCenter: 'CC-HR', debit: amount, credit: 0, currency: currentClient.currency, description: `Net salary release for ${period}${payeeSuffix(payee)}`, createdBy: currentUser.username, clientId: currentClient.id },
      { id: `${uniqueId('JL')}-2`, docNo, period: payPeriod, date, module: 'FI', docType: 'PAY', accountNo: paymentGl.no, accountName: paymentGl.name, costCenter: 'CC-HR', debit: 0, credit: amount, currency: currentClient.currency, description: `Payroll ${method.replace('_', ' ')}${payeeSuffix(payee)}`, createdBy: currentUser.username, clientId: currentClient.id },
    ];
    if (aboveMakerLimit(amount)) {
      return queuePaymentApproval(docNo, `Net payroll release for ${period}${payeeSuffix(payee)}`, amount, entries,
        { kind: 'salary', clientId: currentClient.id, settleAmount: amount, cashDelta: -amount, bankId: funding.id });
    }
    const result = handleAddJournalLines(entries);
    if (result) setBankAccounts(previous => previous.map(b => b.id === funding.id ? { ...b, balance: round2(b.balance - amount) } : b));
    return result ? 'posted' : 'failed';
  };

  // Expense bills recorded at the Expenses & Statutory desk are paid ONLY here:
  // Dr 202000 Accrued Expenses & Other Payables (reference = bill no) / Cr treasury,
  // with optional income WHT that itself becomes a statutory payable (209000).
  const handleSettleExpenseBill = (input: {
    bill: ExpenseBill; grossAmount: number; whtRate: number; bankId: number; method: PaymentMethod; reference: string;
  } & PaymentExtras): PaymentResult => {
    const { bill, grossAmount, whtRate, bankId, method, reference, payee, whtNote } = input;
    const date = postDate();
    const period = periodFrom(date);
    if (isPeriodClosed) return 'failed';
    const liveBill = deriveExpenseBills(lines, currentClient.id).find(b => b.billNo === bill.billNo);
    if (!liveBill || grossAmount <= 0 || grossAmount > liveBill.outstanding + 0.009) return 'failed';
    const bank = bankAccounts.find(b => b.id === bankId);
    if (!bank) return 'failed';
    const taxBase = liveBill.gross > 0 ? grossAmount * ((liveBill.gross - liveBill.vat) / liveBill.gross) : 0;
    const incomeWht = Math.round(taxBase * whtRate) / 100;
    const cashPaid = round2(grossAmount - incomeWht);
    const funding = fundingAccountFor(method, bank);
    if (cashPaid < 0 || funding.balance + 0.009 < cashPaid) return 'failed';
    const paymentGl = paymentAccountFor(method, funding);
    const docNo = uniqueDocNo(reference || `PAY-${liveBill.billNo.replace('EXPB-', '')}`, currentClient.id);
    const base = { docNo, period, date, module: 'FI' as const, docType: 'PAY' as const, costCenter: liveBill.costCenter, currency: currentClient.currency, createdBy: currentUser.username, clientId: currentClient.id, reference: liveBill.billNo };
    const entries: ACDOCALine[] = [
      { ...base, id: `${uniqueId('JL')}-1`, accountNo: EXPENSE_PAYABLE_ACCOUNT, accountName: `Accrued Expenses & Other Payables (${liveBill.payee})`, debit: grossAmount, credit: 0, description: `Payment of expense bill ${liveBill.billNo} to ${liveBill.payee}${payee && payee.name.trim() !== liveBill.payee ? payeeSuffix(payee) : ''}` },
      { ...base, id: `${uniqueId('JL')}-2`, accountNo: paymentGl.no, accountName: paymentGl.name, debit: 0, credit: cashPaid, description: `${method.replace('_', ' ')} payment for ${liveBill.billNo}${payeeSuffix(payee)}${whtSuffix(whtRate > 0, whtRate, whtNote)}` },
    ];
    if (incomeWht > 0) entries.push({ ...base, id: `${uniqueId('JL')}-3`, accountNo: '209000', accountName: 'Income Withholding Tax Payable', debit: 0, credit: incomeWht, description: `Income WHT ${whtRate}% on expense bill ${liveBill.billNo}` });
    if (aboveMakerLimit(grossAmount)) {
      return queuePaymentApproval(docNo, `Expense bill payment: ${liveBill.payee} (${liveBill.billNo})${payee && payee.name.trim() !== liveBill.payee ? payeeSuffix(payee) : ''}`, grossAmount, entries,
        { kind: 'expense', clientId: currentClient.id, targetId: liveBill.billNo, settleAmount: grossAmount, cashDelta: -cashPaid, bankId: funding.id });
    }
    const result = handleAddJournalLines(entries);
    if (!result) return 'failed';
    setBankAccounts(previous => previous.map(b => b.id === funding.id ? { ...b, balance: round2(b.balance - cashPaid) } : b));
    return 'posted';
  };

  // Statutory remittance (PAYE, SSNIT Tier 1 13.5%, Tier 2 5%, WHT, VAT, levies, CIT):
  // Dr the statutory liability registered by payroll/sales/settlements / Cr treasury.
  const handleRemitStatutory = (input: {
    row: StatutoryPayableRow; amount: number; bankId: number; method: PaymentMethod; reference: string;
  } & PaymentExtras): PaymentResult => {
    const { row, amount, bankId, method, reference, payee } = input;
    const date = postDate();
    const period = periodFrom(date);
    if (isPeriodClosed) return 'failed';
    const balance = liabilityBalance(lines, currentClient.id, row.accountNo);
    if (amount <= 0 || amount > balance + 0.009) return 'failed';
    const bank = bankAccounts.find(b => b.id === bankId);
    if (!bank) return 'failed';
    const funding = fundingAccountFor(method, bank);
    if (funding.balance + 0.009 < amount) return 'failed';
    const paymentGl = paymentAccountFor(method, funding);
    const accountName = visibleAccounts.find(a => a.accountNo === row.accountNo)?.name || row.label;
    const docNo = uniqueDocNo(reference || `STAT-${row.accountNo}-${period}`, currentClient.id);
    const costCenter = row.payroll ? 'CC-HR' : 'CC-ADM';
    const entries: ACDOCALine[] = [
      { id: `${uniqueId('JL')}-1`, docNo, period, date, module: 'FI', docType: 'PAY', accountNo: row.accountNo, accountName, costCenter, debit: amount, credit: 0, currency: currentClient.currency, description: `Statutory remittance: ${row.label} to ${payee?.name.trim() || row.authority}${payee ? ` (${payee.kind})` : ''}`, createdBy: currentUser.username, clientId: currentClient.id },
      { id: `${uniqueId('JL')}-2`, docNo, period, date, module: 'FI', docType: 'PAY', accountNo: paymentGl.no, accountName: paymentGl.name, costCenter, debit: 0, credit: amount, currency: currentClient.currency, description: `${method.replace('_', ' ')} remittance ${docNo}`, createdBy: currentUser.username, clientId: currentClient.id },
    ];
    if (aboveMakerLimit(amount)) {
      return queuePaymentApproval(docNo, `Statutory remittance: ${row.label} → ${payee?.name.trim() || row.authority}`, amount, entries,
        { kind: 'statutory', clientId: currentClient.id, targetId: row.accountNo, settleAmount: amount, cashDelta: -amount, bankId: funding.id });
    }
    const result = handleAddJournalLines(entries);
    if (!result) return 'failed';
    setBankAccounts(previous => previous.map(b => b.id === funding.id ? { ...b, balance: round2(b.balance - amount) } : b));
    return 'posted';
  };

  const handlePostMonthlyPayroll = (period: string, journalLines: ACDOCALine[], records: MonthlyPayrollRecord[]): boolean => {
    if (isPeriodClosed || journalLines.some((l) => l.clientId !== currentClient.id || l.period !== period)) return false;
    if (lines.some((l) => l.clientId === currentClient.id && l.docNo === `PAYROLL-${period}`)) return false;
    const result = handleAddJournalLines(journalLines);
    if (result) {
      // Merge: never wipe previously posted payroll periods for this entity.
      const others = persistentStorage.getPayrollRecords().filter((r) => !(r.clientId === currentClient.id && r.period === period));
      persistentStorage.savePayrollRecords([...others, ...records.map((r) => ({ ...r, clientId: currentClient.id }))]);
    }
    return result;
  };

  const handleUpdateNote = (updated: DisclosureNote) => {
    setNotes(notes.map((n) => (n.key === updated.key ? updated : n)));
  };

  // Immutable counter-reversal: posts to the CURRENT period (never the frozen
  // original period), balanced by construction, one reversal per document, and
  // flags the original lines so the books and the audit trail agree.
  const handleReverseDocument = (docNo: string): boolean => {
    const today = new Date().toISOString();
    const period = today.slice(0, 7);
    const check = checkReversal(lines, docNo, currentClient.id, {
      currentPeriod: period,
      closedPeriods: closedPeriodsMap[currentClient.id] || [],
    });
    if (!check.ok) {
      pushNotice(`Reversal refused: ${check.reason}.`);
      return false;
    }
    const original = lines.filter((l) => l.clientId === currentClient.id && l.docNo === docNo);
    const revLines = buildReversalLines(original, { username: currentUser.username, canCheck: currentUser.canCheck, period, date: today.slice(0, 10) });
    // Reversals must post in the ORIGINAL document's currency (a foreign-currency
    // purchase reversed in the entity's functional currency was silently refused).
    const ok = handleAddJournalLines(revLines, original[0].currency, currentClient.id);
    if (ok) {
      setLines((prev) => prev.map((l) => (l.clientId === currentClient.id && l.docNo === docNo ? { ...l, isReversed: true } : l)));
    } else {
      pushNotice(`Reversal of ${docNo} was refused by the posting controls — the ledger is unchanged.`);
    }
    return ok;
  };

  // Year-end close: transfer the fiscal year's P/L to Retained Earnings (310000)
  // with one balanced document dated 31 December of the closed year.
  const handlePostYearEndClose = (year: number): { net: number; accounts: number } | null => {
    const yearLines = lines.filter((l) => l.clientId === currentClient.id && l.period.startsWith(`${year}-`));
    if (lines.some((l) => l.clientId === currentClient.id && l.docNo === `YE-CLOSE-${year}`)) return null;
    const result = buildYearEndCloseEntries(yearLines, visibleAccounts, {
      year,
      period: `${year}-12`,
      date: `${year}-12-31`,
      currency: currentClient.currency,
      username: currentUser.username,
      canCheck: currentUser.canCheck,
      clientId: currentClient.id,
    });
    if (!result) return null;
    const ok = handleAddJournalLines(result.lines, currentClient.currency, currentClient.id);
    return ok ? { net: result.net, accounts: result.accountsClosed.length } : null;
  };

  // Approval loop: approving a request posts its proposed journal lines exactly
  // once, with the approver as the independent checker of record. Payment requests
  // also carry settlement metadata — on approval the treasury balance moves and the
  // supplier/customer document is settled, so the payment is actually effected.
  const handleApprovePost = (req: { payload?: { lines: ACDOCALine[]; settlement?: PaymentSettlementMeta }; clientId: number }): boolean => {
    const proposed = req.payload?.lines || [];
    if (!proposed.length) return false;
    const settlement = req.payload?.settlement;
    if (settlement && settlement.cashDelta < 0) {
      const fundingBank = bankAccounts.find((b) => b.id === settlement.bankId);
      if (!fundingBank || fundingBank.balance + 0.009 < -settlement.cashDelta) {
        pushNotice(`Approved payment ${req.payload?.lines[0]?.docNo || ''} could NOT be effected: insufficient funds in ${fundingBank?.name || 'the funding account'}. Top up treasury and re-submit.`);
        return false;
      }
    }
    const withChecker = proposed.map((l) => ({ ...l, checkedBy: currentUser.username }));
    const posted = handleAddJournalLines(withChecker, undefined, req.clientId);
    if (posted && settlement) {
      setBankAccounts((prev) => prev.map((b) => b.id === settlement.bankId ? { ...b, balance: Math.round((b.balance + settlement.cashDelta) * 100) / 100 } : b));
      if (settlement.kind === 'supplier' && settlement.targetId) {
        setPurchaseOrders((prev) => prev.map((p) => {
          if (p.id !== settlement.targetId) return p;
          const paidAmount = Math.min(p.totalAmount, (p.paidAmount || 0) + settlement.settleAmount);
          return { ...p, paidAmount, status: paidAmount + 0.009 >= p.totalAmount ? 'Paid' : 'Invoiced' };
        }));
      }
      if (settlement.kind === 'customer' && settlement.targetId) {
        setSalesInvoices((prev) => prev.map((i) => {
          if (i.id !== settlement.targetId) return i;
          const paidAmount = Math.min(i.totalReceivable, i.paidAmount + settlement.settleAmount);
          return { ...i, paidAmount, status: paidAmount + 0.009 >= i.totalReceivable ? 'Paid' : 'Partial' };
        }));
      }
      // expense / statutory / salary: the payable register is derived from the
      // ledger, so posting the journal already clears the obligation.
    }
    return posted;
  };

  // Guard against clients viewing private owner administration sections
  const ownerOnlySections = [
    'clients_management',
    'advisory',
    'user_permissions',
    'group_consolidation',
    'enterprise_sso',
    'global_tax',
    'tax_settings',
    'soc_dr',
    'realtime_integrations',
  ];

  const effectiveSection = (!isOwner && ownerOnlySections.includes(activeSection)) || !maySeeSection(currentUser, currentClient, activeSection)
    ? 'dashboard'
    : activeSection;

  // Entity isolation guard: never render one client's workspace under another
  // client's account (e.g. a stale or orphaned assignment).
  if (workspaceMissing) {
    return (
      <div className="min-h-screen bg-[#f0f6fc] text-[#0a253e] flex items-center justify-center p-6 font-sans">
        <div className="max-w-md rounded-xl border border-rose-300 bg-rose-50 p-6 text-center shadow-xs">
          <p className="text-sm font-black uppercase tracking-wider text-rose-900 mb-2">No workspace assigned</p>
          <p className="text-xs font-semibold text-rose-800 leading-relaxed">
            This account (<span className="font-mono">{currentUser.username}</span>) is not bound to an active client
            entity, so no other client&rsquo;s information can be shown. Contact the firm owner to restore the workspace
            assignment, or sign out.
          </p>
          <button onClick={onSignOut} className="mt-4 rounded-lg bg-[#b42318] px-4 py-2 text-xs font-bold text-white hover:bg-rose-800">
            Sign Out
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="app-shell h-dvh overflow-hidden bg-[#f0f6fc] text-[#0a253e] flex flex-col font-sans">
      {/* Top Header */}
      <AccountingHeader
        key={currentClient.id}
        currentClient={currentClient}
        clients={clients}
        onSelectClient={(c) => setCurrentClientId(c.id)}
        currentUser={currentUser}
        onSignOut={onSignOut}
        isBalanced={isBalanced}
        totalLines={clientLines.length}
        totalDocs={uniqueDocs}
        activeSection={effectiveSection}
        pendingApprovalsCount={approvalsCount}
        onOpenApprovals={() => setIsApprovalsModalOpen(true)}
      />

      {/* Approvals Drawer / Modal */}
        <ApprovalsModal
          isOpen={isApprovalsModalOpen}
          onClose={() => {
            setIsApprovalsModalOpen(false);
            refreshApprovalsCount();
          }}
          currentUser={currentUser}
          currentClient={currentClient}
          allowFirmWide={hasFirmWideScope(currentUser)}
          onApprovalResolved={refreshApprovalsCount}
          onApprovePost={handleApprovePost}
        />

      {/* System notices: every failed server-side operation is surfaced here explicitly. */}
      {systemNotices.length > 0 && (
        <div role="alert" className="shrink-0 max-h-40 overflow-y-auto border-b border-rose-300 bg-rose-50 px-4 py-2.5">
          <div className="flex items-start justify-between gap-4">
            <div>
              <span className="block text-[11px] font-black uppercase tracking-wider text-rose-800">
                System notices — nothing failed silently
              </span>
              <ul className="mt-1 space-y-0.5 text-[11.5px] font-semibold text-rose-900 list-disc pl-4">
                {systemNotices.map((n) => (
                  <li key={n}>{n}</li>
                ))}
              </ul>
            </div>
            <button
              onClick={() => setSystemNotices([])}
              className="shrink-0 rounded border border-rose-300 bg-white px-2.5 py-1 text-[11px] font-bold text-rose-800 hover:bg-rose-100"
            >
              Dismiss
            </button>
          </div>
        </div>
      )}

      {/* Main Shell */}
      {/* Mobile bar: the menu is a drawer on phones/tablets so page content is never pushed below a 30-item list. */}
      <div className="md:hidden shrink-0 flex items-center gap-2 border-b border-sky-200 bg-white px-3 py-2">
        <button
          onClick={() => setMobileNavOpen(true)}
          aria-label="Open navigation menu"
          aria-expanded={mobileNavOpen}
          className="flex items-center gap-1.5 rounded-lg bg-[#082f4f] px-3 py-1.5 text-xs font-bold text-white"
        >
          <Menu className="h-4 w-4" /> Menu
        </button>
        <span className="truncate text-xs font-black uppercase tracking-wider text-[#082f4f]">{effectiveSection.replace(/_/g, ' ')}</span>
      </div>

      <div className="flex-1 flex min-h-0">
        {/* Sidebar */}
        <AccountingSidebar
          activeSection={effectiveSection}
          onSelectSection={setActiveSection}
          currentClient={currentClient}
          currentUser={currentUser}
          mobileOpen={mobileNavOpen}
          onCloseMobile={() => setMobileNavOpen(false)}
        />

        {/* Center Content Workspace — scrolls independently of the menu */}
        <main ref={mainRef} className="flex-1 min-w-0 overflow-y-auto overflow-x-hidden p-3 sm:p-6 lg:p-7">
          <div className="max-w-7xl mx-auto space-y-6">
            <div role="note" className="rounded-lg border border-amber-400 bg-amber-50 px-3 py-2 text-xs font-bold text-amber-950">
              Workspace notice: While signed in, entries sync to the firm&rsquo;s server; offline changes stay in this browser and sync on the next connection.
              Figures remain draft working papers — obtain professional review before statutory filing.
            </div>
            {/* A fault inside one desk must never blank the whole workspace. */}
            <ModuleErrorBoundary
              moduleKey={`${effectiveSection}:${currentClient.id}`}
              label={effectiveSection.replace(/_/g, ' ')}
              onBackToDashboard={() => setActiveSection('dashboard')}
            >
            {effectiveSection === 'dashboard' && (
              <AccountingDashboard
                key={currentClient.id}
                currentClient={currentClient}
                lines={lines}
                onNavigate={setActiveSection}
              />
            )}

            {effectiveSection === 'procurement' && (
              <ProcurementSection
                key={currentClient.id}
                currentClient={currentClient}
                purchaseOrders={visibleOrders}
                partners={visiblePartners}
                accounts={visibleAccounts}
                onAddPO={(po) => setPurchaseOrders(previous => [...previous, { ...po, clientId: currentClient.id }])}
                onPostPOToJournal={handlePostPOToJournal}
                onIssueDebitNote={handleIssueDebitNote}
              />
            )}

            {effectiveSection === 'sales' && (
              <SalesSection
                key={currentClient.id}
                currentClient={currentClient}
                salesInvoices={visibleInvoices}
                partners={visiblePartners}
                onAddInvoice={(inv) => setSalesInvoices(previous => [...previous, { ...inv, clientId: currentClient.id }])}
                onPostSalesToJournal={handlePostSalesToJournal}
                onIssueCreditNote={handleIssueCreditNote}
              />
            )}

            {effectiveSection === 'business_partners' && (
              <BusinessPartnersSection
                key={currentClient.id}
                currentClient={currentClient}
                partners={visiblePartners}
                salesInvoices={visibleInvoices}
                purchaseOrders={visibleOrders}
                onAddPartner={(newP) => setBusinessPartners(previous => [...previous, { ...newP, clientId: currentClient.id }])}
              />
            )}

            {effectiveSection === 'opening_balance' && (
              <OpeningBalanceSection
                key={currentClient.id}
                currentClient={currentClient}
                currentUser={currentUser}
                accounts={visibleAccounts}
                lines={lines}
                closedPeriods={closedPeriods}
                onAddJournalLines={handleAddJournalLines}
              />
            )}

            {effectiveSection === 'payroll' && (
              <PayrollSection
                key={currentClient.id}
                currentClient={currentClient}
                employees={visibleEmployees}
                lines={lines}
                currentUser={currentUser}
                isPeriodClosed={isPeriodClosed}
                onAddEmployee={(emp) => setEmployees(previous => [...previous, { ...emp, clientId: currentClient.id }])}
                onPostMonthlyPayroll={handlePostMonthlyPayroll}
              />
            )}

            {effectiveSection === 'banking' && (
              <BankingSection
                key={currentClient.id}
                currentClient={currentClient}
                currentUser={currentUser}
                bankAccounts={visibleBanks}
                lines={lines}
                accounts={visibleAccounts}
                onAddBankAccount={(newAcc) => setBankAccounts(previous => [...previous, { ...newAcc, clientId: currentClient.id }])}
                onAddJournalLines={handleAddJournalLines}
              />
            )}

            {effectiveSection === 'company_profile' && (
              <CompanyProfileSection
                key={currentClient.id}
                currentClient={currentClient}
                isOwner={isOwner}
                clients={clients}
                onUpdateClientName={(newName) => {
                  setClients(clients.map((c) => (c.id === currentClient.id ? { ...c, name: newName } : c)));
                }}
                onRefreshAllData={handleRefreshAllData}
              />
            )}

            {effectiveSection === 'payment_desk' && (
              <PaymentDeskSection
                key={currentClient.id}
                currentClient={currentClient}
                currentUser={currentUser}
                purchaseOrders={visibleOrders}
                salesInvoices={visibleInvoices}
                bankAccounts={visibleBanks}
                partners={visiblePartners}
                employees={visibleEmployees}
                lines={lines}
                isPeriodClosed={isPeriodClosed}
                onSettleSupplierInvoice={handleSettleSupplierInvoice}
                onReceiveCustomerPayment={handleReceiveCustomerPayment}
                onDisburseSalaries={handleDisburseSalaries}
                onSettleExpenseBill={handleSettleExpenseBill}
                onRemitStatutory={handleRemitStatutory}
                onApprovalSubmitted={refreshApprovalsCount}
              />
            )}

             {effectiveSection === 'expenses' && (
               <ExpensesSection
                 key={currentClient.id}
                 currentClient={currentClient}
                 currentUser={currentUser}
                 isPeriodClosed={isPeriodClosed}
                 lines={lines}
                 accounts={visibleAccounts}
                 onAddJournalLines={handleAddJournalLines}
                 onNavigate={setActiveSection}
                 onApprovalSubmitted={refreshApprovalsCount}
               />
             )}

             {effectiveSection === 'inventory' && (
               <InventorySection
                 key={currentClient.id}
                 currentClient={currentClient}
                 currentUser={currentUser}
                 isPeriodClosed={isPeriodClosed}
                 lines={lines}
                 onAddJournalLines={handleAddJournalLines}
               />
             )}

             {effectiveSection === 'prepayments' && (
               <PrepaymentsSection
                 key={currentClient.id}
                 currentClient={currentClient}
                 currentUser={currentUser}
                 isPeriodClosed={isPeriodClosed}
                 lines={lines}
                 accounts={visibleAccounts}
                 bankAccounts={visibleBanks}
                 partners={visiblePartners}
                 onAddJournalLines={handleAddJournalLines}
                 onBankBalanceChange={(bankId, delta) => setBankAccounts(previous => previous.map(b => b.id === bankId ? { ...b, balance: Math.round((b.balance + delta) * 100) / 100 } : b))}
               />
             )}

             {effectiveSection === 'assets' && (
               <FixedAssetsSection
                 key={currentClient.id}
                 currentClient={currentClient}
                 currentUser={currentUser}
                 isPeriodClosed={isPeriodClosed}
                 lines={lines}
                 bankAccounts={visibleBanks}
                 onAddJournalLines={handleAddJournalLines}
                 onBankBalanceChange={(bankId, delta) => setBankAccounts(previous => previous.map(b => b.id === bankId ? { ...b, balance: Math.round((b.balance + delta) * 100) / 100 } : b))}
               />
             )}

            {effectiveSection === 'coa_master' && (
              <ChartOfAccountsSection
                key={currentClient.id}
                currentClient={currentClient}
                accounts={visibleAccounts}
                lines={lines}
                onAddAccount={(newAcc) => setChartOfAccounts([...chartOfAccounts, { ...newAcc, clientId: currentClient.id }])}
              />
            )}

            {effectiveSection === 'universal_journal' && (
              <ManualJournalSection
                key={currentClient.id}
                currentClient={currentClient}
                currentUser={currentUser}
                lines={lines}
                accounts={visibleAccounts}
                onAddJournalLines={handleAddJournalLines}
                onReverseDocument={handleReverseDocument}
                isPeriodClosed={isPeriodClosed}
                onApprovalSubmitted={refreshApprovalsCount}
              />
            )}

            {effectiveSection === 'manual_journal' && (
              <ManualJournalSection
                key={currentClient.id}
                currentClient={currentClient}
                currentUser={currentUser}
                lines={lines}
                accounts={visibleAccounts}
                onAddJournalLines={handleAddJournalLines}
                onReverseDocument={handleReverseDocument}
                isPeriodClosed={isPeriodClosed}
                onApprovalSubmitted={refreshApprovalsCount}
              />
            )}

            {effectiveSection === 'standards_desk' && (
              <ComprehensiveStandardsDesk
                key={currentClient.id}
                currentClient={currentClient}
                currentUser={currentUser}
                lines={lines}
                onAddJournalLines={handleAddJournalLines}
                onNavigateSection={setActiveSection}
              />
            )}

            {effectiveSection === 'loans_desk' && (
              <LoansAmortisationDesk
                key={currentClient.id}
                currentClient={currentClient}
                currentUser={currentUser}
                onAddJournalLines={handleAddJournalLines}
              />
            )}

            {effectiveSection === 'financial_reports' && (
              <FinancialReportsSection
                key={currentClient.id}
                currentClient={currentClient}
                clients={hasFirmWideScope(currentUser) ? clients : clients.filter((c) => c.id === currentClient.id)}
                currentUser={currentUser}
                onSelectClient={(c) => setCurrentClientId(c.id)}
                lines={lines}
                accounts={visibleAccounts}
                onOpenNotesToAccounts={() => setActiveSection('disclosures')}
              />
            )}

            {effectiveSection === 'tax_schedule' && (
              <TaxFilingScheduleSection
                key={currentClient.id}
                currentClient={currentClient}
                currentUser={currentUser}
                lines={lines}
                accounts={visibleAccounts}
                onAddJournalLines={handleAddJournalLines}
                isPeriodClosed={isPeriodClosed}
              />
            )}

            {effectiveSection === 'disclosures' && (
              <DisclosureNotesDesk
                currentWorkspace={currentClient as any}
                notes={notes as any}
                onUpdateNote={handleUpdateNote as any}
              />
            )}

            {effectiveSection === 'adjustments' && (
              <AdjustmentsDesk
                key={currentClient.id}
                currentClient={currentClient}
                currentUser={currentUser}
                accounts={visibleAccounts}
                lines={lines}
                closedPeriods={closedPeriods}
                isPeriodClosed={isPeriodClosed}
                onAddJournalLines={handleAddJournalLines}
                onReverseDocument={handleReverseDocument}
              />
            )}

             {effectiveSection === 'month_end' && (
              <MonthEndSection
                key={currentClient.id}
                currentClient={currentClient}
                currentUser={currentUser}
                lines={lines}
                accounts={visibleAccounts}
                onPostYearEndClose={handlePostYearEndClose}
                closedPeriods={closedPeriods}
                onTogglePeriodClose={(period) => setClosedPeriodsMap((prev) => {
                   const list = prev[currentClient.id] || [];
                   const next = list.includes(period) ? list.filter((p) => p !== period) : [...list, period];
                   return { ...prev, [currentClient.id]: next };
                 })}
               />
             )}

            {/* Owner/Firm Practice & Enterprise Administration (Strictly Private to Owner) */}
            {isOwner && effectiveSection === 'clients_management' && (
              <ClientsManagementSection
                key={currentClient.id}
                currentClient={currentClient}
                clients={clients}
                onAddClient={(newC) => {
                  setClients([...clients, newC]);
                  setCurrentClientId(newC.id);
                }}
                onSwitchClient={(c) => setCurrentClientId(c.id)}
              />
            )}

             {isOwner && effectiveSection === 'advisory' && (
               <AdvisorySection currentClient={currentClient} currentUser={currentUser} />
             )}

            {isOwner && effectiveSection === 'user_permissions' && (
              <UserPermissionsDesk onRefreshUsers={handleRefreshAllData} />
            )}

            {isOwner && effectiveSection === 'group_consolidation' && (
              <ConsolidationDesk
                clients={clients}
                lines={lines}
                accounts={visibleAccounts}
              />
            )}

            {isOwner && effectiveSection === 'enterprise_sso' && (
              <SsoDesk onLoginAsSsoUser={onSwitchUser as any} />
            )}

            {isOwner && effectiveSection === 'tax_settings' && (
              <TaxSettingsDesk />
            )}

            {isOwner && effectiveSection === 'global_tax' && (
              <GlobalTaxDesk />
            )}

            {isOwner && effectiveSection === 'soc_dr' && (
              <SocBackupDesk />
            )}

            {isOwner && effectiveSection === 'realtime_integrations' && (
              <IntegrationsDesk />
            )}
            </ModuleErrorBoundary>
          </div>
        </main>
      </div>
    </div>
  );
}

export default App;
