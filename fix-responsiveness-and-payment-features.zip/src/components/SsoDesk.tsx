import { useState } from 'react';
import { ShieldOff, KeyRound, UserCheck } from 'lucide-react';
import type { UserAccount } from '../types/accounting';

interface SsoDeskProps {
  onLoginAsSsoUser?: (user: UserAccount) => void;
}

const SCOPE_TASKS = [
  { id: 'idp', label: 'Identity provider (SAML 2.0 / OIDC)', status: 'blocked', note: 'No authentication server. Browser-only sign-in.' },
  { id: 'scim', label: 'SCIM 2.0 user provisioning', status: 'blocked', note: 'Cannot deprovision from browser storage.' },
  { id: 'jit', label: 'Just-in-time access & revocation', status: 'blocked', note: 'Sessions are local and not centrally enforced.' },
  { id: 'mfa', label: 'Multi-factor authentication', status: 'blocked', note: 'Owner and demo logins rely on a single password.' },
  { id: 'audit', label: 'Audit trail of federation events', status: 'blocked', note: 'No server-side log exists.' },
];

const PLAN = [
  'Provision an identity provider (Azure AD, Okta, Auth0, Keycloak) for SAML 2.0 / OIDC.',
  'Map IdP groups to BPZ roles and tenancy in a database, never in browser storage.',
  'Implement SCIM 2.0 provisioning and deprovisioning from the IdP, with one-way TLS to the API.',
  'Enforce MFA, conditional access, and short-lived sessions server-side.',
  'Add cryptographic audit logging written from the API to a tamper-evident store (append-only).',
];

export const SsoDesk: React.FC<SsoDeskProps> = ({ onLoginAsSsoUser }) => {
  const [step, setStep] = useState(0);
  const [feedback, setFeedback] = useState<string | null>(null);

  const handleShowNext = () => {
    const next = Math.min(step + 1, PLAN.length - 1);
    setStep(next);
    setFeedback(`Step ${next + 1} of ${PLAN.length}: ${PLAN[next]}`);
  };

  return (
    <div className="space-y-6 text-[#0a253e]">
      <div className="rounded-xl border border-amber-400 bg-amber-50 p-4 text-sm text-amber-950 flex items-start gap-2">
        <ShieldOff className="h-5 w-5 mt-0.5 text-amber-700 shrink-0" />
        <div>
          <strong>Demo only.</strong> No federation, SCIM, or single sign-on is operating here. The items
          below are deployment tasks. Do not claim to clients that this system is SSO-ready.
        </div>
      </div>

      <div className="rounded-xl border border-sky-200 bg-white p-5 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-sky-200 pb-3">
          <h3 className="text-sm font-bold uppercase tracking-wider text-[#082f4f] flex items-center gap-2">
            <KeyRound className="h-4 w-4 text-[#006f98]" /> Federation roadmap
          </h3>
          <button onClick={handleShowNext} className="rounded-lg bg-[#082f4f] px-4 py-2 text-xs font-bold text-white hover:bg-[#0c3f68] transition shadow-xs">
            Show next step
          </button>
        </div>
        <ol className="space-y-2 text-xs text-[#082f4f]">
          {PLAN.map((text, idx) => (
            <li key={idx} className={`rounded-lg border p-3 flex items-start gap-3 ${idx <= step ? 'border-emerald-300 bg-emerald-50' : 'border-sky-200 bg-sky-50/40'}`}>
              <span className={`mt-0.5 inline-flex items-center justify-center w-5 h-5 rounded-full text-[10px] font-black ${idx <= step ? 'bg-emerald-600 text-white' : 'bg-sky-200 text-[#082f4f]'}`}>{idx + 1}</span>
              <div>
                <div className="font-bold">{text}</div>
                {idx === step && <div className="text-[#006f98] mt-0.5">Currently shown</div>}
              </div>
            </li>
          ))}
        </ol>

        {feedback && (
          <div className="rounded border border-emerald-300 bg-emerald-50 p-2.5 text-xs font-bold text-emerald-900">{feedback}</div>
        )}
      </div>

      <div className="rounded-xl border border-sky-200 bg-white p-5 shadow-xs">
        <h3 className="text-sm font-bold uppercase tracking-wider text-[#082f4f] mb-3">Federated identity features required for procurement</h3>
        <div className="overflow-x-auto">
        <table className="w-full text-xs">
          <thead>
            <tr className="border-b border-sky-200 bg-sky-50/70">
              <th className="text-left px-3 py-2">Requirement</th>
              <th className="text-left px-3 py-2">Current state</th>
              <th className="text-left px-3 py-2">Note</th>
            </tr>
          </thead>
          <tbody>
            {SCOPE_TASKS.map(t => (
              <tr key={t.id} className="border-b border-sky-100">
                <td className="px-3 py-2 font-bold text-[#082f4f]">{t.label}</td>
                <td className="px-3 py-2">
                  <span className="rounded bg-rose-100 text-rose-800 px-2 py-0.5 text-[10.5px] font-bold border border-rose-300">Not implemented</span>
                </td>
                <td className="px-3 py-2 text-[#2d4f6d]">{t.note}</td>
              </tr>
            ))}
          </tbody>
        </table>
        </div>
      </div>

      <div className="rounded-xl border border-sky-200 bg-white p-5 shadow-xs space-y-3">
        <h3 className="text-sm font-bold uppercase tracking-wider text-[#082f4f] flex items-center gap-2">
          <UserCheck className="h-4 w-4 text-emerald-700" /> Owner instructions
        </h3>
        <p className="text-xs text-[#2d4f6d]">
          When the server-side build is deployed, owners will assign a single identity per staff member,
          enforce MFA, and revoke sessions from the IdP. Until then, the &ldquo;Owner sign-in&rdquo; button on the
          workspace selector remains a local demo.
        </p>
        {onLoginAsSsoUser && (
          <button
            onClick={() => onLoginAsSsoUser({ username: 'owner', name: 'Kwesi Dadzie (Owner)', role: 'owner', makerLimit: 1000000, canCheck: true, email: 'k.dadzie@bpzconsult.com' })}
            className="rounded bg-sky-700 text-white text-xs font-bold px-4 py-2 hover:bg-sky-800 transition"
          >
            Owner demo login
          </button>
        )}
      </div>
    </div>
  );
};
