"use client";

import Link from "next/link";

export default function Error({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <div className="min-h-screen bg-[#f0f6fc] p-6 font-sans text-[#0a253e] flex items-center justify-center">
      <div className="max-w-lg space-y-3 rounded-2xl border border-rose-300 bg-white p-6 shadow-sm">
        <h1 className="text-base font-black uppercase tracking-wider text-rose-900">The workspace hit an error</h1>
        <p className="text-xs font-semibold leading-relaxed text-[#2d4f6d]">
          Your books are stored safely in this browser and on the firm&rsquo;s server — nothing was lost. Reload the
          workspace to continue; if the fault repeats, send the reference below to the support desk.
        </p>
        <pre className="max-h-40 overflow-auto rounded border border-sky-200 bg-sky-50 p-3 font-mono text-[11px] text-[#163653]">
          {error.message}
          {error.digest ? `\n\nReference: ${error.digest}` : ''}
        </pre>
        <div className="flex gap-2">
          <button onClick={reset} className="rounded-lg bg-[#082f4f] px-4 py-2 text-xs font-bold text-white hover:bg-[#0c3f68]">
            Reload workspace
          </button>
          <Link href="/" className="rounded-lg border border-sky-300 bg-white px-4 py-2 text-xs font-bold text-[#082f4f] hover:bg-sky-50">
            Return to sign-in
          </Link>
        </div>
      </div>
    </div>
  );
}
