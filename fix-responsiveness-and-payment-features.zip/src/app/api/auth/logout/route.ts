import { ensureDatabaseReady } from "@/db/bootstrap";
import { authJson, destroySession, readSessionToken } from "@/lib/auth";

export const dynamic = "force-dynamic";

/** Revokes the server session and clears the cookie on every carrier. */
export async function POST(req: Request) {
  try {
    await ensureDatabaseReady();
  } catch (e) {
    // Still clear the cookie: signing out must always work locally.
    console.error("logout: database unavailable", e);
    return authJson(req, { ok: true, degraded: true }, { clearCookie: true });
  }
  const token = readSessionToken(req);
  if (token) {
    try {
      await destroySession(token);
    } catch (e) {
      console.error("logout: could not revoke the server session", e);
    }
  }
  return authJson(req, { ok: true }, { clearCookie: true });
}
