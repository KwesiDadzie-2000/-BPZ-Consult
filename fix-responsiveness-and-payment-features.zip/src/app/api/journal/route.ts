import { ensureDatabaseReady } from "@/db/bootstrap";
import { db } from "@/db";
import { auditLog, chartAccounts, closedPeriods, clients, journalLines } from "@/db/schema";
import { authJson, getSessionUser, hasFirmWideScope } from "@/lib/auth";
import { validateJournalLines, validateMakerChecker } from "@/lib/journalValidation";
import { eq } from "drizzle-orm";
import type { ACDOCALine } from "@/types/accounting";

export const dynamic = "force-dynamic";

/**
 * Server-side posting service: validates the document (tenant ownership, open
 * period, chart-of-accounts existence, double entry in minor units, idempotent
 * document number) and inserts it with an audit-trail entry in one transaction.
 */
export async function POST(req: Request) {
  await ensureDatabaseReady();
  const user = await getSessionUser(req);
  if (!user) return authJson(req, { ok: false, error: "Unauthorized" }, { status: 401 });

  let lines: ACDOCALine[];
  try {
    const body = await req.json();
    lines = body?.lines;
  } catch {
    return Response.json({ ok: false, error: "Invalid payload." }, { status: 400 });
  }
  if (!Array.isArray(lines)) return Response.json({ ok: false, error: "No journal lines provided." }, { status: 400 });

  const isOwner = user.role === "owner";
  const myClientId = user.clientId ?? null;
  const allClients = await db.select().from(clients);
  const allowedClientIds = hasFirmWideScope(user) ? allClients.map((c) => c.id) : myClientId === null ? [] : [myClientId];
  const [coa, closed] = await Promise.all([
    db.select().from(chartAccounts),
    db.select().from(closedPeriods),
  ]);
  // Periods are frozen per entity: only the periods closed for this user's own
  // writable clients constrain posting.
  const closedKeys = new Set(
    closed.filter((c) => allowedClientIds.includes(c.clientId)).map((c) => `${c.clientId}:${c.period}`)
  );
  // COA scope: firm master plus the writable entities' custom accounts.
  const coaNos = new Set(coa.filter((a) => a.clientId === null || allowedClientIds.includes(a.clientId)).map((a) => a.accountNo));

  const error = validateJournalLines(lines, { allowedClientIds, closedPeriodKeys: closedKeys, coaAccountNos: coaNos });
  if (error) return Response.json({ ok: false, error }, { status: 409 });

  // Segregation of duties: above the maker limit an independent checker is required.
  const mcError = validateMakerChecker(lines, { username: user.username, makerLimit: user.makerLimit });
  if (mcError) return Response.json({ ok: false, error: mcError }, { status: 409 });

  // Idempotency: an identical document may be re-sent safely; any conflicting
  // content (including a superset of previously posted lines) is rejected with 409.
  for (const docNo of new Set(lines.map((l) => l.docNo))) {
    const clientId = lines.find((l) => l.docNo === docNo)!.clientId;
    const existing = await db.select().from(journalLines).where(eq(journalLines.docNo, docNo));
    const sameClient = existing.filter((l) => l.clientId === clientId);
    if (!sameClient.length) continue;
    const sentIds = new Set(lines.filter((l) => l.docNo === docNo).map((l) => l.id));
    const same = sameClient.length === sentIds.size && sameClient.every((e) => sentIds.has(e.id));
    if (same) return Response.json({ ok: true, idempotent: true });
    return Response.json({ ok: false, error: `Document ${docNo} already posted with different content.` }, { status: 409 });
  }

  await db.transaction(async (tx) => {
    await tx.insert(journalLines).values(
      lines.map((l) => ({
        id: l.id, docNo: l.docNo, period: l.period, date: l.date, module: l.module, docType: l.docType,
        accountNo: l.accountNo, accountName: l.accountName, costCenter: l.costCenter ?? null, debit: l.debit,
        credit: l.credit, currency: l.currency, description: l.description, createdBy: l.createdBy,
        checkedBy: l.checkedBy ?? null, isReversed: l.isReversed ?? false, reference: l.reference ?? null,
        clientId: l.clientId,
      }))
    );
    const dr = lines.reduce((n, l) => n + Math.round(l.debit * 100), 0) / 100;
    await tx.insert(auditLog).values({
      id: crypto.randomUUID(),
      timestamp: new Date().toISOString(),
      userId: user.username,
      username: user.username,
      action: "POST_JOURNAL",
      target: lines[0].docNo,
      details: `${lines.length} line(s), debits ${dr.toFixed(2)}`,
      clientId: lines[0].clientId,
    });
  });

  return Response.json({ ok: true, lines });
}
