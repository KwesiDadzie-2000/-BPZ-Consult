/**
 * Idempotent DDL generated from `src/db/schema.ts` with `drizzle-kit export`.
 *
 * Regenerate after schema changes:
 *   npx drizzle-kit export --sql > /tmp/ddl.sql   (then convert to IF NOT EXISTS)
 *
 * Applied automatically by `ensureDatabaseReady()` so a fresh database never
 * produces `relation "users" does not exist` (the original "Login failed." bug).
 */
export const SCHEMA_DDL: string[] = [
  "CREATE TABLE IF NOT EXISTS \"approval_requests\" (\n\t\"id\" text PRIMARY KEY NOT NULL,\n\t\"client_id\" integer NOT NULL,\n\t\"client_code\" text NOT NULL,\n\t\"client_name\" text NOT NULL,\n\t\"doc_no\" text NOT NULL,\n\t\"doc_type\" text NOT NULL,\n\t\"amount\" double precision NOT NULL,\n\t\"requested_by\" text NOT NULL,\n\t\"requested_at\" text NOT NULL,\n\t\"description\" text NOT NULL,\n\t\"reason_for_approval\" text NOT NULL,\n\t\"status\" text NOT NULL,\n\t\"reviewed_by\" text,\n\t\"reviewed_at\" text,\n\t\"rejection_reason\" text,\n\t\"payload\" jsonb\n)",
  "CREATE TABLE IF NOT EXISTS \"audit_log\" (\n\t\"id\" text PRIMARY KEY NOT NULL,\n\t\"timestamp\" text NOT NULL,\n\t\"user_id\" text NOT NULL,\n\t\"username\" text NOT NULL,\n\t\"action\" text NOT NULL,\n\t\"target\" text NOT NULL,\n\t\"details\" text NOT NULL,\n\t\"client_id\" integer\n)",
  "CREATE TABLE IF NOT EXISTS \"bank_accounts\" (\n\t\"id\" integer PRIMARY KEY NOT NULL,\n\t\"client_id\" integer NOT NULL,\n\t\"code\" text NOT NULL,\n\t\"name\" text NOT NULL,\n\t\"bank_name\" text NOT NULL,\n\t\"account_no\" text NOT NULL,\n\t\"currency\" text NOT NULL,\n\t\"balance\" double precision DEFAULT 0 NOT NULL,\n\t\"kind\" text,\n\t\"gl_account\" text\n)",
  "CREATE TABLE IF NOT EXISTS \"business_partners\" (\n\t\"id\" text PRIMARY KEY NOT NULL,\n\t\"client_id\" integer,\n\t\"code\" text NOT NULL,\n\t\"name\" text NOT NULL,\n\t\"type\" text NOT NULL,\n\t\"tin\" text NOT NULL,\n\t\"email\" text NOT NULL,\n\t\"phone\" text NOT NULL,\n\t\"address\" text NOT NULL,\n\t\"currency\" text NOT NULL,\n\t\"is_vat_withholding_agent\" boolean DEFAULT false NOT NULL,\n\t\"vat_withholding_rate\" double precision,\n\t\"is_cst_applicable\" boolean DEFAULT false NOT NULL,\n\t\"is_tourism_levy_applicable\" boolean DEFAULT false NOT NULL,\n\t\"is_vat_registered\" boolean\n)",
  "CREATE TABLE IF NOT EXISTS \"chart_accounts\" (\n\t\"id\" integer PRIMARY KEY GENERATED ALWAYS AS IDENTITY (sequence name \"chart_accounts_id_seq\" INCREMENT BY 1 MINVALUE 1 MAXVALUE 2147483647 START WITH 1 CACHE 1),\n\t\"account_no\" text NOT NULL,\n\t\"name\" text NOT NULL,\n\t\"type\" text NOT NULL,\n\t\"category\" text NOT NULL,\n\t\"active\" boolean DEFAULT true NOT NULL,\n\t\"is_custom\" boolean DEFAULT false NOT NULL,\n\t\"client_id\" integer\n)",
  "CREATE TABLE IF NOT EXISTS \"clients\" (\n\t\"id\" integer PRIMARY KEY NOT NULL,\n\t\"code\" text NOT NULL,\n\t\"name\" text NOT NULL,\n\t\"sector\" text NOT NULL,\n\t\"currency\" text NOT NULL,\n\t\"jurisdiction\" text NOT NULL,\n\t\"reg_number\" text NOT NULL,\n\t\"is_parent\" boolean DEFAULT false NOT NULL,\n\t\"assigned_services\" jsonb,\n\t\"admin_username\" text,\n\t\"admin_email\" text,\n\t\"login_url\" text\n)",
  "CREATE TABLE IF NOT EXISTS \"closed_periods\" (\n\t\"id\" integer PRIMARY KEY GENERATED ALWAYS AS IDENTITY (sequence name \"closed_periods_id_seq\" INCREMENT BY 1 MINVALUE 1 MAXVALUE 2147483647 START WITH 1 CACHE 1),\n\t\"client_id\" integer NOT NULL,\n\t\"period\" text NOT NULL,\n\t\"closed_at\" text NOT NULL,\n\t\"closed_by\" text NOT NULL\n)",
  "CREATE TABLE IF NOT EXISTS \"company_profiles\" (\n\t\"client_id\" integer PRIMARY KEY NOT NULL,\n\t\"legal_name\" text NOT NULL,\n\t\"trading_name\" text NOT NULL,\n\t\"tin\" text NOT NULL,\n\t\"vat_reg_no\" text NOT NULL,\n\t\"address\" text NOT NULL,\n\t\"phone\" text NOT NULL,\n\t\"email\" text NOT NULL,\n\t\"website\" text NOT NULL,\n\t\"fiscal_year_start\" text NOT NULL,\n\t\"bank_payment_details\" text NOT NULL\n)",
  "CREATE TABLE IF NOT EXISTS \"disclosure_notes\" (\n\t\"id\" integer PRIMARY KEY GENERATED ALWAYS AS IDENTITY (sequence name \"disclosure_notes_id_seq\" INCREMENT BY 1 MINVALUE 1 MAXVALUE 2147483647 START WITH 1 CACHE 1),\n\t\"key\" text NOT NULL,\n\t\"note_number\" integer NOT NULL,\n\t\"title\" text NOT NULL,\n\t\"standard_ref\" text NOT NULL,\n\t\"applicable\" boolean NOT NULL,\n\t\"not_applicable_reason\" text,\n\t\"body\" text NOT NULL,\n\t\"tables\" jsonb,\n\t\"editable_override\" boolean\n)",
  "CREATE TABLE IF NOT EXISTS \"employees\" (\n\t\"id\" integer PRIMARY KEY NOT NULL,\n\t\"client_id\" integer,\n\t\"bp_no\" text NOT NULL,\n\t\"name\" text NOT NULL,\n\t\"role\" text NOT NULL,\n\t\"department\" text NOT NULL,\n\t\"cost_center\" text,\n\t\"jurisdiction\" text NOT NULL,\n\t\"basic_salary\" double precision NOT NULL,\n\t\"allowances\" double precision DEFAULT 0 NOT NULL,\n\t\"ssnit_number\" text NOT NULL,\n\t\"tin\" text NOT NULL,\n\t\"status\" text NOT NULL,\n\t\"is_resident\" boolean DEFAULT true NOT NULL,\n\t\"exempt_tier1\" boolean DEFAULT false NOT NULL,\n\t\"exempt_tier2\" boolean DEFAULT false NOT NULL,\n\t\"ssnit_exempt\" boolean DEFAULT false NOT NULL,\n\t\"ssnit_exemption_reason\" text,\n\t\"tax_relief\" double precision DEFAULT 0 NOT NULL,\n\t\"relief_type\" text,\n\t\"deductions\" jsonb\n)",
  "CREATE TABLE IF NOT EXISTS \"journal_lines\" (\n\t\"id\" text PRIMARY KEY NOT NULL,\n\t\"doc_no\" text NOT NULL,\n\t\"period\" text NOT NULL,\n\t\"date\" text NOT NULL,\n\t\"module\" text NOT NULL,\n\t\"doc_type\" text NOT NULL,\n\t\"account_no\" text NOT NULL,\n\t\"account_name\" text NOT NULL,\n\t\"cost_center\" text,\n\t\"debit\" double precision DEFAULT 0 NOT NULL,\n\t\"credit\" double precision DEFAULT 0 NOT NULL,\n\t\"currency\" text NOT NULL,\n\t\"description\" text NOT NULL,\n\t\"created_by\" text NOT NULL,\n\t\"checked_by\" text,\n\t\"is_reversed\" boolean DEFAULT false NOT NULL,\n\t\"reference\" text,\n\t\"client_id\" integer NOT NULL\n)",
  "CREATE TABLE IF NOT EXISTS \"payroll_records\" (\n\t\"id\" text PRIMARY KEY NOT NULL,\n\t\"client_id\" integer NOT NULL,\n\t\"record\" jsonb NOT NULL\n)",
  "CREATE TABLE IF NOT EXISTS \"prepayment_records\" (\n\t\"id\" text PRIMARY KEY NOT NULL,\n\t\"client_id\" integer NOT NULL,\n\t\"record\" jsonb NOT NULL\n)",
  "CREATE TABLE IF NOT EXISTS \"prepayment_schedules\" (\n\t\"id\" text PRIMARY KEY NOT NULL,\n\t\"prepayment_id\" text NOT NULL,\n\t\"client_id\" integer NOT NULL,\n\t\"line\" jsonb NOT NULL\n)",
  "CREATE TABLE IF NOT EXISTS \"purchase_orders\" (\n\t\"id\" text PRIMARY KEY NOT NULL,\n\t\"client_id\" integer NOT NULL,\n\t\"po_no\" text NOT NULL,\n\t\"vendor_name\" text NOT NULL,\n\t\"item_type\" text NOT NULL,\n\t\"item_description\" text NOT NULL,\n\t\"qty\" double precision NOT NULL,\n\t\"unit_price\" double precision NOT NULL,\n\t\"vat_recoverable\" double precision DEFAULT 0 NOT NULL,\n\t\"total_amount\" double precision NOT NULL,\n\t\"paid_amount\" double precision DEFAULT 0 NOT NULL,\n\t\"status\" text NOT NULL,\n\t\"date\" text NOT NULL,\n\t\"currency\" text,\n\t\"vat_treatment\" text,\n\t\"net_amount\" double precision,\n\t\"quotation_ref\" text,\n\t\"gl_account\" text NOT NULL,\n\t\"gl_account_name\" text NOT NULL,\n\t\"cost_center\" text NOT NULL,\n\t\"cost_center_name\" text NOT NULL\n)",
  "CREATE TABLE IF NOT EXISTS \"sales_invoices\" (\n\t\"id\" text PRIMARY KEY NOT NULL,\n\t\"client_id\" integer NOT NULL,\n\t\"inv_no\" text NOT NULL,\n\t\"customer_name\" text NOT NULL,\n\t\"revenue_stream\" text NOT NULL,\n\t\"net_revenue\" double precision NOT NULL,\n\t\"vat_output\" double precision DEFAULT 0 NOT NULL,\n\t\"cst_amount\" double precision,\n\t\"tourism_levy_amount\" double precision,\n\t\"vat_withheld_by_customer\" double precision,\n\t\"total_receivable\" double precision NOT NULL,\n\t\"paid_amount\" double precision DEFAULT 0 NOT NULL,\n\t\"status\" text NOT NULL,\n\t\"date\" text NOT NULL\n)",
  // Sessions live in a dedicated table: a `sessions` table left behind by an
  // earlier build (or another app on the same database) has an incompatible
  // shape, and `CREATE TABLE IF NOT EXISTS` would keep it — which broke session
  // lookups and bounced signed-in users back to the login screen.
  "CREATE TABLE IF NOT EXISTS \"bpz_sessions\" (\n\t\"token\" text PRIMARY KEY NOT NULL,\n\t\"user_id\" text NOT NULL,\n\t\"expires_at\" bigint NOT NULL,\n\t\"last_seen_at\" bigint,\n\t\"created_at\" timestamp with time zone DEFAULT now() NOT NULL\n)",
  "CREATE INDEX IF NOT EXISTS \"bpz_sessions_user_idx\" ON \"bpz_sessions\" USING btree (\"user_id\")",
  "CREATE INDEX IF NOT EXISTS \"bpz_sessions_expiry_idx\" ON \"bpz_sessions\" USING btree (\"expires_at\")",
  "CREATE TABLE IF NOT EXISTS \"users\" (\n\t\"id\" text PRIMARY KEY NOT NULL,\n\t\"username\" text NOT NULL,\n\t\"email\" text NOT NULL,\n\t\"name\" text NOT NULL,\n\t\"role\" text NOT NULL,\n\t\"maker_limit\" double precision DEFAULT 0 NOT NULL,\n\t\"can_check\" boolean DEFAULT false NOT NULL,\n\t\"client_id\" integer,\n\t\"password_hash\" text,\n\t\"password_salt\" text,\n\t\"status\" text DEFAULT 'active' NOT NULL,\n\t\"restriction_reason\" text,\n\t\"permissions\" jsonb,\n\t\"created_at\" timestamp with time zone DEFAULT now() NOT NULL\n)",
  "CREATE UNIQUE INDEX IF NOT EXISTS \"chart_accounts_no_idx\" ON \"chart_accounts\" USING btree (\"account_no\")",
  "CREATE UNIQUE INDEX IF NOT EXISTS \"closed_periods_client_period_idx\" ON \"closed_periods\" USING btree (\"client_id\",\"period\")",
  "CREATE UNIQUE INDEX IF NOT EXISTS \"users_username_idx\" ON \"users\" USING btree (\"username\")",
  "CREATE UNIQUE INDEX IF NOT EXISTS \"users_email_idx\" ON \"users\" USING btree (\"email\")",
  // --- Idempotent in-place migrations for databases created by earlier builds ---
  // Employee cost centre (payroll cost allocation by responsibility centre).
  "ALTER TABLE \"employees\" ADD COLUMN IF NOT EXISTS \"cost_center\" text",
  // The chart of accounts is scoped per entity: the same account number may
  // exist as a firm-master account AND as a client's own custom account, so the
  // uniqueness constraint must include the owning entity (0 = firm master).
  "DROP INDEX IF EXISTS \"chart_accounts_no_idx\"",
  "CREATE UNIQUE INDEX IF NOT EXISTS \"chart_accounts_scope_idx\" ON \"chart_accounts\" (\"account_no\", COALESCE(\"client_id\", 0))",
  // Tenant column repairs. Databases created before multi-entity isolation had
  // no `client_id` on the operational tables; a `select` of that column then
  // failed with HTTP 500 on /api/bootstrap and /api/state, which the browser
  // could not distinguish from a broken sign-in. Added as NULLABLE so existing
  // rows are never rejected; new writes always carry the owning entity.
  "ALTER TABLE \"journal_lines\" ADD COLUMN IF NOT EXISTS \"client_id\" integer",
  "ALTER TABLE \"bank_accounts\" ADD COLUMN IF NOT EXISTS \"client_id\" integer",
  "ALTER TABLE \"purchase_orders\" ADD COLUMN IF NOT EXISTS \"client_id\" integer",
  "ALTER TABLE \"sales_invoices\" ADD COLUMN IF NOT EXISTS \"client_id\" integer",
  "ALTER TABLE \"employees\" ADD COLUMN IF NOT EXISTS \"client_id\" integer",
  "ALTER TABLE \"business_partners\" ADD COLUMN IF NOT EXISTS \"client_id\" integer",
  "ALTER TABLE \"approval_requests\" ADD COLUMN IF NOT EXISTS \"client_id\" integer",
  "ALTER TABLE \"payroll_records\" ADD COLUMN IF NOT EXISTS \"client_id\" integer",
  "ALTER TABLE \"prepayment_records\" ADD COLUMN IF NOT EXISTS \"client_id\" integer",
  "ALTER TABLE \"prepayment_schedules\" ADD COLUMN IF NOT EXISTS \"client_id\" integer",
  "ALTER TABLE \"closed_periods\" ADD COLUMN IF NOT EXISTS \"client_id\" integer",
  "ALTER TABLE \"audit_log\" ADD COLUMN IF NOT EXISTS \"client_id\" integer",
  // Session/user columns the auth layer depends on. Repaired in place so a
  // partially migrated database can never 401 a freshly issued session.
  "ALTER TABLE \"users\" ADD COLUMN IF NOT EXISTS \"status\" text DEFAULT 'active'",
  "ALTER TABLE \"users\" ADD COLUMN IF NOT EXISTS \"restriction_reason\" text",
  "ALTER TABLE \"users\" ADD COLUMN IF NOT EXISTS \"permissions\" jsonb",
  "ALTER TABLE \"users\" ADD COLUMN IF NOT EXISTS \"password_hash\" text",
  "ALTER TABLE \"users\" ADD COLUMN IF NOT EXISTS \"password_salt\" text",
  "ALTER TABLE \"users\" ADD COLUMN IF NOT EXISTS \"client_id\" integer",
];
