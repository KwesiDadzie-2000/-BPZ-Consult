import { db } from "@/db";
import { sessions, users } from "@/db/schema";
import { eq, lt } from "drizzle-orm";
import type { UserAccount } from "@/types/accounting";

/**
 * Working sessions last 8 hours and slide forward on every authenticated
 * request once less than 30 minutes remain — a user posting journals or payroll
 * during a long working day must not be cut off mid-task by an expired session.
 */
export const SESSION_TTL_MS = 8 * 60 * 60 * 1000;
const SLIDE_THRESHOLD_MS = 30 * 60 * 1000;

/**
 * Session cookie name.
 *
 * WHY A COOKIE AT ALL: the browser used to be the only carrier of the session
 * token (`sessionStorage` + `Authorization: Bearer`). That breaks — and bounced
 * users straight back to the login portal a moment after a successful sign-in —
 * whenever the token cannot make the round trip:
 *   • a hosting/CDN proxy strips the `Authorization` header,
 *   • the workspace is opened in a new tab or the browser restores tabs
 *     (`sessionStorage` is per-tab, so the token is simply gone),
 *   • site data is blocked/partitioned, so `sessionStorage.setItem` throws and
 *     the token is never stored at all,
 *   • a stale in-flight `/api/auth/session` response wiped the fresh token.
 * An HttpOnly cookie is sent by the browser on every same-site request, is
 * invisible to JavaScript (so nothing can wipe it), survives new tabs and
 * reloads, and cannot be stripped by a proxy. The Bearer token is still
 * accepted as a fallback, so both carriers work.
 */
export const SESSION_COOKIE = "bpz_session";

/** Strips secrets — user records returned to the browser never carry password material. */
export function sanitizeUser(row: typeof users.$inferSelect): UserAccount {
  return {
    username: row.username,
    name: row.name,
    role: row.role as UserAccount["role"],
    makerLimit: row.makerLimit,
    canCheck: row.canCheck,
    email: row.email,
    clientId: row.clientId ?? undefined,
    status: (row.status as UserAccount["status"]) ?? "active",
    restrictionReason: row.restrictionReason ?? undefined,
    permissions: (row.permissions as UserAccount["permissions"]) ?? undefined,
  };
}

/* ------------------------------------------------------------------ *
 * Cookie plumbing
 * ------------------------------------------------------------------ */

/** True only when the request really arrived over TLS (proxies set x-forwarded-proto). */
export function isHttpsRequest(req: Request): boolean {
  const forwarded = (req.headers.get("x-forwarded-proto") || "").split(",")[0].trim().toLowerCase();
  if (forwarded) return forwarded === "https";
  try {
    return new URL(req.url).protocol === "https:";
  } catch {
    return false;
  }
}

/**
 * True when the page is embedded from another site (preview iframes, embedded
 * dashboards). Such requests need `SameSite=None` or the browser will not send
 * the cookie back — the user would be signed out immediately after signing in.
 */
export function isCrossSiteRequest(req: Request): boolean {
  const site = (req.headers.get("sec-fetch-site") || "").trim().toLowerCase();
  if (site === "cross-site") return true;
  if (site === "same-origin" || site === "same-site") return false;
  const origin = req.headers.get("origin");
  if (!origin) return false;
  try {
    return new URL(origin).host !== new URL(req.url).host;
  } catch {
    return false;
  }
}

function cookieAttributes(req: Request): string[] {
  const secure = isHttpsRequest(req);
  // SameSite=None is only honoured by browsers together with Secure, so it is
  // used only on a real TLS cross-site request; plain http previews keep Lax.
  const sameSite = secure && isCrossSiteRequest(req) ? "None" : "Lax";
  const attrs = ["Path=/", "HttpOnly", `SameSite=${sameSite}`];
  if (secure || sameSite === "None") attrs.push("Secure");
  return attrs;
}

/** Builds the `Set-Cookie` header that carries the session token. */
export function sessionCookie(req: Request, token: string, maxAgeSeconds = SESSION_TTL_MS / 1000): string {
  return [
    `${SESSION_COOKIE}=${encodeURIComponent(token)}`,
    ...cookieAttributes(req),
    `Max-Age=${Math.max(0, Math.floor(maxAgeSeconds))}`,
  ].join("; ");
}

/** Builds the `Set-Cookie` header that expires the session cookie. */
export function clearedSessionCookie(req: Request): string {
  return [`${SESSION_COOKIE}=`, ...cookieAttributes(req), "Max-Age=0", "Expires=Thu, 01 Jan 1970 00:00:00 GMT"].join("; ");
}

/**
 * Session token from the request: cookie first (the browser always sends it),
 * then the `Authorization: Bearer` header (native/preview clients, and the
 * fallback when cookies are blocked).
 */
export function readSessionToken(req: Request): string | null {
  const cookieHeader = req.headers.get("cookie") || "";
  for (const part of cookieHeader.split(";")) {
    const idx = part.indexOf("=");
    if (idx === -1) continue;
    if (part.slice(0, idx).trim() !== SESSION_COOKIE) continue;
    const raw = part.slice(idx + 1).trim();
    if (!raw) continue;
    try {
      return decodeURIComponent(raw);
    } catch {
      return raw;
    }
  }
  const header = req.headers.get("authorization") || "";
  const token = header.startsWith("Bearer ") ? header.slice(7).trim() : "";
  return token || null;
}

/* ------------------------------------------------------------------ *
 * Session lookup
 * ------------------------------------------------------------------ */

/** Validates a raw token and returns the session user, or null. */
export async function getSessionUserByToken(token: string | null): Promise<UserAccount | null> {
  if (!token) return null;
  const found = await db.select().from(sessions).where(eq(sessions.token, token)).limit(1);
  const session = found[0];
  if (!session || session.expiresAt < Date.now()) {
    if (session) {
      // Best-effort cleanup: a failed delete must never invalidate the request.
      try {
        await db.delete(sessions).where(eq(sessions.token, token));
      } catch (error) {
        console.error("expired session cleanup failed", error);
      }
    }
    return null;
  }
  const now = Date.now();
  // Sliding renewal: extend an active session so continuous work never loses it.
  if (session.expiresAt < now + SLIDE_THRESHOLD_MS) {
    try {
      await db.update(sessions).set({ expiresAt: now + SESSION_TTL_MS, lastSeenAt: now }).where(eq(sessions.token, token));
    } catch (error) {
      // A failed slide must not sign the user out — the session is still valid.
      console.error("session slide failed", error);
    }
  } else if (!session.lastSeenAt || session.lastSeenAt < now - 60_000) {
    try {
      await db.update(sessions).set({ lastSeenAt: now }).where(eq(sessions.token, token));
    } catch {
      /* heartbeat only — never fatal */
    }
  }
  const userRows = await db.select().from(users).where(eq(users.id, session.userId)).limit(1);
  const user = userRows[0];
  if (!user || user.status === "restricted" || user.status === "suspended") return null;
  return sanitizeUser(user);
}

/** Validates the request's cookie/Bearer token and returns the session user, or null. */
export async function getSessionUser(req: Request): Promise<UserAccount | null> {
  return getSessionUserByToken(readSessionToken(req));
}

export async function createSession(userId: string): Promise<string> {
  // 256-bit cryptographically random session token (UUIDv4 carries only 122
  // bits and is not specified as a CSPRNG output in every runtime).
  const token = Array.from(crypto.getRandomValues(new Uint8Array(32)))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
  const now = Date.now();
  await db.insert(sessions).values({
    token,
    userId,
    expiresAt: now + SESSION_TTL_MS,
    lastSeenAt: now,
  });
  return token;
}

export async function destroySession(token: string): Promise<void> {
  await db.delete(sessions).where(eq(sessions.token, token));
}

/** Housekeeping: drops rows that expired more than a day ago. Never throws. */
export async function pruneExpiredSessions(): Promise<void> {
  try {
    await db.delete(sessions).where(lt(sessions.expiresAt, Date.now() - 24 * 60 * 60 * 1000));
  } catch {
    /* housekeeping only */
  }
}

/** Owner-only guard. Returns the user or null (route handlers respond 403). */
export async function requireOwner(req: Request): Promise<UserAccount | null> {
  const user = await getSessionUser(req);
  if (!user || user.role !== "owner") return null;
  return user;
}

/* ------------------------------------------------------------------ *
 * JSON responses that must never be cached
 * ------------------------------------------------------------------ */

/**
 * Auth/workspace JSON with `Cache-Control: no-store`.
 *
 * A shared cache (CDN, hosting proxy, service worker) that replayed an earlier
 * `401 Unauthorized` for `/api/bootstrap` is enough to throw a signed-in user
 * back to the login portal, so every session-bearing response is uncacheable.
 */
export function authJson(
  req: Request,
  body: unknown,
  init: { status?: number; token?: string; clearCookie?: boolean } = {}
): Response {
  const headers = new Headers({
    "content-type": "application/json; charset=utf-8",
    "cache-control": "no-store, max-age=0, must-revalidate",
    pragma: "no-cache",
  });
  if (init.token) headers.append("set-cookie", sessionCookie(req, init.token));
  if (init.clearCookie) headers.append("set-cookie", clearedSessionCookie(req));
  return new Response(JSON.stringify(body), { status: init.status ?? 200, headers });
}

export { hasFirmWideScope } from "@/utils/access";
