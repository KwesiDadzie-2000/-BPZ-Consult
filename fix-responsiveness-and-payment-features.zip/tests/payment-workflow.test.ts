import { test } from 'node:test';
import assert from 'node:assert/strict';
import type { ACDOCALine } from '../src/types/accounting';
import { deriveExpenseBills, statutoryPayableRows, liabilityBalance, EXPENSE_BILL_PREFIX } from '../src/utils/payables';

const CID = 2;
let seq = 0;
const line = (partial: Partial<ACDOCALine>): ACDOCALine => ({
  id: `L${++seq}`,
  docNo: 'DOC',
  period: '2026-07',
  date: '2026-07-10',
  module: 'FI',
  docType: 'STAT',
  accountNo: '620000',
  accountName: 'Utilities',
  costCenter: 'CC-ADM',
  debit: 0,
  credit: 0,
  currency: 'GHS',
  description: 'test',
  createdBy: 'accountant',
  clientId: CID,
  ...partial,
});

const billNo = `${EXPENSE_BILL_PREFIX}2026-07-1`;
const accrual = [
  line({ docNo: billNo, reference: billNo, accountNo: '620000', debit: 800 }),
  line({ docNo: billNo, reference: billNo, accountNo: '125000', accountName: 'VAT Input', debit: 200 }),
  line({ docNo: billNo, reference: billNo, accountNo: '202000', accountName: 'Accrued Expenses & Other Payables (ECG)', credit: 1000 }),
];

test('expense bill is recorded as a payable, never a direct bank payment', () => {
  const bills = deriveExpenseBills(accrual, CID);
  assert.equal(bills.length, 1);
  assert.equal(bills[0].payee, 'ECG');
  assert.equal(bills[0].gross, 1000);
  assert.equal(bills[0].outstanding, 1000);
  assert.equal(bills[0].status, 'Awaiting payment');
  // No treasury account was touched by the accrual.
  assert.ok(accrual.every((l) => !['100000', '102000', '104000'].includes(l.accountNo)));
});

test('partial and full settlement at the Payment Desk clear the payable progressively', () => {
  const partial = line({ docNo: 'PAY-B1', reference: billNo, docType: 'PAY', accountNo: '202000', debit: 400 });
  let bills = deriveExpenseBills([...accrual, partial], CID);
  assert.equal(bills[0].outstanding, 600);
  assert.equal(bills[0].status, 'Partially paid');
  const rest = line({ docNo: 'PAY-B2', reference: billNo, docType: 'PAY', accountNo: '202000', debit: 600 });
  bills = deriveExpenseBills([...accrual, partial, rest], CID);
  assert.equal(bills[0].outstanding, 0);
  assert.equal(bills[0].status, 'Paid');
});

test('reversing a settlement re-opens the bill; reversing the bill removes it from payables', () => {
  const partial = line({ docNo: 'PAY-B1', reference: billNo, docType: 'PAY', accountNo: '202000', debit: 400 });
  const revPay = line({ docNo: 'REV-PAY-B1', reference: billNo, docType: 'REV', accountNo: '202000', credit: 400 });
  let bills = deriveExpenseBills([...accrual, partial, revPay], CID);
  assert.equal(bills[0].outstanding, 1000);
  const reversedAccrual = accrual.map((l) => ({ ...l, isReversed: true }));
  bills = deriveExpenseBills([...reversedAccrual, partial, revPay], CID);
  assert.equal(bills[0].status, 'Reversed');
  assert.equal(bills[0].outstanding, 0);
});

test('posted payroll immediately registers PAYE, SSNIT Tier 1 13.5% and Tier 2 5% as payables', () => {
  // Insurable basic 10,000 → 18.5% = 1,850 → Tier 1 1,350 + Tier 2 500; PAYE 1,200; net 7,000.
  const payroll: ACDOCALine[] = [
    line({ docNo: 'PAYROLL-2026-07', module: 'HR', accountNo: '510000', debit: 10000 }),
    line({ docNo: 'PAYROLL-2026-07', module: 'HR', accountNo: '511000', debit: 1300 }),
    line({ docNo: 'PAYROLL-2026-07', module: 'HR', accountNo: '205000', credit: 8250 }),
    line({ docNo: 'PAYROLL-2026-07', module: 'HR', accountNo: '207000', credit: 1200 }),
    line({ docNo: 'PAYROLL-2026-07', module: 'HR', accountNo: '206000', credit: 1350 }),
    line({ docNo: 'PAYROLL-2026-07', module: 'HR', accountNo: '206100', credit: 500 }),
  ];
  const rows = statutoryPayableRows(payroll, CID);
  assert.equal(rows.find((r) => r.accountNo === '207000')?.balance, 1200);
  assert.equal(rows.find((r) => r.accountNo === '206000')?.balance, 1350);
  assert.equal(rows.find((r) => r.accountNo === '206100')?.balance, 500);
  // Balanced document.
  const dr = payroll.reduce((s, l) => s + l.debit, 0);
  const cr = payroll.reduce((s, l) => s + l.credit, 0);
  assert.equal(dr, cr);
});

test('statutory remittance debits the payable and reduces the live balance', () => {
  const posted = [
    line({ docNo: 'PAYROLL-2026-07', accountNo: '206100', credit: 500 }),
    line({ docNo: 'STAT-206100-2026-08', docType: 'PAY', accountNo: '206100', debit: 500 }),
    line({ docNo: 'STAT-206100-2026-08', docType: 'PAY', accountNo: '100000', credit: 500 }),
  ];
  assert.equal(liabilityBalance(posted, CID, '206100'), 0);
});

test('entity isolation: another client\'s bills and statutory balances never leak', () => {
  const other = accrual.map((l) => ({ ...l, clientId: CID + 1, id: `X${l.id}` }));
  assert.equal(deriveExpenseBills([...accrual, ...other], CID).length, 1);
  assert.equal(liabilityBalance(other, CID, '202000'), 0);
});

import { incomeWithholding, isValidPayee, payeeSuffix, whtSuffix } from '../src/utils/payables';

test('withholding is only deducted when the operator chooses to apply it', () => {
  assert.equal(incomeWithholding(1000, 7.5, true), 75);
  assert.equal(incomeWithholding(1000, 7.5, false), 0, 'choosing "No withholding tax" deducts nothing');
  assert.equal(incomeWithholding(0, 7.5, true), 0);
  assert.equal(incomeWithholding(Number.NaN, 7.5, true), 0);
  assert.equal(incomeWithholding(1000, 0, true), 0);
  // rounds to pesewas on the VAT-exclusive base
  assert.equal(incomeWithholding(333.33, 3, true), 10);
});

test('payee must be named and is recorded in the journal description', () => {
  assert.equal(isValidPayee(undefined), false);
  assert.equal(isValidPayee({ kind: 'company', name: '   ', source: 'other' }), false);
  assert.equal(isValidPayee({ kind: 'individual', name: 'Ama Owusu', source: 'other' }), true);
  assert.equal(isValidPayee({ kind: 'company', name: 'x'.repeat(121), source: 'other' }), false);
  assert.equal(payeeSuffix({ kind: 'company', name: ' Acme Ltd ', source: 'partner' }), ' → Acme Ltd (company)');
  assert.equal(payeeSuffix({ kind: 'individual', name: 'Ama Owusu', source: 'other' }), ' → Ama Owusu (individual)');
  assert.equal(payeeSuffix(undefined), '');
  assert.equal(whtSuffix(true, 7.5), '');
  assert.match(whtSuffix(false, 0, 'GRA cert 123'), /not applied \(GRA cert 123\)/);
  assert.match(whtSuffix(false, 0), /not applied/);
});
